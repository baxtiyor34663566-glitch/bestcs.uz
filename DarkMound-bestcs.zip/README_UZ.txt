BESTCS.UZ - DarkMound Plus GE (GameCMS) sozlangan versiya
=========================================================

NIMALAR O'ZGARTIRILDI
- Logo, favicon va reklama banneri bestcs.uz uchun yangilandi (img/ papkasi)
- Footer, slayder va asosiy matnlar o'zbekchaga o'girildi
- Telegram kanal: https://t.me/bestcsuz, chat: https://t.me/bestcschat
- Server IP: 195.158.4.108:27111 (slayder va footerda, "Serverga kirish" tugmasi)
- Counter-Strike 2 yozuvi Counter-Strike 1.6 ga almashtirildi
- Muallifning Google Tag Manager (GTM-PD3VWC3) kuzatuv kodi olib tashlandi
- F12 / Ctrl+U ni bloklaydigan skript olib tashlandi
- Eski cache fayllari tozalandi

O'RNATISH
1) Saytingizdagi GameCMS ning templates/ papkasiga DarkMound-Plus-GE papkasini yuklang
   (zip ichida: DarkMoundPlusGEGameCMS/DarkMound-Plus-GE)
2) modules_extra/site_stats papkasini saytdagi modules_extra/ ga yuklang
3) Admin panel -> Sozlamalar -> shablonni DarkMound-Plus-GE ga almashtiring
4) inc/classes/class.getdata.php ni ZAXIRA QILMASDAN ustiga yozmang. Bu GameCMS
   ning o'z fayli, avval eskisini nusxalab qo'ying. Shablon u holda ham ishlasa,
   bu faylni umuman yuklamang.

ADMIN PANELDA QILINADIGAN ISHLAR (shablonda emas)
- Serverni qo'shish: Monitoring/Serverlar bo'limida 195.158.4.108 : 27111 (CS 1.6)
  Shunda "Serverlar yo'q" yozuvi o'rniga server va online o'yinchilar chiqadi.
- Yuqori menyu (Главная, Новости, Форум, Поддержка) nomlari: Menyu sozlamalarida
- Sayt nomi, title, description: Umumiy sozlamalar
- Privilegiyalar narxlari: Do'kon bo'limi
