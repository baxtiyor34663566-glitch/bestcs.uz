<style>
#site_stats small {
    margin-left: 5px;
    color: rgb(255 255 255);
    background: #ff7167;
    padding: 0px 7px;
    position: relative;
    top: 4px;
    font-size: 8.5px;
    height: 12px;
    border-radius: 50px;
    font-weight: bold;
    line-height: 12px;
}
  
  #site_stats small a {
    color: rgb(209, 87, 77);
  }
</style>

 <div class="stats_vnutr">
		
		<a class="a_mobile" href="../users">
        <div class="stats_mini_block">
		<i class='bx bx-carousel' ></i>
		<div class="right_stats_info">
          <span class="span_number">{users}
		  {if({users_diff} > 0)}
		  <small title="Изменение за сутки" tooltip="yes">
			+{users_diff}
		  </small>
		  {/if}
		  </span>
          <span class="span_text">ПОЛЬЗОВАТЕЛЕЙ</span>
		  </div>
        </div>
		</a>
		
		<a class="a_mobile" href="../banlist">
		<div class="stats_mini_block">
		<i class='bx bx-lock' ></i>
		<div class="right_stats_info">
          <span class="span_number">{servers_bans}
		  {if({servers_bans_diff} > 0)}
		  <small title="Изменение за сутки" tooltip="yes">
			+{servers_bans_diff}
		  </small>
		  {/if}
		  </span>
          <span class="span_text">ВСЕГО БАНОВ</span>
		  </div>
        </div>
		</a>
		
		<a class="a_mobile" href="#">
		<div class="stats_mini_block">
		<i class='bx bx-message-square-detail' ></i>
		<div class="right_stats_info">
          <span class="span_number">{chat}
		  {if({chat_diff} > 0)}
		  <small title="Изменение за сутки" tooltip="yes">
			+{chat_diff}
		  </small>
		  {/if}
		  </span>
          <span class="span_text">СООБЩЕНИЙ</span>
		  </div>
        </div>
		</a>
		
		<a class="a_mobile" href="../stats">
		<div class="stats_mini_block">
		<i class='bx bx-line-chart' ></i>
		<div class="right_stats_info">
          <span class="span_number">{servers_stats}
		  {if({servers_stats_diff} > 0)}
		  <small title="Изменение за сутки" tooltip="yes">
			+{servers_stats_diff}
		  </small>
		  {/if}
		  </span>
          <span class="span_text">В СТАТИСТИКЕ</span>
		  </div>
        </div>
		</a>
		
		<a class="a_mobile" href="#">
		<div class="stats_mini_block">
		<i class='bx bx-server' ></i>
		<div class="right_stats_info">
          <span class="span_number">{servers}
		  {if({servers_diff} > 0)}
		  <small title="Изменение за сутки" tooltip="yes">
			+{servers_diff}
		  </small>
		  {/if}
		  </span>
          <span class="span_text">СЕРВЕРОВ</span>
		  </div>
        </div>
		</a>
        
      </div>