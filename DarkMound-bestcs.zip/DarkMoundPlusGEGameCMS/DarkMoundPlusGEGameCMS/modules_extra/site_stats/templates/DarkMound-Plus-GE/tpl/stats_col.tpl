<style>
	#site_stats small {
		position: absolute;
		margin-left: 3px;
		color: rgb(209, 87, 77);
		font-weight: bold;
		line-height: 10px;
	}
	#site_stats small a {
		color: rgb(209, 87, 77);
	}
</style>
<div class="block">
	<p>
		Всего пользователей: <b>{users}</b>
		{if({users_diff} > 0)}
			<small title="Изменение за сутки" tooltip="yes">
				<a target="_blank" href="../events?class=3">+{users_diff}</a>
			</small>
		{/if} <br>
	</p>
	<hr>
	<p>
		Банов на серверах: <b>{servers_bans}</b>
		{if({servers_bans_diff} > 0)}
			<small title="Изменение за сутки" tooltip="yes">
				+{servers_bans_diff}
			</small>
		{/if} <br>
	</p>
	<hr>
	<p>
		Игроков в статистике: <b>{servers_stats}</b>
		{if({servers_stats_diff} > 0)}
			<small title="Изменение за сутки" tooltip="yes">
				+{servers_stats_diff}
			</small>
		{/if}
	</p>
</div>