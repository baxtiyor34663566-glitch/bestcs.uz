{if(is_auth())}
{else}
<div class="block authorization" style="padding: 25px 5px;margin-left: 0px;">
    <!-- Заголовок -->
    <div class="top_info_index">
        <i class='bx bx-lock-open-alt'></i>
        <b class="pretext_index">Авторизация</b>
    </div>
    <form id="user_login">
        <input type="text" maxlength="30" class="form-control" id="user_loginn" placeholder="Введите логин">
        <input type="password" maxlength="15" class="form-control" id="user_password" placeholder="Введите пароль">

        <div class="row">
            <div class="col-12">
                <div class="block_auth_push">
                    <button type="submit" class="voiti">Войти</button>
                    {if($auth_api->vk_api == 1)}
                    <a class="vkbut" href="" id="vk_link" title="Войти через Вконтакте">
                        <i class='bx bxl-vk'></i>
                    </a>
                    <script>
                        get_vk_auth_link();
                    </script>
                    {/if}


                    {if($auth_api->steam_api == 1)}
                    <a class="steambut" href="" id="steam_link" title="Войти через Steam">
                        <i class='bx bxl-steam'></i>
                    </a>
                    <script>
                        get_steam_auth_link();
                    </script>
                    {/if}
                </div>
            </div>
            <div class="col-12" style="display: flex;">
            </div>
        </div>

        <div id="result" class="disp-n">{conf_mess}</div>
    </form>
    <script>
        send_form('#user_login', 'user_login();');
    </script>
    <a href="../recovery" class="small">Забыли пароль?</a>
</div>
{/if}