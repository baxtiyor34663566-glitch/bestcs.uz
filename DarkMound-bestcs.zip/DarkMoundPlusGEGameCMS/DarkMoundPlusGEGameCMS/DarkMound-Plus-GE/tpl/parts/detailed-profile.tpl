<script>
         $(function() {
            $('.multiple-items').slick({
              infinite: true,
              dots: false,
              spaceBetween: 30,
              autoplay: true,
              slidesToShow: 3,
              arrows: false,
              slidesToScroll: 1,
            })
         })
      </script>
      
      <div class="multiple-items">
         <div class="advertising" style="background-image: url(../templates/DarkMound-Plus-GE/img/reklama.png);background-size: cover;">
           
        </div>
        
        <div class="advertising" style="background-image: url(../templates/DarkMound-Plus-GE/img/reklama.png);background-size: cover;">
           
        </div>
        
        <div class="advertising" style="background-image: url(../templates/DarkMound-Plus-GE/img/reklama.png);background-size: cover;">
           
        </div>
        
        <div class="advertising" style="background-image: url(../templates/DarkMound-Plus-GE/img/reklama.png);background-size: cover;">
           
        </div>
        
        <div class="advertising" style="background-image: url(../templates/DarkMound-Plus-GE/img/reklama.png);background-size: cover;">
           
        </div>
      </div>