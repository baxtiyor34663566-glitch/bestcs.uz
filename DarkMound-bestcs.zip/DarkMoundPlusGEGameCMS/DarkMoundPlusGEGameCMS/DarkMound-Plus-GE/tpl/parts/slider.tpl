<div class="toper">
    <script>
        $(function() {
            $('.nav_slider').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                ariableWidth: true,
                autoplay: false,
                spaceBetween: 30,
                arrows: false,
                dots: true,
                autoplaySpeed: 3000,
            })
        })
    </script>

    <!-- Слайдбар -->
    <div class="nav_slider">
        <div class="toper_block2" style="background-image: url(../templates/DarkMound-Plus-GE/img/slide-1.png);background-size: cover;">
            <div class="bar_top">
                <div class="fire_top"><i class='bx bx-cart-alt'></i></div>
                <span>Eng yaxshi takliflar</span>
            </div>
            <div class="bar">
                <p class="razrab">Privilegiyalar do'koni</p>
                <p class="text">VIP oling va serverda yangi<br>imkoniyatlarga ega bo'ling</p>
                <a href="../store" class="animate-pulse">Do'konga o'tish</a>
            </div>
        </div>

        <div class="toper_block2" style="background-image: url(../templates/DarkMound-Plus-GE/img/slide-1.png);background-size: cover;">
            <div class="bar_top">
                <div class="fire_top"><i class='bx bx-plug'></i></div>
                <span>Serverga ulaning</span>
            </div>
            <div class="bar">
                <p class="razrab">195.158.4.108:27111</p>
                <p class="text">Konsolga connect yozing yoki<br>tugmani bosing</p>
                <a href="steam://connect/195.158.4.108:27111" class="animate-pulse">Serverga kirish</a>
            </div>
        </div>

        <div class="toper_block2" style="background-image: url(../templates/DarkMound-Plus-GE/img/slide-1.png);background-size: cover;">
            <div class="bar_top">
                <div class="fire_top"><i class='bx bx-paper-plane'></i></div>
                <span>Yangiliklar va aksiyalar</span>
            </div>
            <div class="bar">
                <p class="razrab">Telegram kanal va chat</p>
                <p class="text">Yangiliklar, aksiyalar va yordam<br>uchun bizga qo'shiling</p>
                <a href="https://t.me/bestcsuz" target="_blank" class="animate-pulse">Kanalga o'tish</a>
            </div>
        </div>
    </div>

    <script>
        function local_change_admin_type(id) {
            var type = $('#store_type_' + id + ' option:selected').val();
            change_admin_bind_type(type, id);
        }
    </script>

    <!-- Блок над мониторингом -->
    <div class="toper_block">
        <div class="toper_mini_blocks">
            <div class="toper_mini_block">

                <a href="../store" class="button_sortion" style="background-image: url(../templates/DarkMound-Plus-GE/img/shop.png);background-size: cover;">
                    <div>
                        <div style="display: flex;flex-direction: column;">
                            <span style="font-size: 12px;font-weight: 600;">Do'kon</span>
                            <span class="open_open">Ochish</span>
                        </div>
                    </div>
                </a>

                <a href="../support" class="button_sortion" style="background-image: url(../templates/DarkMound-Plus-GE/img/support.png);background-size: cover;">
                    <div>
                        <div style="display: flex;flex-direction: column;">
                            <span style="font-size: 12px;font-weight: 600;">Yordam</span>
                            <span class="open_open">Ochish</span>
                        </div>
                    </div>
                </a>

                <a href="../stats" class="button_sortion" style="background-image: url(../templates/DarkMound-Plus-GE/img/trophy.png);background-size: cover;">
                    <div>
                        <div style="display: flex;flex-direction: column;">
                            <span style="font-size: 12px;font-weight: 600;">Statistika</span>
                            <span class="open_open" style="background: linear-gradient(12deg, #763f1a 0%, rgb(255 111 14) 55%);">Ochish</span>
                        </div>
                    </div>
                </a>

                <div class="menuq">
                    <a href="../banlist" class="button_right_menu">
                        <div>
                            <i class='bx bx-lock-alt'></i>
                        </div>
                    </a>

                    <a href="../muts" class="button_right_menu">
                        <div>
                            <i class='bx bx-volume-mute'></i>
                        </div>
                    </a>
                </div>

            </div>

            <!-- Модальное окно посетителей сайта -->
            <script>
                $('#voucher').modal('hide');
            </script>
            <div id="online" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content" style="padding-bottom: 15px;">
                        <div class="modal-header">
                            <!-- Заголовок -->
                            <div class="top_info">
                                <i class='bx bx-chalkboard'></i>
                                <b class="pretext">Bugun tashrif buyurganlar</b>
                            </div>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
                        </div>
                        <div class="modal-body">
                            <div class="posetili" style="color: #fff0;" id="load_last_online">
                                {func Widgets:were_online()}
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Модальное окно правил чата -->
            <script>
                $('#voucher').modal('hide');
            </script>
            <div id="ruleschat" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content" style="padding-bottom: 15px;">
                        <div class="modal-header">
                            <!-- Заголовок -->
                            <div class="top_info">
                                <i class='bx bx-info-circle'></i>
                                <b class="pretext">Chat qoidalari</b>
                            </div>
                           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
                        </div>
                        <div class="modal-body">
                            <span>Bir-biringizni hurmat qiling. Haqorat, spam va reklama taqiqlanadi.</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Кнопки над мониторингом -->
        </div>

        <!-- Мониторинг -->
        <div class="block_servers">
            <div class="online_servers_full">
                <span>
                    <div class="online3"></div> PLAYERS ONLINE
                </span>
                <div id="line">
                    <script>
                        get_line();
                    </script>
                </div>
            </div>
            <div id="serverss">
                <div class="table-responsive monitoring-table">
                    <table class="table table-bordered">
                        <thead>
                            <div class="info-line">
                        </thead>
                        <tbody id="servers" style="position: relative;top: -8px;">
                            <tr>
                                <td colspan="10">
                                    <div class="loader"></div>
                                    <script>
                                        get_servers();
                                    </script>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>