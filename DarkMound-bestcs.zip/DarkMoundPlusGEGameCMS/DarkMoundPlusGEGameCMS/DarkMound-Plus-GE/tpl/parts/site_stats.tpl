<div class="block site-stats">
	<div id="site_stats">
		<script>get_site_stats(1);</script>
	</div>

	<strong>
		Сейчас на сайте
	</strong>
	<div id="online_users">
		{func Widgets:online_users()}
	</div>

	<strong>
		Сегодня нас посетили
	</strong>
	<div id="load_last_online"> 
		{func Widgets:were_online()}
	</div>
</div>