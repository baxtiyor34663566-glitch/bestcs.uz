{if(is_auth())}
<div class="block_mini_profile">
    <div class="navigation_profile">
        <div class="photo_profile">
            <a href="../profile">
                <img src="../{{$user->avatar}}" alt="{{$user->login}}" class="img_navigation">
            </a>
            <div class="info_navigation">
                <b class="name_sidebar">{{$user->login}}</b>
                <br>
                <b><b class="group_sidebar"> {{$users_groups[$user->rights]['name']}}</b></b>
            </div>
        </div>
        <a href="../exit">
            <i class="bx bx-log-in-circle"></i>
        </a>
    </div>
    <div class="balance_navigation1">
        <div style="display: flex;align-items: center;">
            <i class="bx bx-wallet" style="width: 34px;transition: all 0.2s;height: 34px;background: linear-gradient(34deg, #258a5e 0%, rgb(50 166 116) 55%);;font-size: 15px;display: flex;color: #ffffff;border-radius: 9px;align-items: center;justify-content: center;"></i>
            <b class="setting-sidebar">{{$user->shilings}} ₽</b>
        </div>
        <a href="../purse">
            <div class="button_plus_purse">
                <i class="bx bx-plus"></i>
            </div>
        </a>
    </div>
    <a href="../settings" class="balance_navigation">
        <i class='bx bx-cog'></i>
        <b class="setting-sidebar">Настройки профиля</b>
    </a>
</div>
{/if}
<div class="block" style="padding: 15px 18px 1px 18px;">
    <ul class="accordion">
        <b style="color: #41415d;font-size: 11px;margin-left: 25px;margin-bottom: 5px;margin-top: 20px;display: block;">ОСНОВНОЕ</b>
        <li>
            <p class="link-store" style="margin-bottom: 0px;"><a href="#" onclick="return false"><i class='bx bx-cart-alt'></i>Магазин<i class='bx bx-chevron-down' style="padding: 3px;border-radius: 50%;position: absolute;font-size: 16px;color: #777b88;top: 24px;margin-right: 0px;"></i></a></p>
            <ul class="submenu">
                <li><a href="../store">Покупка ADMIN</a></li>
                <li><a href="../buy_key">Покупка PREMIUM</a></li>
            </ul>
        </li>

        <li>
            <p class="link" style="margin-bottom: 0px;"><a href="../users"><i class='bx bx-user'></i>Пользователи</a></p>
        </li>


        <b style="color: #41415d;font-size: 11px;margin-left: 25px;margin-bottom: 5px;margin-top: 20px;display: block;">СЕРВЕРНАЯ ЧАСТЬ</b>
        <li>
            <p class="link" style="margin-bottom: 0px;"><a href="#" onclick="return false"><i class="bx bx-lock-alt"></i>Блокировки<i class='bx bx-chevron-down' style="padding: 3px;border-radius: 50%;position: absolute;font-size: 16px;color: #777b88;top: 24px;margin-right: 0px;"></i></a></p>
            <ul class="submenu">
                <li><a href="../banlist">Список банов</a></li>
                <li><a href="../muts">Список мутов</a></li>
            </ul>
        </li>

        <li>
            <p class="link" style="margin-bottom: 0px;"><a href="../admins"><i class='bx bx-shield'></i>Администраторы</a></p>
        </li>
        <li>
            <p class="link" style="margin-bottom: 0px;"><a href="../stats"><i class='bx bx-trophy'></i>Статистика</a></p>
        </li>
        <b style="color: #41415d;font-size: 11px;margin-left: 25px;margin-bottom: 5px;margin-top: 20px;display: block;">ПОМОЩЬ И ЗАЯВКИ</b>
        <li>
            <p class="link" style="margin-bottom: 0px;"><a href="#" onclick="return false"><i class='bx bx-layer'></i>Заявки и жалобы<i class='bx bx-chevron-down' style="padding: 3px;border-radius: 50%;position: absolute;font-size: 16px;color: #777b88;top: 24px;margin-right: 0px;"></i></a></p>
            <ul class="submenu">
                <li><a href="../bans">Заявки на разбан</a></li>
                <li><a href="../complaints">Подать жалобу</a></li>
            </ul>
        </li>
        <li>
            <p class="link" style="margin-bottom: 0px;"><a href="../support"><i class='bx bx-support'></i>Поддержка</a></p>
        </li>
    </ul>
</div>



<script>
    $(function() {
        $('.accordion li').click(function() {
            $(this).toggleClass(' active ');
            $(this).siblings().removeClass(' active ');
            $('.submenu').stop().slideUp();
            $('.active .submenu').stop().slideDown();
        });
    });
</script>