<style>
  .wapper .header {
    background: #12121b;
    margin-bottom: 42px;
    top: 20px;
    padding-right: 20px;
    padding-left: 20px;
    border-radius: 13px;
    height: 70px;
    border-bottom: 1px solid #242a4000;
}
</style>

<div class="container-fluid wapper">
  <div class="content" {points-background}>
    <div class="container">
      <div class="header">
        <!-- Письменный логотип -->
        <span class="logol">
		<a href="../">
         <img class="logo_sdg" src="../templates/DarkMound-Plus-GE/img/logo.png">
          </a>
        </span>       
		
        <!-- Кнопки действий -->
		<ul class="collapsible-menu user-menu">
          <div class="buttons_top">
          <button type="button" class="authoriz" data-toggle="modal" data-target="#authorization">
					<i class='bx bx-lock-open-alt' ></i>
					Вход
				</button>  
		<button type="button" class="zareg" data-toggle="modal" data-target="#registration">
					<i class='bx bx-user-plus'></i>
					Регистрация
				</button>    
          </div>    
        </ul>
      </div>
    </div>
    
     <!-- Модальное окно авторизации -->
        <script>
          $('#voucher').modal('hide');
        </script>
        <div id="authorization" class="modal fade">
          <div class="modal-dialog">
            <div class="modal-content" style="margin-top: 270px;">
              
              <div class="block_authorization">
        		<div class="authorization_img" style="background-image: url(../templates/DarkMound-Plus-GE/img/auth.jpg);background-size: cover;">
        		</div>

                <div class="authorization_plaza">   
                  {include file="/parts/mini-profile.tpl"}
                </div>
     		 </div>
            </div>
          </div>
        </div>
    
     <!-- Модальное окно Регистрации -->
        <script>
          $('#voucher').modal('hide');
        </script>
        <div id="registration" class="modal fade">
          <div class="modal-dialog" style="max-width: 350px;">
            <div class="modal-content" style="margin-top: 230px;">
              
              <div class="block_authorization">

                <div class="authorization_plaza">  
                  <div class="block authorization" style="padding: 15px 0px;margin-left: 0px;">
  				<!-- Заголовок -->
                  <div class="top_info_index">
                   <i class='bx bx-user' ></i>
                    <b class="pretext_index">Регистрация</b>
                  </div>
                 <form id="user_registration" class="registration">
                            <input type="text" maxlength="30" class="form-control" id="reg_login" placeholder="Логин">
                            <input type="password" maxlength="15" class="form-control" id="reg_password" placeholder="Пароль">
                            <input type="password" maxlength="15" class="form-control" id="reg_password2" placeholder="Повторите пароль">
                            <input type="email" maxlength="255" class="form-control" id="reg_email" placeholder="E-mail {if($conf->conf_us == 1)}(Указывайте настоящий e-mail!){/if}">

                            {if($conf->privacy_policy == 1)}
                                <a class="privacy-policy" href="../processing-of-personal-data" target="_blank">Регистрируясь на данном сайте, Вы выражаете согласие на обработку персональных данных</a>
                            {/if}

                           {if($conf->captcha != '2')}
						<div style="-webkit-transform: scale(1);margin-bottom: 13px;" data-theme="dark" class="g-recaptcha mb-15 clearfix" data-sitekey="{{$conf->captcha_client_key}}"></div>
						<script src='https://www.google.com/recaptcha/api.js?hl=ru'></script>
					{/if}

                            <div id="result2"></div>

                          <div class="block_auth_push">
                            <button type="submit" class="voiti">Создать аккаунт</button>
							<div class="block" style="display: flex;padding: 0px;margin-bottom: 0px;">
                            {if($auth_api->vk_api == 1)}
                                <a class="vkbut" onclick="$('#registration').modal('hide'); show_reg_modal('vk');" title="Зарегистрироваться через Вконтакте"><i class='bx bxl-vk' ></i></a>
                            {/if}
                            {if($auth_api->steam_api == 1)}
                                <a class="steambut" onclick="$('#registration').modal('hide'); show_reg_modal('steam');" title="Зарегистрироваться через Steam"><i class='bx bxl-steam' ></i></a>
                            {/if}
                            {if($auth_api->fb_api == 1)}
                                <a class="btn btn-primary" onclick="$('#registration').modal('hide'); show_reg_modal('fb');" title="Зарегистрироваться через Facebook"><i class="m-icon icon-fb"></i></a>
                            {/if}
   							 </div>
                             </div>
                        </form>
                        <script> send_form('#user_registration', 'registration();'); </script> 
                    </div>
                </div>
     		 </div>
            </div>
          </div>
        </div>
    
   
    
    
    
    
    <div id="" class="modal fade">
            <div class="modal-dialog modal-sm">
                <div class="modal-content" style="margin-top: 270px;">
                 <div class="col-lg-6 order-is-first" style="margin-left: auto;margin-right: auto;margin-top: 270px;">
					<i class='bx bx-layer-plus' style="background: #ffffff00;padding: 9px;border: dashed 1px #ffffff;color: #ffffff;font-size: 15px;border-radius: 9px;margin-right: 12px;margin-left: 3px;"></i><span style="
                      font-size: 14px;
                      font-weight: 600;
                  ">Регистрация</span>
					</div>
                    <div class="modal-header">

                    </div>
                    <div class="modal-body">
                        
                    </div>
                </div>
            </div>
        </div>

        <div id="api_auth" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                       <!-- Заголовок -->
                  <div class="top_info_index">
                   <i class='bx bx-user' ></i>
                    <b class="pretext_index">Регистрация</b>
                  </div>
                    </div>
                    <div class="modal-body">
                      

                        <input type="email" maxlength="255" class="form-control" id="api_email" placeholder="E-mail {if($conf->conf_us == 1)}(Требуется настоящий e-mail!){/if}">

                        <div id="result_api_reg"></div>
                        <button id="api_reg_btn" class="voiti" onclick="">Создать аккаунт</button>
                    </div>
                </div>
            </div>
        </div>
    
    

    <div class="container">
      <div class="row">