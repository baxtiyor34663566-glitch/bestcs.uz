</div>
</div>
<style>
  .footer-osn {
    display: none;
  }
  
  .bottom_stats {
    display: none;
}
  
  .header {
    display: none;
}
  
  body {
    background-image: url(../templates/standart/img/back_avalon_auth.jpg);
    background-size: cover;
  }
  
  .sidebar {
    display: none;
  }
  
  .footer {
    display: none;
  }
  
.toper_block2 {
    flex: 1 1 auto;
    max-height: 100%;
    width: 100%;
    padding-right: 15px;
    border-radius: 0px 0px 15px 15px;
    padding-left: 15px;
    background: #1e2638;
}
  
  .toper {
    margin-top: -90px;
    background: #6080ff00;
    margin-bottom: 40px;
    border-radius: 15px;
    margin-top: -30px;
    max-width: 800px;
    margin-left: auto;
    margin-right: auto;
    position: relative;
    top: 200px;
    display: flex;
  }
  
  @media (max-width: 1200px) {
    .toper {
      margin-top: -90px;
      background: #6080ff00;
      margin-bottom: 40px;
      border-radius: 15px;
      margin-top: -30px;
      position: relative;
      top: 0px;
      max-width: 1170px;
      display: flex;
    }
  }
</style>

<div class="container">
  
    <div class="block-aut">
<!-- Заголовок -->
                  <div class="top_info_index" style="margin: 10px 15px;">
                   <i class='bx bx-lock-open-alt' ></i>
                    <b class="pretext_index">Восстановление </b>
                  </div>
      
      <div class="toper_block2">
        {if("{message}" == "")}
		<form id="send_new_pass" class="block_pass">
			<input type="text" maxlength="255" class="form-control" id="email_2" placeholder="Введите ваш e-mail">
			<div class="captcha">
			{if($conf->captcha != '2')}
						<div style="transform:scale(1.13);-webkit-transform:scale(1.13);transform-origin:0 0;-webkit-transform-origin:0 0;" data-theme="dark" class="g-recaptcha mb-15 clearfix" data-sitekey="{{$conf->captcha_client_key}}"></div>
						<script src='https://www.google.com/recaptcha/api.js?hl=ru'></script>
					{/if}
              </div>
			<div id="result3" class="mt-1"></div>
			<button type="submit" class="voiti">Выслать новый пароль</button>
		</form>
		<script> send_form('#send_new_pass', 'send_new_pass();'); </script>
	</div>
	{else}
	<div class="noty-block info">
		{message}
	</div>
	{/if}

      </div>

  

</div>