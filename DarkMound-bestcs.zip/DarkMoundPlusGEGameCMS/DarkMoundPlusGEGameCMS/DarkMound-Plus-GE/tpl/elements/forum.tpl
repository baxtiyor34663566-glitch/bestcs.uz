<style>
	p .very-icon {
		position: absolute;
		float:right;
		background-color:transparent !important;
		width: 16px !important;
		height: 16px !important;
		margin-top: unset !important;
	}
</style>

<div class="col-lg-8">
	<img src="../{img}" alt="{name}">
	<div>
		<h3><a href="../forum/forum?id={id1}" title="{description}">{name}</a></h3>
		<p>{description}</p>
	</div>
</div>
<div class="d-none d-lg-block col-lg-4">
	{if('{msg_id}' == '')}
	<div>
		<p style="border: dashed 1px #5a6a8c;padding: 15px;text-align: center;border-radius: 10px;color:#5a6a8c;width: 100%;">Форум пуст</p>
	</div>
	{else}
	<div>
		<img src="../{msg_avatar}" alt="{msg_login}">
		<p><a style="color: #ffff" href="../forum/topic?id={msg_id}&page=last">{msg_name}</a></p>
		<p>
			<i class="fas fa-user"></i>
			<a href="../profile?id={msg_author}" style="color: #f3a45d" title="{gp_name}">{msg_login}</a>
			
		</p>
		<p>{msg_date}</p>
	</div>
	{/if}
</div>