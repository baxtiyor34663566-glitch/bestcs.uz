<div class="col-lg-6" id="{id}">
  <div class="user-full">
<div class="block_fbrs_friend" style="background-image: url(../templates/DarkMound-Plus-GE/img/profile_back.png);background-size: cover;">
         
        <div class="friend_sv">
        <a title="{login}" href="../profile?id={id}">
			<img alt="{login}" class="avatarprofile_friend" src="../{avatar}">
		</a>
          <div class="texxt">
            <p class="username_friend">{login}</p>
            <span class="lastname_friend">{gp_name}</span>
          </div>
           </div>
 <div class="buttons_friends">
            {if(is_worthy("f") && is_worthy("g"))}
		
			{if(is_worthy("f"))}
				<a class="user-button-check1" href="../edit_user?id={id}">
					<i class='bx bx-message-square-edit' ></i>
				</a>
			{/if}
			{if(is_worthy("g"))}
				<a class="user-button" href="#" onclick="dell_user('{id}')">
					<i class='bx bx-x' ></i>
				</a>
			{/if}
	
		{/if}
            </div>
   </div>
    <a class="message_button" href="../messages?create_id={id}">
			Написать сообщение
		</a>
    </div>
  
</div>