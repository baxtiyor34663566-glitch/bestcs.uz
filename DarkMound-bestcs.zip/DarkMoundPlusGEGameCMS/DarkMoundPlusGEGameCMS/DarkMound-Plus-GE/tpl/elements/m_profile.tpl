				<div>
					<a class="avatar" href="../profile?id={profile_id}">
						<img src="../{avatar}">
					</a>
					<div>
						<span>
							{login}
						</span>
						<span style="color: {group_color}">{group}</span>
					</div>
					{if(is_auth() && '{profile_id}' == $_SESSION['id'])}
					<a href="../settings" tooltip="yes" title="Настройки профиля">
						<i class="far fa-cog"></i>
					</a>
					{/if}
					
					<div id="result_profile"></div>
				</div>