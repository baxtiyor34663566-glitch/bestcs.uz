<a target="_blank" href="../profile?id={user_id}" tooltip="yes">
    <div class="visit_users_online1">
      <div style="display: flex;align-items: center;">
        <img src="../{avatar}" alt="{login}" class="last_online">
            <div class="block_visit">
                <span class="login_visit">{login}</span>
                <span class="gp_visit">{gp_name}</span>
            </div>
      </div>
      	<i class="bx bx-chevron-left" style="transform: rotate(180deg);color: #777b88;font-size: 18px;"></i>
    </div>
</a>