<a href="../profile?id={user_id}" class="top_donators">

  <div style="display: flex;align-items: center;justify-content: space-between;">
    <div style="display: flex;align-items: center;">
    <img src="../{avatar}" alt="{login}" style="height: 34px;width: 34px;border-radius: 8px;transition: .3s all;position: relative;">
 	<span style="display: flex;flex-direction: column;line-height: 13px;margin-left: 10px; ">
	<span style="color: #ffff; font-size: 11.2px;" tooltip="yes">{login}</span>
 	<span style="color: #9b93ad; font-size: 10.5px;" tooltip="yes">{gp_name}</span>
   </span>
  </div>
    	{if('{showSum}' == '1')}
		<span class="summa_donators">{sum}</span>
	{else}
	{/if}
    </div>
</a>

