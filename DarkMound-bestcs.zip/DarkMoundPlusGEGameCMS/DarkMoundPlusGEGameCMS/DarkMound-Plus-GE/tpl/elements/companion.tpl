<div class="block" style="padding-top: 0px;padding-bottom: 0px;margin-bottom: -7px;">
<a onclick="create_dialog('{id}');">
	<img src="../{avatar}" alt="{login}">
  <div style="display: flex;flex-direction: column;position: relative;top: 6px;">
		<span class="login_donator">{login}</span>
		<span style="font-size: 11px;">Написать сообщение</span>
  </div>
</a>
</div>