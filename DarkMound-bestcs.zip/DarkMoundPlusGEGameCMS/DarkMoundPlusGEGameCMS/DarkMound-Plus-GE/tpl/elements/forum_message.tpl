<div id="answer_{id}">
	<div class="left-side">
              
               <div class="block_fbrs_forum" style="background-image: url(../templates/DarkMound-Plus-GE/img/profile_back.png);background-size: cover;">
          <div style="display: flex;align-items: center;">
            <a href="../profile?id={author}">
		<img src="../{avatar}" alt="{login}" class="avatarprofile">
            </a>
          <div class="text_forum">
            <p class="username">{login}</p>
            <span class="lastname">{gp_name}</span>
          </div>
                 </div>
                 <button class="answer_forum" onclick="answer({id}, '{login}', '{link}');">
						<i class='bx bx-share'></i>
					</button>
                 </div>
              
				<div style="display: flex;flex-direction: column;">
				<span class="forum_profile_reaction">
                  <i class='bx bx-heart' ></i> 
                  <div class="reaction_block">
                  Реакций 
                  <b style="color: #ffff;">{thanks}</b>
                  </div>
				</span>
                  
				<span class="forum_profile_reaction">
                  <i class='bx bx-message-square-detail' ></i>
                  <div class="reaction_block">
                  Ответов 
                  <b style="color: #ffff;">{answers}</b>
                  </div>
				</span>
                  
				<span class="forum_profile_reaction">
                  <i class='bx bx-star' ></i> 
                  <div class="reaction_block">
                  Рейтинг 
                  <b style="color: #ffff;">{reit}</b>
                  </div>
				</span>
                  </div>
              
              <div style="display: flex;margin-top: 7px;justify-content: space-between;">
              {if('{author_id}' != '{my_id}')}
					<button class="like_forum" onclick="thank({id}, 0);">
						Поблагодарить
					</button>
					{/if}
			</div>
              
			</div>

	<div class="right-side">
      <div class="likes-area">

			{if(is_worthy("r"))}
			<button class="forum_delete" onclick="dell_answer('{id}');">
				<i class="far fa-trash"></i>
			</button>
			{/if}
			{if((is_worthy("r")) || (is_auth() && ('{author_id}' == '{my_id}') and ('1' == '{check}')))}
			<a class="forum_delete"  href="../forum/edit_message?id={topic_id}&id2={id}">
				<i class="far fa-pencil"></i>
			</a>
			{/if}
		</div>
		
          <span class="date_forum">{date}</span>

		<div id="text_{id}" class="with_code">
          {if('{edited_by_id}' != '')}<span class="editeds" style="color: #576178;font-weight: 600;margin-bottom: 20px;">Отредактировал: <a href="../profile?id={edited_by_id}" title="{edited_by_login}">{edited_by_login}</a>, {edited_time}</span>{/if}
			{text}
		</div>

		{if('{signature}' != '')}
		<div class="with_code signature">
			{signature}
		</div>
		{/if}

		<div class="clearfix"></div>
		{mess_thanks}
	</div>
</div>