<tr class="mt--1 v-m">
	<td>
		<button onclick="setTheAccused({id}, this);" class="button_player1">
           Выбрать
		</button>
	</td>
	<td>
        {if('{user_id}' == '0')}
			<a href="#">
				<img class="small_us_av" src="../files/avatars/no_avatar.jpg" alt="Неизвестно"> Неизвестно
			</a>
        {else}
			<a target="_blank" href="../profile?id={user_id}" title="{gp_name}">
				<img class="small_us_av" src="../{avatar}" alt="{login}"> <span style="color: {gp_color}">{login}</span>
			</a>
        {/if}
	</td>
	<td>
        {name}
	</td>
	<td>
		<a href="#" onclick="get_admin_info2({id});" data-target="#modal{id}" data-toggle="modal" title="Подробнее">
			{services}
		</a>
	</td>
</tr>
<tr class="hidden-tr" style="
    background: #fff0;
    height: 0px;
">
	<td>
		<div id="modal{id}" class="modal fade">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header">
						 <!-- Заголовок -->
                <div class="top_info">
                  <i class='bx bx-star' ></i>
                  <b class="pretext">Услуги</b>
                </div>
					</div>
					<div class="modal-body">
						<div class="table-responsive mb-0">
							<table class="table table-bordered">
								<thead>
								<tr>
									<td>#</td>
									<td>Услуга</td>
									<td>Дата покупки</td>
									<td>Дата окончания</td>
									<td>Осталось</td>
								</tr>
								</thead>
								<tbody id="admin_info{id}">
								<tr>
									<td colspan="10">
										<div class="loader"></div>
									</td>
								</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</td>
</tr>