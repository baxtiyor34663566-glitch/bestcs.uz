<div class="container" style="
    padding-right: 0px;
    padding-left: 0px;
">
	<div class="user">
		<a href="../profile?id={id}" title="{login}">
			<img src="{avatar}" alt="{login}">
		</a>
      <div style="
    width: 200px;
">
		<a href="../profile?id={id}" title="{login}">
          <b class="name_friend" style="color: #ffff;">{login}</b>
		</a><br>
        <span style="color: #5b6276;font-weight: 600;">
			{gp_name}
		</span>
        </div>
		<a class="chat-button" href="../messages?create_id={id}">
			<i class='bx bx-message-square-detail' ></i>
		</a>
        
	</div>
</div>