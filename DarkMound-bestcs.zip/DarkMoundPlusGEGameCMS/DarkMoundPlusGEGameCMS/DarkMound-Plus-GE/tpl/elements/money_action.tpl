

<tr>
  	<td>
	{if('{shilings}' > '0')}
		<span class="status_purse_plus"><i class='bx bx-plus' ></i></span>
	{else}
		<span class="status_purse_minus"><i class='bx bx-minus' ></i></span>
	{/if}
	</td>
	<td>
	{if('{shilings}' > '0')}
		<span class="text-success-custom">{shilings} ₽</span>
	{else}
		<span class="text-success-custom">{shilings} ₽</span>
	{/if}
	</td>
	<td><span class="text-danger-custom">{type}</span></td>
	<td><span class="text-danger-custom">{date}</span></td>
</tr>