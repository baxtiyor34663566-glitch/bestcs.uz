<a href="../profile?id={id}">
	<img src="../{avatar}" alt="{login}">
	<div style="
    display: flex;
    justify-content: space-between;
    align-items: center;
">
      <span style="
    display: flex;
    flex-direction: column;
">
		<span style="color: #ffff; font-size: 11.2px;" tooltip="yes">{login}</span>
     	 <span style="color: #6e7a91; font-size: 10.5px;" tooltip="yes">{gp_name}</span>
        </span>
		<p>
          <span title="Рейтинг" tooltip="yes"><i class='bx bxs-trophy'></i> {reit}</span>
		</p>
	</div>
</a>