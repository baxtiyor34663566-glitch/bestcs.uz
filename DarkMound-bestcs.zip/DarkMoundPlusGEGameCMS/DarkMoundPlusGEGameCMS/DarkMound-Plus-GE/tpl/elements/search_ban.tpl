<div class="table-responsive mb-0">
  
	<table class="table table-bordered baninfo">
		<tr style="background: #fff0;">
			 <div class="profile-block-info" style="margin-top: 20px;">
                              <span class="icon-names"><i class="bx bx-fingerprint"></i></span>
                              <span class="opis" style="color: #5a6a8c;">ID Блокировки</span>
                              <p class="name" style="color: #ffff;">{bid}</p>
               				</div>
		</tr>
		<tr style="background: #fff0;">
			<div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-map-pin"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Ip Забаненного</span>
                              <p class="name" style="color: #ffff;">{player_ip}</p>
               		</div>
		</tr>
		<tr style="background: #fff0;">
			<div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-card"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Steam ID забаненного</span>
                              <p class="name" style="color: #ffff;">{player_id}</p>
               				</div>
		</tr>
		<tr style="background: #fff0;">
			 <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-joystick"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Игровой ник</span>
                              <p class="name" style="color: #ffff;">{player_nick}</p>
               				</div>
		</tr>
		<tr style="background: #fff0;">
			<div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-user-circle"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Администратор</span>
                              <p class="name" style="color: #ffff;">{admin_nick}</p>
               				</div>
		</tr>
		<tr style="background: #fff0;">
		<tr style="background: #fff0;">
			 <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-info-circle"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Причина</span>
                              <p class="name" style="color: #ffff;">{ban_reason}</p>
               				</div>
		</tr>
		<tr style="background: #fff0;">
			 <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-timer"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Дата окончания</span>
                              <p class="name" style="color: #ffff;">{time}</p>
               				</div>
		</tr>
		<tr style="background: #fff0;">
			<div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-label"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Срок блокировки</span>
                              <p class="name" style="color: #ffff;">{ban_length}</p>
               				</div>
		</tr>
		<tr style="background: #fff0;">
           <div class="profile-block-info" style="height: 80px;">
                              <span class="icon-names"><i class="bx bx-map-pin"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Сервер</span>
                              <p class="name" style="color: #ffff;">{server_name} - {address}</p>
               				</div>
		</tr>
	</table>
</div>