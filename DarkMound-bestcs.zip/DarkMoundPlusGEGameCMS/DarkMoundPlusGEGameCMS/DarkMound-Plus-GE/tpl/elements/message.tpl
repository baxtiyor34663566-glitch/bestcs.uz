<div class="chat_message" id="mess_{id}">
	<div class="message">
		      <a href="../profile?id={user_id1}"> 
        <img src="{avatar}" alt="{login}" class="chat_img">
      </a>	
		<div id="message_text_{id}" class="with_code" style="margin-top: 0px;">
          <div> 
            <a href="../profile?id={user_id}">
              <b class="author">{login}</b>
            </a> 
          </div>
          {text}
           <span tooltip="yes" title="{date_full}" class="chat_date">{date_short}</span>
         <img class="fire" src="../templates/DarkMound-Plus-GE/img/chat_arrow.png" style="left: 29.5px;bottom: 1.1px;">
		</div>
	</div>
	<div class="clearfix"></div>
</div>