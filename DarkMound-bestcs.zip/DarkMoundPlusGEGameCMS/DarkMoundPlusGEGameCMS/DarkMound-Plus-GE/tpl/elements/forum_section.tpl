<div class="block" id="section_{id}">
	<div class="block_head">
		Настройка раздела
	</div>
	<form id="section_settings{id}">
		<div class="form-group">
			<b>Название</b>
			<input name="section_name" id="section_name{id}" type="text" class="form-control" value="{name}">
		</div>

		<div class="form-group">
			<span style="margin-bottom: -16px;display: block;font-weight: 600;">
				Доступ
			</span>
			<div class="btn-group-toggle" data-toggle="buttons" id="access{id}">
				{groups}
			</div>
		</div>

		<button type="button" class="btn btn-primary btn-sm" onclick="edit_section('{id}');">
			Изменить
		</button>
		<button type="button" class="btn btn-primary btn-sm" onclick="dell_section('{id}');">
			Удалить
		</button>
		<button type="button" class="btn btn-primary btn-sm" onclick="up_section('{id}');">
			<span class="m-icon icon-up"></span>
		</button>
		<button type="button" class="btn btn-primary btn-sm" onclick="down_section('{id}');">
			<span class="m-icon icon-down"></span>
		</button>
	</form>

	<div class="block_head mt-4">
		Настройка форумов
	</div>
	<div class="table-responsive mb-0">
		<table class="table table-bordered">
			<thead>
				<tr style="background: #293754;">
					<td colspan="2" style="padding-top: 15px;">Изображение</td>
					<td style="padding-top: 15px;">Название</td>
					<td style="padding-top: 15px;">Описание</td>
					<td width="10%" style="padding-top: 15px;">Порядок</td>
					<td width="10%" style="padding-top: 15px;">Действие</td>
				</tr>
			</thead>
			<tbody id="forums{id}">
				<tr>
					<td colspan="10">
						<div class="loader"></div>
						<script>load_forums('{id}');</script>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>