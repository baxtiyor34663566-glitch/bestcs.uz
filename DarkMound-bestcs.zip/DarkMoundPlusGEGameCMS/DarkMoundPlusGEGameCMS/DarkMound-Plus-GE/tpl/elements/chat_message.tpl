<div class="chat_message" id="message_id_{id}">
	<div class="message">
		<div class="info">		  
			{if(strripos("{gp_rights}", "d") !== false)}
				<span onclick="dell_chat_message('{id}');" tooltip="yes" data-placement="left" class="bx bx-trash" style="font-size: 13px;"></span>
			{/if}
		</div>
      <a href="../profile?id={user_id}"> 
        <!-- Уберите этот комментарий, чтобы шапочки заработали 
       <img src="../templates/DarkMound-Plus-GE/img/santa-hat.png" style="width: 30px;position: absolute;z-index: 1;bottom: 19px;left: -8px;transform: rotate(359deg);">
		-->
        <img src="{avatar}" title="{gp_name}"alt="{login}" class="chat_img">
      </a>	
		<div id="message_text_{id}" class="with_code">
          <div> 
              <b class="author" onclick="treatment('{login}');">{login}</b>
      
          </div>
          {text}
           <span tooltip="yes" title="{date_full}" class="chat_date">{date_short}</span>
          <img class="fire" src="../templates/DarkMound-Plus-GE/img/chat_arrow.png" style="width: 21px;">
		</div>
		{if(strripos("{gp_rights}", "d") !== false)}
			<textarea id="message_text_e_{id}" class="form-control disp-n">{text}</textarea>
		{/if}
            
	</div>
	<div class="clearfix"></div>
</div>