<div class="block">
	<div class="head-forum">
		<!-- Заголовок -->
                  <div class="top_info_profile">
                  <i class='bx bx-collection'></i>
                    <b class="pretext_profile">{name}</b>
                  </div>
	</div>
	<div class="row">
		{content}
	</div>
</div>