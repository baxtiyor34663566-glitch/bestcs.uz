<div id="{server_id}" class="block">
	<div class="block_head">
		<i class="bx bx-server" style="
    background: #2c3a58;
    width: 34px;
    height: 34px;
    display: flex;
    color: #5a6a8c;
    margin-right: 10px;
    font-size: 15px;
    border-radius: 8px;
    justify-content: center;
    align-items: center;
"></i> {server_name}
	</div>

	<div class="table-adaptive table-fused" style="padding: 0px 15px;">
		{admins}
	</div>
</div>