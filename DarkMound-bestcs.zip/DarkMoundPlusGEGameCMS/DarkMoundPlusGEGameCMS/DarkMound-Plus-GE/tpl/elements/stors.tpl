<div class="col-lg-3 order-is-last">
	{include file="/parts/mini-profile.tpl"}
</div>