<?
	$ServerCommands = new ServerCommands();
	$commands = $ServerCommands->getServerManagementCommands('{id}');

	foreach($commands as $command) {
		$command->params = json_encode($ServerCommands->getCommandParams($command->id));
	}
?>
	<div class="servers-block">  
		<div class="servers-info-block">
          <div class="servers-online-block" data-toggle="modal" data-target="#server{id}" onclick="get_players({id});">
          <span class="servers-online-now">{now}</span>
     		 <div class="progress servers-online-line">
				<div class="progress-bar bg-{color}" role="progressbar" style="width: {percentage}%;" aria-valuenow="{percentage}" aria-valuemin="0" aria-valuemax="100"></div>
			 </div>
    	</div>
          <span class="servers-info-span">
             <b style="color: #ffff;">{name}</b>
            <p style="color: #797689;">{address} <b style="margin-left: 7px;font-size: 9px;position: relative;top: -1px;">|</b> <b style="margin-left: 7px;">{map_name}</b></p>
          </span>
          <div class="button_servers">
          	<a href="steam://connect/{address}" title="Подключиться к серверу">
          	   <i class='bx bx-play' ></i>
            </a> 
           
           {if('{rcon}' == '1' && count($commands) > 0 && is_auth() && is_worthy_specifically("v", {id}))}
				<span data-toggle="modal" data-target="#server-management-modal{id}">
					<i class='bx bx-cog'></i>
				</span>

				<div class="modal fade" id="server-management-modal{id}">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<!-- Заголовок -->
                <div class="top_info">
                  <i class='bx bx-cog' ></i>
                  <b class="pretext">Управление сервером</b>
                </div>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">×</span>
								</button>
							</div>
							<div class="modal-body">
								<div class="input-group input-group-sm">
									<div class="input-group-prepend">
										<button
												class="button_player"
												type="button"
												onclick='doRconCommandOnServer(
														$("#server-management-command-id{id}").val(),
														$("#server-management-command-id{id} option:selected").attr("data-command-params"),
														{id}
												);'
										>
											Выполнить
										</button>
									</div>
									<select id="server-management-command-id{id}" class="form-control" style="position: relative;top: 0px;margin-left: 3px;color: #fff;">
										{for($l = 0; $l < count($commands); $l++)}
											<option value="{{$commands[$l]->id}}" data-command-params='{{$commands[$l]->params}}'>
												{{$commands[$l]->title}}
											</option>
										{/for}
									</select>
								</div>

								<pre class="mt-3" id="server-management-command-sending-result{id}" style="display: none"></pre>
							</div>
						</div>
					</div>
				</div>
			{/if}
            
          </div>
    	</div>
      
      </div>

	{if({i} > $countOfServersDisplayed && $countOfServersDisplayed != 0)}
			<script>
				if(!$("tr").is("#show_all_servers")) {
					$("#servers").append("<tr style='cursor: pointer;' onclick=\"$('#servers tr').each(function(){$(this).fadeIn();});$('#show_all_servers').fadeOut();\" id='show_all_servers'><td colspan='10'>Отобразить все сервера</td></tr>");
				}
			</script>
	{/if}

	<tr style="display: none;">
		<td>
			<div class="modal fade" id="server{id}">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="modal-header">
							<!-- Заголовок -->
                <div class="top_info" style="margin-bottom: 5px;">
                  <i class='bx bx-cast' ></i>
                  <b class="pretext">Онлайн игроки</b>
                </div>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						</div>
                      
						<div class="modal-body">
                          <div class="player_servers">
							<div class="table-responsive mb-0">
								<table class="table table-bordered">
									<thead>
								<tr style="background: #2f2f42;">
									<td>#</td>
									<td>Ник</td>
									<td>Убийств</td>
									<td>Время</td>
                                     {if('{rcon}' == '1' && is_auth() && is_worthy_specifically("s", {id}))}
									<td>Действие</td>
                                  {/if}
								</tr>
							</thead>
									<tbody id="server-players{id}">
									<tr>
										<td colspan="10">
											<div class="loader"></div>
										</td>
									</tr>
									</tbody>
								</table>
							</div>
                            </div>
						</div>
					</div>
				</div>
			</div>
		</td>
		<td>
			
			{if('{rcon}' == '1' && count($commands) > 0 && is_auth() && is_worthy_specifically("v", {id}))}
				<span class="settings" data-toggle="modal" data-target="#server-management-modal{id}">
					<i class="fas fa-cog"></i>
				</span>

				<div class="modal fade" id="server-management-modal{id}">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<h4 class="modal-title">Управление сервером</h4>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">×</span>
								</button>
							</div>
							<div class="modal-body">
								<div class="input-group input-group-sm">
									<div class="input-group-prepend">
										<button class="btn btn-outline-primary" type="button" onclick='doRconCommandOnServer($("#server-management-command-id{id}").val(), $("#server-management-command-id{id} option:selected").attr("data-command-params"), {id});'>
											Выполнить
										</button>
									</div>
									<select id="server-management-command-id{id}" class="form-control">
										{for($l = 0; $l < count($commands); $l++)}
											<option value="{{$commands[$l]->id}}" data-command-params='{{$commands[$l]->params}}'>
												{{$commands[$l]->title}}
											</option>
										{/for}
									</select>
								</div>

								<pre class="mt-3" id="server-management-command-sending-result{id}" style="display: none"></pre>
							</div>
						</div>
					</div>
				</div>
			{/if}	
		</td>
	</tr>