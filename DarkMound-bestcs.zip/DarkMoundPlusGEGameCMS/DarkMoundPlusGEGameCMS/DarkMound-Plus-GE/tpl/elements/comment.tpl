<div class="comment" id="message_id_{id}">
	<a href="../profile?id={user_id}" title="{login}">
		<img src="../{avatar}" alt="{login}">
	</a>
	<div class="message">
		<div class="info">
			<div class="author">
				<a title="Группа: {gp_name}" style="color: #ffffff;font-weight: 600;font-size: 13px;font-family: 'Montserrat';" onclick="treatment_comment('{login}')" >{login}</a>
			<span tooltip="yes" title="{date_full}, {date_short}" style="
    font-size: 10px;
    margin-left: 7px;
    font-family: 'Montserrat';
    font-weight: 600;
    color: #60677e;
">{date_short}</span>
          </div>
          <b>{dell}</b>
		</div>
		<div class="with_code">
			{text}
		</div>
	</div>
</div>
<div class="clearfix"></div>