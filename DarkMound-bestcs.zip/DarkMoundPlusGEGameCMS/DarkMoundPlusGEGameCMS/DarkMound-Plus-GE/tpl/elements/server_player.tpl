<tr>
  <td><b class="number_player">{i}</b></td>
    <td class="name_players">{name}</td>
    <td>{frags}</td>
    <td>{time}</td>
    {if('{server_rcon}' == '1' && is_auth() && is_worthy_specifically("s", '{server_id}'))}
        <td>
            {if(count($commands) == 0)}
                Комманд нет
            {else}
                <div class="input-group" style="min-width: 250px;">
                   <span class="input-group-btn">
                       <button
                               class="button_player"
                               type="button"
                               onclick='doRconCommandOnPlayer(
                                       $("#action-on-player-command-id{server_id}-{i}").val(),
                                       $("#action-on-player-command-id{server_id}-{i} option:selected").attr("data-command-params"),
                               {coded_nick},
                               {server_id}
                                       );'
                       >
                           Выполнить
                       </button>
                   </span>
                    <span class="input-group-btn w-100">
                        <select id="action-on-player-command-id{server_id}-{i}" class="form-control">
                            {for($l = 0; $l < count($commands); $l++)}
                                <option value="{{$commands[$l]->id}}" data-command-params='{{$commands[$l]->params}}'>
                                    {{$commands[$l]->title}}
                                </option>
                            {/for}
                        </select>
                    </span>
                </div>
            {/if}
        </td>
    {/if}
</tr>