<div class="col-lg-6" id="{id}">
	<div class="user-full">
      <div class="block_fbrs_friend" style="background-image: url(../templates/DarkMound-Plus-GE/img/profile_back.png);background-size: cover;">
         
        <div class="friend_sv">
        <a title="{login}" href="../profile?id={id}">
			<img alt="{login}" class="avatarprofile_friend" src="../{avatar}">
		</a>
          <div class="texxt">
            <p class="username_friend">{login}</p>
            <span class="lastname_friend">{gp_name}</span>
          </div>
           </div>
        
        {if('{type}' == '3')}
		<div class="buttons_friends">
          {if('{type}' == '2')}
		
			
				<a class="user-button" href="#" onclick="cancel_friend('{id}'),dell_block('{id}')" style="width: 300px;">
					Отменить заявку
				</a>

		{/if}
				<a class="user-button-check" href="#" onclick="take_friend('{id}'), dell_block('{id}'), load_col_infriends()">
					<i class='bx bx-check' ></i>
				</a>
				<a class="user-button" href="#" onclick="reject_friend('{id}'), dell_block('{id}'), load_col_infriends()">
					<i class='bx bx-x' ></i>
				</a>

		</div>
		{/if}
         </div>
		
		<a class="message_button" href="../messages?create_id={id}">
			Написать сообщение
		</a>
	</div>

		

	
</div>