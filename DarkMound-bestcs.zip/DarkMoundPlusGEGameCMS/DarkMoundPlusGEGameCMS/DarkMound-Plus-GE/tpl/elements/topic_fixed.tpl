{if('{title}' != '1')}
<div class="col-lg-9">
	<h3>
		<a href="../forum/topic?id={id}" title="{name}">{name}</a>
      <i class="far fa-paperclip" tooltip="yes" title="Тема закреплена"></i>
		{if('{status}' == '2' || '{status}' == '4')}
		<i class="far fa-lock" tooltip="yes" title="Тема закрыта"></i>
		{/if}
	</h3>
	<p style="position: relative;top: -5px;">
		<span tooltip="yes" title="Автор темы">
			<b style="margin-left: 3px;">От <a href="../profile?id={topic_author}" style="color: {topic_user_gp_color}" title="{topic_user_gp_name}">{topic_login}</a> в {name}</b>
		</span>
	</p>
    <div class="forum_info_answer">
  <span tooltip="yes" style="color: #ffff;font-size: 11px;font-weight: 600;">{answers} Ответов</span>
  <span tooltip="yes" style="font-size: 11px;font-weight: 600;color: #777b88;">{views} Просмотров</span>
  </div>
</div>
<div class="d-none d-lg-block col-lg-3">
	<div>
		{if('{last_msg}' == '')}
		<p style="border: dashed 1px #777b88;padding: 15px;text-align: center;border-radius: 10px;color: #777b88;width: 100%;">Сообщений нет</p>
		{else}
		<img src="../{msg_avatar}" alt="{msg_login}">
      	<span> 
		<p>
			<a href="../profile?id={msg_author}" style="color: {topic_user_gp_color}" title="{msg_user_gp_name}">{msg_login}</a>
		</p>
		<p>{date}</p>
        </span>
		{/if}
	</div>
</div>
{/if}