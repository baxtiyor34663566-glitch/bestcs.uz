<div class="event" id="event{id}" style="
    background-image: url(../templates/DarkMound-Plus-GE/img/znak.png);
    background-size: cover;
">
  <img src="../{avatar}" class="avatar_event">
	<div>
      <div class="evetn_content">{content}</div>
      <b style="
    font-size: 10px;
    margin-top: 5px;
">{date}</b>
	</div>
	<a href="../{link}">
		<i class="bx bx-chevron-right"></i>
	</a>
	{if(is_worthy("d"))}
		<i class="m-icon icon-remove" onclick="dell_event({id})" tooltip="yes" data-placement="left" title="Удалить уведомление"></i>
	{/if}
</div>