<div class="noty-block {class}" id="{id}" style="display: flex;flex-direction: row;margin-top: 18px;">
  <i class="m-icon icon-remove" onclick="{function}({id})"></i>
  <div class="logo_notifications">
  <i class='bx bx-message-square-detail' ></i>
  </div>
    <div class="notification_collapse">
			<b style="color: #8181a0;">{text}</b>
            <div class="date-not">
          {date}
      </div>
    </div>
</div>