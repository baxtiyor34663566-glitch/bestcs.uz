<div class="col-lg-6">
	<div>
		<div class="news-block-index" style="background-image: url(../templates/DarkMound-Plus-GE/img/news_news.png);background-size: cover;">
          <div class="news-block-img" style="background-image: url(../{img});background-size: cover;">
            <span class="views_news" title="Просмотры">{views}</span>
          </div>  
          <div class="news-block">
			<div>
            <div class="name_date_news">
			<a href="../news/new?id={id}">
				<h3 style="font-size: 17px;font-weight: 600;text-overflow: ellipsis;width: 200px;overflow: hidden;white-space: nowrap;color: #ffff;">{name}</h3>
              </a>
             <span class="text_info_news"><i class='bx bx-time' ></i> {date}</span>
              </div>
			<font style="font-size: 10.5px;font-weight: 600;color: #6f6f8c;">{short_text}</font>
          </div>
		<a href="../news/new?id={id}">
          <div class="news-button-bottom">Открыть новость</div>
		</a>
            </div>
		</div>
	</div>
</div>