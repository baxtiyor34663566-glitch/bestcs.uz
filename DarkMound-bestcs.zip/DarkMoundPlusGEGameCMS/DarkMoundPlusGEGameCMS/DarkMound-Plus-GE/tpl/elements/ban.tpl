<div class="table-row" id="bid{bid}">
	<div class="row" data-target="#ban{bid}" data-toggle="modal" title="Подробнее">
		<div class="col-lg-3 with-description">
			<p>
				{player_nick}
			</p>
			<span>Игрок</span>
		</div>
		<div class="col-lg-3 with-description with-icon">
			<i class="far fa-exclamation-circle"></i>
			<p>
				{ban_reason}
			</p>
			<span>Причина</span>
		</div>
		<div class="col-lg-3 with-description with-icon">
			<i class="far fa-calendar-alt"></i>
			<p id="ban_end{bid}" class="text-{class}">
				{time}
			</p>
			<span>Окончание</span>
		</div>
		<div class="col-lg-3 with-description">
			<p class="area-user">
				{admin_nick}
			</p>
			<span>Админ</span>
		</div>
	</div>
	<div id="ban{bid}" class="modal fade">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				
					<div class="modal-header">
					  <!-- Заголовок -->
                <div class="top_info">
                  <i class='bx bx-error-alt' ></i>
                  <b class="pretext">Подробная информация</b>
                </div>
				</div>
          
				<div class="modal-body" id="baninfo{bid}">
                   <div class="block" style="padding: 0px;">
              {if('{price}' != '0')}
									<button class="bottom-button" onclick="buy_unban({bid},{server});" title="Купить разбан за {price} руб">
										Разбан - {price}₽
									</button>
									{/if}
									<button class="bottom-button {disp2}" onclick="close_ban2('{server}','{bid}');" id="unban_btn{bid}">
										Разбанить
									</button>
                    
                </div>
                 
                  <div class="modal-bans">
                  <div class="col-lg-6">
                          <b style="font-size: 13px;position: relative;top: -10px;">Общая информация</b>
                          <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-fingerprint"></i></span>
                              <span class="opis" style="color: #5a6a8c;">ID Блокировки</span>
                              <p class="name">{bid}</p>
               				</div>
                    
                    {if(is_worthy("j"))}
                    <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-map-pin"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Ip Забаненного</span>
                              <p class="name">{player_ip}</p>
               		</div>
                      {/if}		
                    
                    <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-card"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Steam ID забаненного</span>
                              <p class="name">{player_id}</p>
               				</div>
                    
                    <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-joystick"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Игровой ник</span>
                              <p class="name">{player_nick}</p>
               				</div>
                    
                    <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-user-circle"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Администратор</span>
                              <p class="name">{admin_nick}</p>
               				</div>
                    
                     {if('{ban_closed}' != '')}
								<div class="profile-block-info" id="ban_closed{bid}">
                                  <span class="icon-names"><i class='bx bx-lock-open-alt' ></i></span>
                                  <span class="opis">Блокировку снял</span>
									<p class="name">
										{ban_closed}
									</p>
								</div>
								{/if}
						</div>
                  
                  <div class="col-lg-6">
                    <b style="font-size: 13px;position: relative;top: -10px;">Подробности</b>
                   <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-info-circle"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Причина</span>
                              <p class="name">{ban_reason}</p>
               				</div>
                    
                     <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-time"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Дата блокировки</span>
                              <p class="name">{ban_created}</p>
               				</div>
                    
                    <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-timer"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Дата окончания</span>
                              <p class="name">{if(is_worthy_specifically("s", {server}))}
									<input style="padding: 0px;height: 10px;margin-left: 42px;border-radius: 0px;position: relative;background: #2e374c00 !important;border: 1px solid #2e374c00;top: -10px;" onclick="$('.ui-datepicker-current').attr('onclick', 'set_admin_date_forever({bid}, \'#ban_end_input{bid}\')');$('.ui-datepicker-current2').attr('onclick', 'change_ban_end({bid}, {server});');" class="form-control" type="text" id="ban_end_input{bid}" value="{ban_end}">
									<script>
										$('#ban_end_input{bid}').datetimepicker({
											timeInput: true,
											timeFormat: "HH:mm",
											onSelect: function () {
												setTimeout(function () {
													$('.ui-datepicker-current').attr('onclick', 'set_admin_date_forever({bid}, \'#ban_end_input{bid}\')');
													$('.ui-datepicker-current2').attr('onclick', 'change_ban_end({bid}, {server});');
												}, 500);
											}
										});
									</script>
									{else}
									<p class="text-{class}" id="ban_end_full{bid}">{time}</p>
									{/if}</p>
               				</div>
                  
                    <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-label"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Срок блокировки</span>
                              <p class="name">{ban_length}</p>
               				</div>
                  
                  <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-map-pin"></i></span>
                              <span class="opis" style="color: #5a6a8c;">IP сервера</span>
                              <p class="name">{address}</p>
               				</div>
                  </div>
                  </div>
					
				</div>
			</div>
		</div>
	</div>
</div>