<div class="table-row" id="sid{id}">
	<div class="row" data-target="#modal{id}" data-toggle="modal" {if('{army_enable}' == '2')}onclick="load_wstats({id},{server},'{authid}');load_mstats({id},{server},'{authid}');"{/if} >
		<div class="col-lg-2 with-description">
			<p>
				{place}
			</p>
			<span>Место</span>
		</div>
		<div class="col-lg-4">
			<div class="area-user">
				{nick}
			</div>
		</div>
		<div class="col-lg-2 with-description with-icon">
			<i class="far fa-skull"></i>
			<p>
				{frags}
			</p>
			<span>Убийств</span>
		</div>
		<div class="col-lg-2 with-description with-icon">
			<i class="far fa-tombstone"></i>
			<p>
				{deaths}
			</p>
			<span>Смертей</span>
		</div>

		{if(in_array({type}, array(1,2,3,4,5)))}
			{if(in_array({type}, array(1,2,3)))}
				{if('{type}' == '2')}
					<div class="col-lg-1 with-description">
						<p>
							{rank}
						</p>
						<span>Ранг</span>
					</div>
				{/if}
				<div class="col-lg-1">
					<div class="area-label">
						<span class="label label-{skill_color}">{skill_name} ({skill})</span>
					</div>
				</div>
			{else}
				<div class="col-lg-2 with-description">
					<p>
						{skill}
					</p>
					<span>Скилл</span>
				</div>
			{/if}
		{else}
			{if('{type}' == '6')}
				<div class="col-lg-2">
					<div class="area-image">
						<img src="{rank_img}" alt="{rank_name}" title="{rank_name}" class="rank">
					</div>
				</div>
			{/if}
		{/if}
	</div>

	<div id="modal{id}" class="modal fade">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					  <!-- Заголовок -->
                <div class="top_info">
                  <i class='bx bx-error-alt' ></i>
                  <b class="pretext">Подробная информация</b>
                </div>
				</div>
				<div class="modal-body" id="statinfo{id}">
					<div class="row">
						{if(is_worthy_specifically("h", {server}) || '{reset_stats}' == '1')}
						<div class="col-lg-12">
						<div class="block" style="padding: 0px;margin-bottom: 15px;">										
											{if('{reset_stats}' == '1')}
											<button class="bottom-button" onclick="reset_stats({id}, {server})">Обнулить - {reset_stats_price}₽</button>
											{/if}
											{if(is_worthy_specifically("h", {server}))}
											<button class="bottom-button" onclick="dell_user_stats({id}, {server})">Удалить</button>
											{/if}
									
                          </div>
							<div class="table-responsive">
								<table class="table table-bordered">
									<tbody>
									
									</tbody>
								</table>
							</div>
						</div>
						{/if}
						<div class="col-lg-6">
                          <b style="font-size: 13px;position: relative;top: -10px;">Общая информация</b>
                          <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-map-pin"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Место в статистике</span>
                              <p class="name">{place}</p>
               				</div>
                          
                          <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-joystick"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Игровой ник</span>
                              <p class="name">{nick}</p>
               				</div>
                          
                          {if(in_array({type}, array(1,2,3,5,6)))}
									{if(is_worthy_specifically("h", {server}))}
                          <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-card"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Steam ID</span>
                              <p class="name">{authid}</p>
               				</div>
                          {/if}
							{/if}
                          
                         
                          <div class="profile-block-info">
                              <span class="icon-names"><i class="far fa-skull" style="font-size: 14px;"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Убийств</span>
                              <p class="name">{frags}</p>
               				</div>
                          
                           <div class="profile-block-info">
                              <span class="icon-names"><i class="far fa-tombstone" style="font-size: 14px;"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Смертей</span>
                              <p class="name">{deaths}</p>
               				</div>
                          
                             <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-current-location"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Убийств в голову</span>
                              <p class="name">{headshots}</p>
               				</div>
                          
                           <div class="profile-block-info">
                              <span class="icon-names"><i class="bx bx-line-chart-down"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Очки на сервере</span>
                              <p class="name">{value}</p>
               				</div>
                       
							
						</div>
						<div class="col-lg-6">
                           <b style="font-size: 13px;position: relative;top: -10px;">Дополнительная информация</b>
                          <div class="profile-block-info" style="height: 65px;">
                            <span class="opis" style="color: #ffffff;font-size: 11px;">Убийства / Смерти</span>
											<div class="progress">
												<div class="progress-bar bg-info" style="width: {procent1}%"></div>
												<span>{procent1}%</span>
											</div>
               				</div>
                          
                          <div class="profile-block-info" style="height: 65px;margin-top: 20px;">
                            <span class="opis" style="color: #ffffff;font-size: 11px;">Убийства в голову</span>
											<div class="progress">
												<div class="progress-bar bg-info" style="width: {procent2}%"></div>
												<span>{procent2}%</span>
											</div>
               				</div>
                          
                          <div class="profile-block-info" style="height: 65px;margin-top: 20px;">
                            <span class="opis" style="color: #ffffff;font-size: 11px;">Точность</span>
											<div class="progress">
												<div class="progress-bar bg-info" style="width: {procent4}%"></div>
												<span>{procent4}%</span>
											</div>
               				</div>
                          
                          <div class="profile-block-info" style="margin-top: 20px;">
                              <span class="icon-names"><i class="bx bx-analyse"></i></span>
                              <span class="opis" style="color: #5a6a8c;">Последнее посещение</span>
                              <p class="name">{date}</p>
               				</div>
                          
							<div class="table-responsive">
								
							</div>
							{if('{type}' == '2')}
							<div class="table-responsive mb-0">
								<table class="table table-bordered">
									<tr>
										<td colspan="2"><b>Армия</b></td>
									</tr>
									<tr>
										<td><b> Ранг: </b></td>
										<td>{rank}</td>
									</tr>
									<tr>
										<td><b> Опыт: </b></td>
										<td>{level}</td>
									</tr>
									<tr>
										<td colspan="2"><b>Бонусы</b></td>
									</tr>
									<tr>
										<td><b> Взрывная граната: </b></td>
										<td>{ar_bonus_he}</td>
									</tr>
									<tr>
										<td><b> Слеповая граната: </b></td>
										<td>{ar_bonus_flash}</td>
									</tr>
									<tr>
										<td><b> Дымовая граната: </b></td>
										<td>{ar_bonus_smoke}</td>
									</tr>
									<tr>
										<td><b> Дефуз: </b></td>
										<td>{ar_bonus_defuse}</td>
									</tr>
									<tr>
										<td><b> Ночное видение: </b></td>
										<td>{ar_bonus_nv}</td>
									</tr>
									<tr>
										<td><b> Дополнительные HP: </b></td>
										<td>{ar_bonus_hp}</td>
									</tr>
									<tr>
										<td><b> Дополнительные AP: </b></td>
										<td>{ar_bonus_armor}</td>
									</tr>
									<tr>
										<td><b> Флаги: </b></td>
										<td>{ar_bonus_flags}</td>
									</tr>
									<tr>
										<td><b> Дополнительный урон: </b></td>
										<td>{ar_bonus_damage}</td>
									</tr>
								</table>
							</div>
							{/if}
						</div>
						{if('{army_enable}' == '2')}
						<div class="col-lg-12">
							<h4 class="modal-title">
								Используемое оружие
							</h4>
							<div class="table-responsive mt-3">
								<table class="table table-bordered">
									<thead>
									<tr>
										<td>Оружие</td>
										<td>Имя</td>
										<td>Убийств</td>
										<td>Выстрелов</td>
										<td>Урон</td>
										<td>Голова</td>
										<td>Грудь</td>
										<td>Тело</td>
										<td>Пр. рука</td>
										<td>Лев. рука</td>
										<td>Пр. нога</td>
										<td>Лев. нога</td>
									</tr>
									</thead>
									<tbody id="wstats{id}"></tbody>
								</table>
							</div>

							<h4 class="modal-title">
								Статистика по картам
							</h4>
							<div class="table-responsive mb-0 mt-3">
								<table class="table table-bordered">
									<thead>
									<tr>
										<td></td>
										<td>Название</td>
										<td>Убийств</td>
										<td>Смертей</td>
										<td>HeadShots</td>
										<td>Раундов</td>
										<td>Время в игре</td>
									</tr>
									</thead>
									<tbody id="mstats{id}"></tbody>
								</table>
							</div>
						</div>
						{/if}
					</div>
				</div>
			</div>
		</div>
	</div>
</div>