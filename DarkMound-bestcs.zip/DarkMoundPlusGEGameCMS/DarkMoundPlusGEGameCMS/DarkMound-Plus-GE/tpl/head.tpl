<head>
  <meta charset="utf-8">
  <title>{title}</title>

  <link rel="canonical" href="{site_name}" />
  <link rel="stylesheet" href="{site_host}templates/{template}/css/main.css?v={cache}">
  <link rel="shortcut icon" href="{site_host}templates/{template}/img/favicon.ico?v={cache}">
  <link rel="image_src" href="{image}">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="robots" content="{robots}">
  <meta name="revisit" content="1">
  <meta name="description" content="{description}">
  <meta name="keywords" content="{keywords}">
  <meta name="document-state" content="dynamic">
  <meta property="og:title" content="{title}">
  <meta property="og:description" content="{description}">
  <meta property="og:type" content="{type}">
  <meta property="og:image" content="{image}">
  <meta property="og:site_name" content="{site_name}">
  <meta property="og:url" content="{url}">

  <meta name="dc.title" content="{title}">
  <meta name="dc.language" content="UZ">

  <script src="{site_host}templates/{template}/js/jquery.js?v={cache}"></script>
  <script src="{site_host}templates/{template}/js/nprogress.js?v={cache}"></script>
  <script src="{site_host}templates/{template}/js/noty.js?v={cache}"></script>
  <script src="{site_host}templates/{template}/js/mix.js?v={cache}"></script>
  <script src="{site_host}templates/{template}/js/bootstrap.js?v={cache}"></script>
  <script src="{site_host}ajax/ajax-user.js?v={cache}"></script>

  {if($conf->new_year == 1 || $conf->win_day == 1)}
  <script src="{site_host}templates/{template}/js/holiday.js"></script>
  {/if} {files} {other}
  <script src="{site_host}ajax/helpers.js?v={cache}"></script>
  <script src="{site_host}ajax/ajax-user.js?v={cache}"></script>
</head>
     <script>
    var makeCtab = {

    config : {
        tabNavContainer : '#cTabs',
        tabNavElement:'div',
        tabContentContainer : '#cTabContent',
        tabContentElement:'div'
    },

    init:function(config){
        	$.extend(makeCtab.config, config);	
    	    $(makeCtab.config.tabNavContainer)
        .on('click', makeCtab.config.tabNavElement, this.changeContent);
        makeCtab.showFirstTab();       
    },

    showFirstTab:function(){
        	$(makeCtab.config.tabContentContainer)
          .find(makeCtab.config.tabContentElement).hide()
          .filter(":first").show();
        $(makeCtab.config.tabNavContainer)
          .find(makeCtab.config.tabNavElement).removeClass('active')
          .filter(":first").addClass('active');
    },
    showActiveTab:function(a){
        $(a).addClass('active')
          .siblings().removeClass('active'); 
    },
    changeContent:function(event){
        event.preventDefault();
	        myIndex = $(this).index();	
      
        makeCtab.showActiveTab(this);
	        $(makeCtab.config.tabContentContainer)
          .find(makeCtab.config.tabContentElement)
          .eq(myIndex).show()
          .siblings().hide();
	    }
 };

 $(document).ready(function() { 
 	makeCtab.init({ 
 		'tabNavContainer' : '#cTabs' 
 	}); 
});
  </script>

<script type="text/javascript">
document.write(unescape('%3c%61%20%68%72%65%66%3d%22%2e%2e%2f%73%75%70%70%6f%72%74%2f%61%64%64%5f%74%69%63%6b%65%74%22%3e%0a%20%20%3c%64%69%76%20%63%6c%61%73%73%3d%22%6d%65%73%73%61%67%65%5f%73%75%70%70%6f%72%74%22%3e%0a%20%20%20%20%20%3c%69%6d%67%20%63%6c%61%73%73%3d%22%69%6d%67%5f%6d%65%73%73%61%67%65%5f%73%75%70%70%6f%72%74%22%20%73%72%63%3d%22%2e%2e%2f%74%65%6d%70%6c%61%74%65%73%2f%44%61%72%6b%4d%6f%75%6e%64%2d%50%6c%75%73%2d%47%45%2f%69%6d%67%2f%6d%65%73%73%61%67%65%5f%73%75%70%70%6f%72%74%2e%70%6e%67%22%3e%0a%20%20%3c%2f%64%69%76%3e%0a%20%20%3c%2f%61%3e%0a%20%20%20%3c%21%2d%2d%20%72%75%73%73%69%61%2d%63%73%2e%72%75%20%2d%2d%3e%0a%20%20%3c%73%70%61%6e%20%63%6c%61%73%73%3d%22%76%65%72%73%69%6f%6e%5f%66%69%78%65%64%22%3e%56%65%72%73%69%6f%6e%20%32%2e%32%20%3c%61%20%68%72%65%66%3d%22%68%74%74%70%73%3a%2f%2f%76%6b%2e%63%6f%6d%2f%73%64%67%5f%70%72%6f%64%75%63%74%69%6f%6e%22%3e%3c%62%20%63%6c%61%73%73%3d%22%76%65%72%73%69%6f%6e%5f%6e%61%6d%65%22%3e%53%44%47%20%50%72%6f%64%75%63%74%69%6f%6e%3c%2f%62%3e%3c%2f%61%3e%3c%2f%73%70%61%6e%3e%0a%20%20%20%20%20%3c%21%2d%2d%20%u041C%u043E%u0434%u0430%u043B%u044C%u043D%u043E%u0435%20%u043E%u043A%u043D%u043E%20%u041F%u0440%u043E%u043C%u043E%u043A%u043E%u0434%20%2d%2d%3e%0a%20%20%20%20%20%20%20%20%3c%64%69%76%20%69%64%3d%22%70%72%6f%6d%6f%63%6f%64%65%22%20%63%6c%61%73%73%3d%22%6d%6f%64%61%6c%20%66%61%64%65%22%3e%0a%20%20%20%20%20%20%20%20%20%20%3c%64%69%76%20%63%6c%61%73%73%3d%22%6d%6f%64%61%6c%2d%64%69%61%6c%6f%67%22%3e%0a%20%20%20%20%20%20%20%20%20%20%20%20%3c%64%69%76%20%63%6c%61%73%73%3d%22%6d%6f%64%61%6c%2d%63%6f%6e%74%65%6e%74%22%20%73%74%79%6c%65%3d%22%70%61%64%64%69%6e%67%2d%62%6f%74%74%6f%6d%3a%20%31%35%70%78%3b%22%3e%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3c%64%69%76%20%63%6c%61%73%73%3d%22%6d%6f%64%61%6c%2d%68%65%61%64%65%72%22%3e%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3c%21%2d%2d%20%u0417%u0430%u0433%u043E%u043B%u043E%u0432%u043E%u043A%20%2d%2d%3e%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3c%64%69%76%20%63%6c%61%73%73%3d%22%74%6f%70%5f%69%6e%66%6f%22%3e%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3c%69%20%63%6c%61%73%73%3d%27%62%78%20%62%78%2d%73%63%61%6e%27%20%3e%3c%2f%69%3e%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3c%62%20%63%6c%61%73%73%3d%22%70%72%65%74%65%78%74%22%3e%u041F%u0440%u043E%u043C%u043E%u043A%u043E%u0434%3c%2f%62%3e%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3c%2f%64%69%76%3e%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3c%62%75%74%74%6f%6e%20%74%79%70%65%3d%22%62%75%74%74%6f%6e%22%20%63%6c%61%73%73%3d%22%63%6c%6f%73%65%22%20%64%61%74%61%2d%64%69%73%6d%69%73%73%3d%22%6d%6f%64%61%6c%22%20%61%72%69%61%2d%6c%61%62%65%6c%3d%22%43%6c%6f%73%65%22%3e%0a%09%09%09%09%09%3c%73%70%61%6e%20%61%72%69%61%2d%68%69%64%64%65%6e%3d%22%74%72%75%65%22%3e%d7%3c%2f%73%70%61%6e%3e%0a%09%09%09%09%3c%2f%62%75%74%74%6f%6e%3e%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3c%2f%64%69%76%3e'));
</script>
             <script>
          $('#voucher').modal('hide');
        </script>
              <div class="modal-body">
               <div class="promo-code"> 
               <label for="voucher_key" class="custom-input with-title with-button mb-0" style="margin-bottom: 20px !important;">
				<input id="voucher_key" maxlength="32" autocomplete="off" type="text" placeholder=" ">
					<span>Введите промокод</span>
					<small id="voucher_key"></small>
				</label>
                 
                 <a class="animate-pulse" onclick="activate_voucher();" style="display: block;line-height: 12px;height: 46px;width: 100%;margin-bottom: -12px;margin-top: 10px;background: #8159df;position: relative;">Применить код</a>  
			  <div id="activate_result"></div>					
      </div>

              </div>
            </div>
          </div>
        </div>
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'> 
  

  <div class="preloader">
     <div id="loading-bar-spinner" class="spinner"><div class="spinner-icon"></div></div>
  </div>

  <script>
    window.addEventListener('load', () => {
      const preloader = document.querySelector('.preloader')
      preloader.classList.add('preloader_hidden')
    })
  </script>



  {if($conf->new_year == 1)} {include file="/elements/new_year.tpl"} {/if} {if($conf->win_day == 1)} {include file="/elements/win_day.tpl"} {/if}

  <input id="token" type="hidden" value="{token}">

  <div id="global_result">
    <span class="m-icon result_ok disp-n"><div class="result_uspeshno"><i class="bx bx-check" style="font-size: 15px;    background: linear-gradient(48deg, #c07938 0%, #f3a45d 55%);margin-right: 10px;padding: 9px;border-radius: 8px;"></i> Операция выполнена</div></span>
    <span class="m-icon result_error disp-n"><div class="result_uspeshno"><i class="bx bx-x" style="font-size: 15px;background: linear-gradient(229deg, #ff3a51 0%, #f56262 95%);margin-right: 10px;padding: 9px;border-radius: 8px;"></i> Ошибка выполнения</div></span>
    <span class="m-icon result_ok_b disp-n"><div class="result_uspeshno"><i class="bx bx-check" style="font-size: 15px;    background: linear-gradient(48deg, #c07938 0%, #f3a45d 55%);margin-right: 10px;padding: 9px;border-radius: 8px;"></i> Операция выполнена</div></span>
    <span class="m-icon result_error_b disp-n"><div class="result_uspeshno"><i class="bx bx-x" style="font-size: 15px;background: linear-gradient(229deg, #ff3a51 0%, #f56262 95%);margin-right: 10px;padding: 9px;border-radius: 8px;"></i> Ошибка выполнения</div></span>
  </div>
  <div id="result_player"></div>
 