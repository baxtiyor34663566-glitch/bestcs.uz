<script>
	$(".monitoring").remove();
	$("#hidden-menu").addClass("with-border");
</script>
</div>
</div>

<div class="container">
	<div class="row mt-5">
		<div class="col-lg-3">
          
          <div class="block_select_servers">
      <div class="head_new">
		<i class='bx bx-category' ></i> Выберите категорию
      </div>
		<ul class="vertical-navigation">
 <ul class="nav vertical-navigation with-icons">
				<li>
					<a class="vertical-navigation" data-toggle="tab" href="#friends-tab" onclick="load_friends('{id}')">
						Список друзей
					</a>
				</li>
				<li>
					<a class="vertical-navigation" data-toggle="tab" href="#unfriends-tab" onclick="load_friend_requests('un')">
						Исходящие заявки
					</a>
				</li>
				<li>
					<a class="vertical-navigation" data-toggle="tab" href="#infriends-tab" onclick="load_friend_requests('in')" style="margin-right: 0px;">
						Входящие заявки
						<span id="col_infriends"></span>
					</a>
				</li>
			</ul>
		</ul>
	</div>
  
           
            {include file="/parts/sidebar.tpl"} 
		</div>

		<div class="col-lg-9 profile-page">
     <!-- Заголовок -->
        <div class="top_info">
          <i class='bx bx-list-ul'></i>
          <b class="pretext">Мои друзья</b>
        </div>

			<div class="tab-content">
				<div class="tab-pane fade show active" id="friends-tab">
					<div class="row" id="friends">
						<div class="loader"></div>
					</div>
				</div>
				<div class="tab-pane fade" id="unfriends-tab">
					<div class="row" id="unfriends">
						<div class="loader"></div>
					</div>
				</div>
				<div class="tab-pane fade" id="infriends-tab">
					<div class="row" id="infriends">
						<div class="loader"></div>
					</div>
				</div>
			</div>

			<script>
				load_friends("{id}");
				load_col_infriends();
			</script>
		</div>
