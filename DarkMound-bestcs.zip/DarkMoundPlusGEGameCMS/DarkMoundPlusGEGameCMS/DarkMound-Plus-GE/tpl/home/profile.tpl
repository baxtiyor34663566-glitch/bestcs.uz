<script>
  $(".monitoring").remove();
  $("#hidden-menu").addClass("with-border");
</script>
</div>
</div>


<div class="container">
  <!-- Заголовок -->
  <div class="top_info">
    <a href="../">
      <button class="add_news">Вернуться</button>
    </a>
    <i class='bx bx-user'></i>
    <b class="pretext">Профиль</b>
  </div>
  <div class="row mt-5">
    {if('{dell}' != '1')}
    <div class="col-lg-4">
      <!-- Меню действий для администратора -->
      <div class="block">
        <div class="block_fbrs" style="background-image: url(../templates/DarkMound-Plus-GE/img/profile_back.png);background-size: cover;">
           {if((is_auth() && $_SESSION['id'] != '{profile_id}' && '{dell}' != '1'))} {if(isOnMyBlacklist($pdo, $id))}
        <button class="razblock" onclick="removeFromBlackList({profile_id}, function(message) { alert(message) }); $(this).fadeOut();"><i class='bx bx-happy' ></i></button>
        {else}
        <button class="zablock" type="Заблокировать" onclick="addToBlackList({profile_id}, function(message) { alert(message) }); $(this).fadeOut();"><i class='bx bx-block' ></i></button>
        {/if} {/if}
          <img src="../{avatar}" alt="{login}" class="avatarprofile">
          <div class="texxt">
            <p class="username">{login}</p>
            <span class="lastname">{last_activity}</span>
          </div>
          {if(is_worthy("p"))}
          <div class="dropdown">
            <button onclick="myFunction()" title="Меню действий" class="dropbtn">EDIT</button>
            <div id="myDropdown" class="dropdown-content">
              <div class="row" style="margin-bottom: 0px;    display: flex;flex-wrap: nowrap;">
                <div class="col-sm" style="height: 80px;">
                  <div class="balance-left">
                    <span id="money" class="h1reg">{shilings}</span>
                    <span class="h2reg">Баланс</span>
                  </div>
                </div>

                <div class="col-sm" style="height: 80px;">
                  <div class="skidka-right">
                    <span id="proc" class="h1reg">{proc}%</span>
                    <span class="h2reg">Скидка</span>
                  </div>
                </div>
              </div>

              {if(is_worthy("m"))}
              <a onclick="give_money({profile_id});"><i class='bx bx-plus-circle' ></i> Дать деньги</a>
              <a onclick="pick_up_money({profile_id});"><i class='bx bx-minus-circle' ></i> Забрать деньги</a> {/if} {if(is_worthy("c"))}
              <a onclick="take_proc({profile_id});"><i class='bx bx-purchase-tag' ></i> Установить скидку</a> {/if} {if(is_worthy("f"))}
              <a href="../edit_user?id={profile_id}"><i class='bx bx-message-square-edit' ></i> Редактировать</a> {/if}
            </div>
          </div>
          {/if}
        </div>

        <!-- Кнопки действия с пользователями -->
        <div class="container-buttons">
          {if(is_auth() && '{profile_id}' == $_SESSION['id'])}
          <a href="../settings" class="profile-settingss">Редактировать профиль</a> {/if} {if((is_auth() && $_SESSION['id'] != '{profile_id}' && '{dell}' != '1'))}
          <a href="../messages?create_id={profile_id}" class="profile-button">Сообщение</a> {/if} {if((is_auth() && $_SESSION['id'] != '{profile_id}' && '{dell}' != '1'))} {if('{isFriend}' == 'false' && '{issetFriendRequestFromMe}' == 'false' && '{issetFriendRequestFromHim}' == 'false')}
          <a onclick="add_new_friend({profile_id}, function(message) { alert(message) }); $(this).fadeOut();" style="margin-left: 7px;" class="profile-button">Добавить в друзья</a> {/if} {if('{isFriend}' == 'true')}
          <a onclick="dell_friend({profile_id}, function(message) { alert(message) }); $(this).fadeOut();" style="margin-left: 7px;" class="profile-button">Удалить из друзей</a> {/if} {/if} {if('{issetFriendRequestFromMe}' == 'true')}
          <a onclick="cancel_friend({profile_id}, function(message) { alert(message) }); $(this).fadeOut();" style="margin-left: 7px;" class="profile-button">Отменить заявку</a> {/if} {if('{issetFriendRequestFromHim}' == 'true')}
          <a onclick="take_friend({profile_id}, function(message) { alert(message) }); $(this).fadeOut(); $(this).next().fadeOut();" style="margin-left: 7px;" class="profile-button">Принять заявку</a> {/if}
        </div>

        <!-- Контакты -->
        {if(('{skype}' != '' && '{skype}' != '---') || '{telegram}' != '' || '{vk}' != '---' || '{steam_api}' != '0' || '{fb}' != '0')}
        <div class="contacts_profile">
            {if('{telegram}' != '')}
              <div class="profile_contact_telegram">
                       <i class='bx bxl-telegram'></i>
 				<div class="text_contactss">
                  <a title="Добавить в Telegram" href="https://telegram.me/{telegram}" class="profile_contact_name">@{telegram}</a>
				<span class="profile_contact_opisanie">Telegram</span>
                  </div>
              </div>
            {/if}
            
             {if('{discord}' != '')}
              <div class="profile_contact_discord">
                        <i class="bx bxl-discord-alt"></i>
                <div class="text_contactss">
                  <a title="Добавить в Discord" class="profile_contact_name">{discord}</a>
                 <span class="profile_contact_opisanie">Discord</span>
                   </div>
              </div>
            {/if}

          
          
            {if('{vk}' != '---')}

              <div class="profile_contact_telegram">
                <span class="vk_contact">
                        <i class="bx bxl-vk"></i>
                        </span>
                  <div class="text_contactss">
                  <a title="Перейти в профиль Вконтакте" target="_blank" href="https://vk.com/{vk}" id="vk_user">
                    
                    <span class="profile_contact_name">Загрузка...</span>
                  </a>
                <span class="profile_contact_opisanie">Вконтакте</span>
                     </div>
                <script>
                  get_vk_profile_info('{vk_api}', '#vk_user img', '#vk_user span', '{vk}');
                </script>
              </div>

            {/if} {if('{steam_api}' != '0')}


              <div class="profile_contact_telegram">
                <span class="steam_contact">
                        <i class="bx bxl-steam"></i>
                        </span>
				<div class="text_contactss">
                  <a title="Перейти в профиль Steam" target="_blank" href="https://steamcommunity.com/profiles/{steam_api}/" id="steam_user">
                    <span class="profile_contact_name">Загрузка...</span>
                  </a>
                
                <span class="profile_contact_opisanie">Steam</span>
                  </div>
                <script>
                  get_user_steam_info('{steam_api}');
                </script>
              </div>

            {/if}

        </div>
        {/if}

        <!-- Мини статистика -->
        <div class="block-profile-stats">
          <div class="block-stats">
            <p class="stats-text">{thanks}</p><span class="opiss">Лайков</span>
          </div>
          <div class="block-stats">
            <p class="stats-text">{answers}</p><span class="opiss">Сообщений</span>
          </div>
          <div class="block-stats" style="margin-right: 0px;">
            <p class="stats-text">{reit}</p><span class="opiss">Рейтинг</span>
          </div>
        </div>
      </div>

      <script>
        var user_balance = $(".detailed-profile ul > li span#money").text();
        var user_percent = $(".detailed-profile ul > li span#proc").text();
        if (user_balance != '' && user_percent != '') {
          $(".money-info-block #money").html(user_balance + "Р");
          $(".money-info-block #proc").html(user_percent + "%");
        } else {
          $(".money-info-block").remove();
        }
        $(".detailed-profile ul > li").has(".icon-user").remove();
        $(".detailed-profile ul > li").has(".icon-bank").remove();
        $(".detailed-profile ul > li").has(".icon-marker").remove();
      </script>
    </div>

    <script>
      function myFunction() {
        document.getElementById("myDropdown").classList.toggle("show");
      }

      window.onclick = function(event) {
        if (!event.target.matches('.dropbtn')) {
          var dropdowns = document.getElementsByClassName("dropdown-content");
          var i;
          for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
              openDropdown.classList.remove('show');
            }
          }
        }
      }
    </script>

    <div class="col-lg-8">

      <div class="tabs__buttons--container">
        <button class="tabs__tab-btn" data-tab-id="home">Информация</button>
         {if(is_auth() && '{profile_id}' == $_SESSION['id'])}
        <button class="tabs__tab-btn" data-tab-id="privileges">Привилегии</button>
        {/if}
        <button class="tabs__tab-btn" data-tab-id="stena">Стена</button>
      </div>
      
       <div data-tab="privileges" class="tabs__tab">
        <div class="block" style="padding: 0px;">
           <div class="block" style="padding: 20px;padding-bottom: 0px;margin-bottom: 0px;">
                    <div class="referal_block">
                  <div class="black_list_left">
                  <i class='bx bx-star' style="top: 0px;background: linear-gradient(227deg, #7c7bff 0%, #5857d5 55%);font-size: 18px;"></i>
                    <div class="black_list_text">
                      <span class="black_list_h1">Ваши привилегии</span>
                      <span class="black_list_h2">Здесь находятся Ваши активные<br> привилегии</span>
                    </div>
                     </div>
                  </div>
             </div>
          
          <div class="block" style="padding-top: 0px;padding-bottom: 10px;padding-right: 20px;padding-left: 20px;">
          <div id="my_stores" class="table-adaptive">
				<div class="loader"></div>
				<script>get_user_srotes();</script>
			</div>
			</div>
			<script>
				function local_change_admin_type(id) {
					var type = $('#store_type_'+id+' option:selected').val();
					change_admin_bind_type(type, id);
				}
			</script>
          
        </div>
       </div>

      <div data-tab="home" class="tabs__tab">
        <div class="block-profile">
          <div class="profile-info1">

            <div class="profile-block-info">
              <span class="icon-names"><i class="bx bx-fingerprint" style="font-weight: 100;"></i></span>
              <span class="opis">Номер профиля</span>
              <p class="name">{profile_id}</p>
            </div>
            <div class="profile-block-info">
              <span class="icon-names"><i class='bx bx-category-alt' ></i></span>
              <span class="opis">Группа</span>
              <p class="name">{group}</p>
            </div>
            <div class="profile-block-info">
              <span class="icon-names"><i class="bx bx-joystick" style="font-weight: 100;"></i></span>
              <span class="opis">Игровой ник</span>
              <p class="name">{nick}</p>
            </div>
            <div class="profile-block-info">
              <span class="icon-names"><i class='bx bx-meteor' ></i></span>
              <span class="opis">Имя</span>
              <p class="name">{name}</p>
            </div>
            <div class="profile-block-info">
              <span class="icon-names"><i class='bx bx-face' ></i></span>
              <span class="opis">Дата рождения</span>
              <p class="name">{birth}</p>
            </div>
            <div class="profile-block-info" style="border-bottom: dashed 1px #343e5600;margin-bottom: -5px;">
              <span class="icon-names"><i class='bx bx-time' ></i></span>
              <span class="opis">Дата регистрации</span>
              <p class="name">{regdate}</p>
            </div>
          </div>

          <div class="profile_right_b">
          <div class="profile_forum" style="margin-bottom: 8px;">
          <!-- Заголовок -->
                  <div class="top_info_profile">
                  <i class='bx bx-album' ></i>
                    <b class="pretext_profile">Активность</b>
                  </div>
            <div id="last_activity">
              {func Widgets:user_forum_activity('{profile_id}', '2')}
            </div>
          </div>
          
          <div class="profile_forum">
          <!-- Заголовок -->
                  <div class="top_info_profile">
                  <i class='bx bx-dice-5' style="background: linear-gradient(221deg, #ff8c8c 0%, rgb(255 103 92) 55%);"></i>
                    <b class="pretext_profile">Заявки на разбан</b>
                  </div>
			<div id="mybans">
				{func Widgets:user_bans('{profile_id}', '1')}
			</div>
          </div>
         </div>
        </div>
      </div>
      
      
      

<div data-tab="stena" class="tabs__tab">
   <div class="block-profile-stena">
     {if('{dell}' != '1')}
				
                    {if('{checker}' != '1')}
						<div id="add_new_comments">
							<textarea id="text" maxlength="1000"></textarea>

							<div class="smile_input_forum mt-3">
								<input id="send_btn" class="btn btn-outline-primary" type="button" onclick="send_user_comment({profile_id});" value="Отправить">
								<div id="smile_btn" class="smile_btn" data-container="body" data-toggle="popover" data-placement="top" data-content="empty"></div>
							</div>
						</div>
						<script>
                          $(document).ready(function () {
                            init_tinymce(
                              'text', 'lite', "{file_manager_theme}", "{file_manager}", "{{md5($conf->code)}}");
                            get_smiles('#smile_btn');
                          });

                          $('#smile_btn').popover({ html: true, animation: true, trigger: 'click' });
                          $('#smile_btn').on('show.bs.popover', function () {
                            $(document).mouseup(function (e) {
                              var container = $('.popover-body');
                              if (container.has(e.target).length === 0) {
                                $('#smile_btn').popover('hide');
                                selected = 'gcms_smiles';
                              }
                            });
                          });

                          function set_smile (elem) {
                            var smile = '<img src="' + $(elem).attr('src') +
                              '" class="g_smile" height="20px" width="20px">';
                            tinymce.activeEditor.insertContent(smile);
                            $('#smile_btn').popover('hide');
                            selected = 'gcms_smiles';
                          }

                          function set_sticker (elem) {
                            var text = 'sticker' + $(elem).attr('src');
                            text = encodeURIComponent(text);
                            send_user_comment({profile_id}, text);
                            $('#smile_btn').popover('hide');
                            selected = 'gcms_smiles';
                          }
						</script>
                    {/if}
					<div id="comments" class="mt-3">
						<div class="loader"></div>
					</div>
					<script>load_users_comments({profile_id}, 'first');</script>
				
            {/if}
     </div>
</div>
      </div>

	<script>
const tabsBtns = Array.from(document.querySelectorAll("[data-tab-id]"));
const tabs = Array.from(document.querySelectorAll("[data-tab]"));

let selectedTab = tabsBtns[0].dataset.tabId;

const hideTabs = () => {
  tabs
    .filter((tab) => tab.dataset.tab !== selectedTab)
    .forEach((tab) => {
      tab.classList.add("tabs__tab--hide");
    });

  tabsBtns
    .filter((tab) => tab.dataset.tabId !== selectedTab)
    .forEach((tab) => {
      tab.classList.add("tabs__tab-btn--not-selected");
    });
};
hideTabs();

const handleSelectTab = (e) => {
  selectedTab = e.target.dataset.tabId;

  tabs.forEach((tab) => {
    tab.classList.remove("tabs__tab--hide");
  });

  tabsBtns.forEach((tab) => {
    tab.classList.remove("tabs__tab-btn--not-selected");
  });

  hideTabs();
};

tabsBtns.forEach((btn) => {
  btn.addEventListener("click", handleSelectTab);
});

    </script>


    {else}
    <h2>Пользователь удален</h2> {/if}
      