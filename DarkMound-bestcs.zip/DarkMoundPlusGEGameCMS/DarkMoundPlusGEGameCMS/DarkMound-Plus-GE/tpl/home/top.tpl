<div class="container-fluid wapper">
  <div class="content" {points-background}>
    <div class="container">
   
      
      <div class="header">
         <!-- Логотип -->
        <span class="logol">
		<a href="../">
         <img class="logo_sdg" src="../templates/DarkMound-Plus-GE/img/logo.png">
          </a>
        </span>   
        <p class="welcome"> Приветствуем, <b style="color: #ffff;">{{$user->login}}!</b> </p>
        
        
		
        <!-- Кнопка уведомлений -->
		<ul class="collapsible-menu user-menu">
          <!-- Баланс юзера -->
          <li class="balance">
           {{$user->shilings}} ₽
            <a href="../purse" class="pursee-button">+</a>
          </li>
          
                     <li class="">
           <a href="../messages"><i class='bx bx-message-square-dots' ></i></a>
          </li>
          
          <li>
            <div class="show_user"><span class="circleuved" id="notifications_line"></span><i class='bx bx-bell' style="position: absolute;right: 9px;top: 9px;"></i>
            </div>
            <div id="block" style="display: none">
              <div class="navigation_head">
                     <b>Уведомления</b>
					<button onclick="hide_notifications();" class="notification_delete_all" style="font-size: 10px;">
                Прочитано
              </button>
           
            </div>

            <div id="notifications">
			{func GetData:notifications("0", "0", "1")}
		</div>
              <a href="../notifications">
              <button class="notification_all_uved" style="font-size: 10px;">
                Все уведомления
              </button>
                </a>
            </div>
            
            <script>
              jQuery(function($) { 
                $('.show_user').click(function() {
                  $(this).toggleClass('active').next()[
                    $(this).next().is(':hidden') ? "slideDown" : "slideUp"](300);
                });
              });
            </script>
          </li>
          
         
		<i class='bx bx-chevron-down' ></i>
          <!-- Личный кабинет -->
          <li class="collapsible">
            <a href="">
              <div class="blockprofile">
                <div id="check_mess"></div>
			{if('{countOfOpenTickets}' > '0' || '{countOfOpenBans}' > '0' || '{countOfOpenComplaints}' > '0')}
			<i class="point"></i>
			{/if}
                <img src="../{avatar}" alt="{login}">
                <script>
                  check_news();
                </script>
                <div id="check_mess"></div>

                {if('{tickets}' > '0' || '{bans}' > '0')}
                {/if}
                <br>
              	</div>
            </a>
            <ul style="border-radius: 15px;">

              <div class="collapsible_head">
                <a href="../profile">
                <div class="headd" style="left: -12px;position: relative;">
                  <div>
                        <img src="../{{$user->avatar}}" alt="{{$user->login}}" style="top: 12px; left: 30px;">
                    <div class="collapsible_profile">
                        <b>{{$user->login}}</b>
                      <br>
                       <p style="font-size: 10px;font-weight: 600;position: relative;top: -5px;color: #83839e;">Перейти в профиль</p>
                    </div>
                  </div>
                </div>
                   </a>
              </div>
              <li>
                <a href="../messages"><i class='bx bx-message-square-detail' ></i> Мои сообщения</a>
              </li>
               <li>
                <a href="../friends"><i class="bx bx-carousel"></i> Мои друзья</a>
              </li>
              <li>
                <a href="../purse"><i class='bx bx-wallet' ></i> Пополнить баланс</a>
              </li>      
                {if('{countOfOpenBans}' > '0')}
              <li>
                <a href="../bans/"><i class='bx bx-lock-open-alt' ></i> Разбан <b>{countOfOpenBans}</b></a>			
              </li>
				{/if}
              {if('{countOfOpenTickets}' > '0')}
              <li>
                <a href="../support/all_tickets"><i class='bx bx-headphone' ></i> Открытые тикеты <b>{countOfOpenTickets}</b></a>
              </li>
              {/if} {if('{countOfOpenComplaints}' > '0')}
              <li>
                <a href="../complaints/index"><i class='bx bx-archive' ></i> Жалобы <b>{countOfOpenComplaints}</b></a>
              </li>
              {/if}
              {if(is_worthy("p"))}
				<a class="admin-center" href="../admin"><i class='bx bx-planet'></i> Админ центр <b class="admin-panel">PANEL</b></a>
              {/if}
              <li style="background: #383850;height: 1px;margin-top: 7px;margin-bottom: -1.1px;width: 200px;">
                </li>
              <a class="exitmini" href="../exit" style="margin-bottom: 10px;"><i class="bx bx-log-in-circle"></i> Выход</a>
            </ul>
          </li>
        </ul>
      </div>
      <div class="two_menu_2">
      <div class="two_top_menu">
        
        <div class="menu_top_left">     
          <a href="../">
          <div class="menu_top_push">
            <i class='bx bx-home-alt-2' ></i> Главная
          </div>
          </a>
          
          <div class="menu_top_left">
            <a href="../news">
          <div class="menu_top_push">
            <i class='bx bx-globe' ></i> Новости
          </div>
           </a>
         </div> 
          
        <div class="menu_top_left">
          <a href="../forum">
          <div class="menu_top_push">
            <i class='bx bx-chat' ></i> Форум
          </div>
          </a>
         </div> 
          
           <div class="menu_top_left">
            <a href="../support">
          <div class="menu_top_push">
            <i class='bx bx-support' ></i> Поддержка
          </div>
           </a>
         </div> 
          </div>
        
         <div class="menu_top_rigth">
           
           <a href="../users">
           <div class="search_user">
           <i class='bx bx-search'></i>
             <span>Foydalanuvchini qidirish</span>
           </div> 
           </a>
           
           <div class="qr_code_top" data-target="#promocode" data-toggle="modal">
             <i class='bx bx-scan' ></i> Promokod
           </div>
           
         </div> 
        </div>
        </div> 
    </div>
    

    <div class="container">
      <div class="row">