<div class="container" style="padding-right: 0px;padding-left: 0px;">
<div class="banlist">

<div class="col-lg-9 order-is-first">

  <div class="button-plateji">
    <!-- Заголовок -->
        <div class="top_info">
          {if(is_worthy("j"))}
          <a href="../edit_admins">
            <button class="add_admins"><b class="admins_plus">+</b><b class="admins_all">Управление</b></button>
          </a>
          {/if}
        <i class='bx bx-shield' ></i>
          <b class="pretext">Действующие админы</b>
        </div>
         
  				</div>

	<div class="clearfix"></div>

	{func GetData:servers_admins({server})}
</div>

<div class="col-lg-3 order-is-last">
	
	<div class="block_select_servers">
      <div class="head_new">
		<i class='bx bx-dice-3' ></i> Выберите сервер
      </div>
		<ul class="vertical-navigation">
			{servers}
		</ul>
	</div>

  

	{include file="/parts/sidebar.tpl"}
</div>
  </div>
  </div>