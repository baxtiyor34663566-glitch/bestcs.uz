<div class="col-lg-9 order-is-first">
	{func GetData:price_list()}
</div>
<div class="col-lg-3 order-is-last">
 <div class="block_mini_profile">
<div class="navigation_profile">
              <div class="photo_profile">
                <a href="../profile">
               <img src="../{{$user->avatar}}" alt="{{$user->login}}" class="img_navigation">
                  </a>
                 <div class="info_navigation">
                     <b class="name_sidebar">{{$user->login}}</b>
                     <br>
                     <b><b class="group_sidebar"> {{$users_groups[$user->rights]['name']}}</b></b>
                 </div>
                </div>
              <a href="../exit">
              <i class="bx bx-log-in-circle"></i>
                </a>
            </div>
     	
     
   
  		<a href="../settings" class="balance_navigation">
   			<i class='bx bx-cog'></i>
    		<b class="setting-sidebar">Настройки профиля</b>
    	</a>
   </div>
	{include file="/parts/sidebar.tpl"}

</div>