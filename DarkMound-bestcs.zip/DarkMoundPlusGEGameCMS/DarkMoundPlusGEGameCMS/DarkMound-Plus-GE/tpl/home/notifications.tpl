<div class="col-lg-3 order-is-last">
{include file="/parts/sidebar.tpl"}
</div>

<div class="col-lg-9 order-is-first">
  <!-- Заголовок -->
        <div class="top_info">
          <a href="../news/add_new">
            <button onclick="dell_notifications();" class="add_news">Удалить все</button>
          </a>
          <i class='bx bx-bell' style="transition: .2s all;position: relative;right: 0px;"></i>
          <b class="pretext">Уведомления</b>
        </div>
	<div class="block" id="notifications_line" style="padding-bottom: 25px;padding-top: 1px;">
		<div id="notifications">
			{func GetData:notifications("{start}", "{limit}")}
		</div>
	</div>

	<div id="pagination2"><center>{pagination}</center></div>
</div>