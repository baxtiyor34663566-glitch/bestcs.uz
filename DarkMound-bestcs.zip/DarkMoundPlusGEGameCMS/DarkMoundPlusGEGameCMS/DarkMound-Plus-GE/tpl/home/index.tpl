</div>
</div>

<style>
    .two_menu_2 {
        display: none;
    }
</style>
<div class="container">
    <div class="two_top_menu">
        <div class="menu_top_left">
            <a href="../">
                <div class="menu_top_push_active">
                    <i class='bx bx-home-alt-2'></i> Главная
                </div>
            </a>
            <div class="menu_top_left">
                <a href="../news">
                    <div class="menu_top_push">
                        <i class='bx bx-globe'></i> Новости
                    </div>
                </a>
            </div>
            <div class="menu_top_left">
                <a href="../forum">
                    <div class="menu_top_push">
                        <i class='bx bx-chat'></i> Форум
                    </div>
                </a>
            </div>
            <div class="menu_top_left">
                <a href="../support">
                    <div class="menu_top_push">
                        <i class='bx bx-support'></i> Поддержка
                    </div>
                </a>
            </div>
        </div>

        <div class="menu_top_rigth">
            <a href="../users">
                <div class="search_user">
                    <i class='bx bx-search'></i>
                    <span>Foydalanuvchini qidirish</span>
                </div>
            </a>
            <div class="qr_code_top" data-target="#promocode" data-toggle="modal">
                <i class='bx bx-scan'></i> Promokod
            </div>
        </div>
    </div>

    {include file="/parts/detailed-profile.tpl"}
  
    <div class="mobile_block">
        <i class='bx bx-devices'></i>
        <div class="div_text_mobile">
            <span class="span_monile">Вы в мобильной версии</span>
            <b class="p_mobile" style="color: #5d6883;">Для полноты ощущений от использования сайта, перейдите в ПК версию</b>
        </div>
    </div>

    <!-- Здесь находится блок со слайдером и кнопками -->
    {include file="/parts/slider.tpl"}

    <div class="container">
        <div class="row">
            <div class="col-lg-9 order-is-first">
                <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

                <!-- Заголовок -->
                <div class="top_info">
                    <i class='bx bx-message-square-detail'></i>
                    <b class="pretext">Чат проекта</b>
                </div>
                <div class="chat_block" style="background-image: url(../templates/DarkMound-Plus-GE/img/chat_background.png);background-size: cover;">
                    <div class="users_online_chat">
                        <div class="online_full_user">
                            <div style="display: flex;align-items: center;">
                                <i class='bx bx-radar'></i>
                                <span class="userss_online">Online <span class="number_max" id="users_online_number"></span>
                                    <br><b style="color: #8989bd;font-size: 10.2px;position: relative;right: 0.5px;">Пользователи</b></span>
                            </div>

                            <div data-target="#ruleschat" data-toggle="modal" class="button_rules_chat">
                                <i class='bx bx-book'></i>
                            </div>
                        </div>

                        <div class="online_scroll">
                            {func Widgets:online_users()}
                        </div>
                        <span data-target="#online" data-toggle="modal" class="all_online">Сегодня посетили 
                          <span class="number_max_set" id="count_of_last_onl_us">{func Widgets:were_online()}</span>
                      </span>

                    </div>
                    {include file="/elements/chat.tpl"} {if($conf->show_news != '1')}
                </div>

                <!-- Заголовок -->
                <div class="top_info">
                    {if(is_worthy("b"))}
                    <a href="../news/add_new">
                        <button class="add_news">Добавить новость</button>
                    </a>
                    {/if}
                    <i class='bx bx-map-alt'></i>
                    <b class="pretext">Последние новости</b>
                </div>
                <div class="clearfix"></div>
                <div id="new_news" class="row">
                    {func Widgets:last_news($conf->show_news)}
                </div>
                {/if}

                <!-- Заголовок -->
                <div class="top_info">
                    <i class='bx bx-radar'></i>
                    <b class="pretext">События проекта</b>
                </div>

                <div class="sobitia-block">
                    <div class="sobitia-left">
                        {if($conf->show_events != '0')}
                        <div class="block" style="background: #1e222f00;margin-bottom: 0px;">
                            <div id="events">
                                {func EventsRibbon:get_events(0, 0, $conf->show_events)}
                            </div>
                        </div>
                        {/if}
                    </div>

                    <div class="online-right">
                        <div class="block" style="padding: 12px;background: #8158df6e;margin-bottom: 0px;">
                            <div class="donat_block_top">
                                <i class='bx bx-donate-heart'></i>
                                <div class="rozigrish_block">
                                    <span class="rozigrish_h1">Топ донатеров</span>
                                    <span class="rozigrish_opisanie">Игроки поддержавшие проект</span>
                                </div>
                            </div>
                            {if($conf->top_donators == '1')}
                            <div id="online_users">
                                {func Widgets:top_donators($conf->top_donators_count)}
                            </div>
                            {/if}
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 order-is-last">
               {if($user->steam_id == '---' || empty($user->steam_id))}
                <div class="steamid_recomended">
                  <span class="steamid_index">ВАЖНО</span>
                    <div class="steamid_left">
                        <p style="font-size: 14px;font-weight: 600;margin-bottom: 5px;">Укажите STEAM ID</p>
                        <p style="margin-bottom: 0px;font-size: 10.3px;font-weight: 600;color: #7c7c99;">Нужно заполнить поле ниже, чтобы в будующем не возникло проблем с покупкой привилегий</p>
                    </div>
                    <div class="steamid_right">
                        <label for="user_steam_id" class="custom-input with-title with-button mb-0">
                            <button type="button" onclick="edit_user_steam_id();">
                                Сохранить
                            </button>
                            <input id="user_steam_id" maxlength="32" autocomplete="off" type="text" placeholder=" ">
                            <span>Steam ID</span>
                            <small id="edit_user_steam_id_result"></small>
                        </label>
                    </div>
                </div>
                {/if}
                {include file="/parts/sidebar.tpl"}

                <div class="block_forum">
                    <div class="block_forum_head">
                        Последнее на форуме
                    </div>
                    <div id="last_activity">
                        {func Widgets:last_forum_activity('7')}
                    </div>
                </div>

            </div>