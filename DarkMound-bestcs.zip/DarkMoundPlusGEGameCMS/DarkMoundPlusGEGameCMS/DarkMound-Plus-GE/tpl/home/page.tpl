<div class="col-lg-9 order-is-first">
		<div class="with_code">{content}</div>
</div>

<div class="col-lg-3 order-is-last">
	{include file="/parts/sidebar.tpl"}
</div>