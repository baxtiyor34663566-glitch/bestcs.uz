<div class="col-lg-9 order-is-first">
 <!-- Заголовок -->
		<div style="display: flex;align-items: center;justify-content: space-between;">
        <div class="top_info">
          <i class='bx bx-group' ></i>
          <b class="pretext">Пользователи</b>
        </div>
           <label for="groups" style="width: 130px;" class="custom-select with-title">
				<select style="font-size: 11px;padding-top: 2px;background: #29293c;font-weight: 600;padding-left: 45px;height: 41px;position: absolute;top: -21px;border-radius: 10px;color: #ffff;" id="groups" onchange="group_change();">{groups}</select>
            <span><i class="bx bx-filter-alt"style="background: #41415b;width: 28px;display: flex;color: #717197;top: -20px;cursor: auto;position: relative;margin-left: -8px;font-size: 14px;height: 28px;border-radius: 7px;justify-content: center;align-items: center;"></i></span>
			</label>
        </div>
	<div class="block_search">
		<div class="input-search">
			<i class="bx bx-search-alt" onclick="search_login({start})" style="z-index: 1000;position: absolute;left: 1px;top: 28px;width: 40px;display: flex;height: 40px;color: #77779c;border-radius: 10px;background: #363650;font-size: 18px;cursor: pointer;justify-content: center;align-items: center;"></i>
			<label for="search_login" class="custom-input with-title">
				<input id="search_login" autocomplete="off" type="text" placeholder=" " style="background:#1a1a26;">
				<span>Введите логин пользователя</span>
			</label>
		</div>
	</div>

	<div id="users" class="row">
		{func GetData:users("{start}", "{group}", "{limit}")}
	</div>

	<script>
		set_enter('#search_login', 'search_login({start})');

		function group_change() {
			var group = $('#groups').val();
			location.href = 'users?group='+group+'&page=1';
		}
	</script>

	<div id="pagination2">{pagination}</div>
</div>

<div class="col-lg-3 order-is-last">	
	{include file="/parts/sidebar.tpl"}
</div>