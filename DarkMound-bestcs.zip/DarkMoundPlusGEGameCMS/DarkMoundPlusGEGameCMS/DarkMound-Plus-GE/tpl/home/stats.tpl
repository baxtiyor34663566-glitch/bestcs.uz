<div class="col-lg-9 order-is-first">
 <!-- Заголовок -->
        <div class="top_info" style="margin-bottom: -30px;">
          <i class='bx bx-line-chart' ></i>
          <b class="pretext">Статистика</b>
        </div>
  
	<div class="block" style="background: #fff0;">
		{if('{error}' == '')}

			<div class="table-adaptive table-fused mt-4" id="stats">
				{func GetData:stats("{start}","{server}","{limit}")}
			</div>
		{else}
			<div class="empty-element">
				{error}
			</div>
		{/if}
	</div>

	<div id="pagination2">{pagination}</div>



</div>

<div class="col-lg-3 order-is-last mt-5">
  
 <div class="block_search">
<div class="input-search mt mb">
  <i class="bx bx-search-alt" onclick="search_stats({server})" style="z-index: 1000;position: absolute;left: 1px;top: 28px;width: 40px;display: flex;height: 40px;color: #60608a;border-radius: 10px;background: #323249;font-size: 18px;cursor: pointer;justify-content: center;align-items: center;"></i>
			<label for="search_stats" class="custom-input with-title">
				<input id="search_stats" autocomplete="off" type="text" placeholder=" " style="background: #1a1a26;">
				<span>Введите никнейм / SteamID</span>
			</label>
			<script> set_enter('#search_stats', 'search_stats({server})'); </script>
		</div>
        	</div>


	<div class="block_select_servers">
      <div class="head_new">
		<i class='bx bx-dice-3' ></i> Выберите сервер
      </div>
		<ul class="vertical-navigation">
			{servers}
		</ul>
	</div>

	{include file="/parts/sidebar.tpl"}
</div>