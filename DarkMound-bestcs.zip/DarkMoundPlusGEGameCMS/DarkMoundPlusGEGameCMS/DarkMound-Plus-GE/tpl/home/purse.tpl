<div class="col-lg-9 order-is-first">

    {if('{success}' == '1')}
		<div class="noty-block success">
			<h4>Ваш баланс успешно пополнен!</h4>
			<p><b>{login}</b>, Ваш баланс успешно пополнен!</p>
		</div>
    {/if}
    {if('{fail}' == '1')}
		<div class="noty-block error">
			<h4>Внимание! Ваш баланс не пополнен!</h4>
			<p>Возможно произошла ошибка, либо Вы отменили платеж.</p>
		</div>
    {/if}


<!-- Заголовок 
	{if('{bonusesActivity}' == '1')}

		<div class="bonus-block">

				{for($i = 0; $i < count($bonuses); $i++)}
					<div class="col-xs-{if(count($bonuses) % 4 == 0)}3{else}{if(count($bonuses) % 3 == 0)}4{else}{if(count($bonuses) % 2 == 0)}6{else}12{/if}{/if}{/if}">
						<div class="but-bonus">
                          <i class="bx bx-bomb" style="float: left;padding: 13px;background: linear-gradient(180deg, #3473ff 0%, rgb(80 134 255) 55%);font-size: 19px;border-radius: 12px;margin-right: 12px;"></i>
							<div>
                          <h4 style="font-weight: 600;margin-bottom: 0px;">{{$bonuses[$i]['value']}}{if($bonuses[$i]['type'] == 1)}{{$messages['RUB']}}{else}%{/if}</h4>
							<b style="font-size: 10px;line-height: 10px;color: #5b657d;font-weight: 600;">При пополнении от {{$bonuses[$i]['start']}} до {{$bonuses[$i]['end']}}{{$messages['RUB']}}</b>
						</div>
                          </div>
					</div>
				{/for}
			
		</div>
{/if}
-->
  
<!-- Заголовок -->
      <div class="top_info">
	 	<i class='bx bx-wallet'></i>
          <b class="pretext">Платежный агрегатор</b>
      </div>

	<div class="row pay_area">
		{foreach($merchants as $slug => $merchant)}
			{if($merchantsSettings->$slug == 1)}
				<div class="col-md-6">
					<div class="block_purse_base">
						<div class="block_head_purse">
							{{$merchant['title']}}
                          	<span class="line_purse"></span>
						</div>
						<label for="number_{{$slug}}">
							
						</label>
                          <label for="accused" style="margin-bottom: 20px;" class="custom-input with-title">
      <input  id="number_{{$slug}}" autocomplete="off" type="text" value="{price}" placeholder=" ">
      <span>Введите сумму</span>
	</label>
<button class="buy_purse" onclick="refill_balance('{{$slug}}');">Пополнить</button>
						<div id="balance_result_{{$slug}}" class="mt-3"></div>
						
					</div>
				</div>
			{/if}
		{/foreach}
	</div>

  <!-- Заголовок -->
      <div class="top_info">
	 	<i class='bx bx-history' ></i>
          <b class="pretext">История платежей</b>
      </div>
	<div class="block block-table" id="last_operations" style="padding: 15px;">
		<div class="table-responsive mb-0">
			<table class="table table-bordered">
				<thead>
				<tr style="background: #2d2d42;">
                    <td style="line-height: 49px;">Статус</td>
					<td style="line-height: 49px;">Сумма</td>
					<td style="line-height: 49px;">Тип операции</td>
					<td style="line-height: 49px;">Дата операции</td>
				</tr>
				</thead>
				<tbody id="operations">
				<tr>
					<td colspan="10">
						<div class="loader"></div>
						<script>get_operations();</script>
					</td>
				</tr>
				</tbody>
			</table>
		</div>
	</div>

	
</div>

<div class="col-lg-3 order-is-last">
    {include file="/parts/sidebar.tpl"}
</div>