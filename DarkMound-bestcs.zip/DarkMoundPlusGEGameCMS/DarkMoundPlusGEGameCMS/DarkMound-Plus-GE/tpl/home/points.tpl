<div id="points_result"></div>

<style>
	.category-point {
		position:absolute;
		top:10px;
		left:10px;
	}
	
	.card-to-points {
		padding:10px;
	}
</style>

<div class="col-lg-9 order-is-first">
	<h2 class="mb-3">Магазин бонусов</h2>

	<div class="block">
		<div class="text-muted" style="text-align:right;">
			У вас в наличии: {points} бонусов
		</div>
		<div class="row">
			{product_points_list}
		</div>
	</div>
</div>

<div class="col-lg-3 order-is-last">
	<h2 class="mb-3">Категории</h2>
	<div class="vertical-navigation">
		<ul>
			{category_points_list}
		</ul>
	</div>

	{include file="/parts/mini-profile.tpl"}
	
	{if("{{$steam_group_link}}" != "")}
		<a target="_blank" class="our-steam-group" href="/">
			<span>Магазин</span>
			<i class="fas fa-shopping-basket"></i>
		</a>
		<a target="_blank" class="our-steam-group" href="/">
			<span>Мы ВКонтакте</span>
			<i class="fab fa-vk"></i>
		</a>
	{/if}
</div>
<link href="{site_host}templates/admin/js/toasts/toasty.min.css" rel="stylesheet"/>
<script src="{site_host}templates/admin/js/toasts/toasty.min.js" type="text/javascript"></script>