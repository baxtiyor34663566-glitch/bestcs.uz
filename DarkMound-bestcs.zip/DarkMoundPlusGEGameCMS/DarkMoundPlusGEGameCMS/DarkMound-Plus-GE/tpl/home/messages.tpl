<script>
	$(".monitoring").remove();
	$("#hidden-menu").addClass("with-border");
</script>
</div>
</div>

<div class="container">
	<div class="row mt-5">
		<div class="col-lg-12 profile-page">
                     <div class="button-plateji">
                       
                        <!-- Заголовок -->
        <div class="top_info">
            <button id="back_btn" class="disp-n btn btn-primary btn-block-head btn-sm" onclick="load_dialogs();">К диалогам</button>
          <i class='bx bx-message-square-detail' ></i>
          <b class="pretext">Сообщения</b>
        </div>
               
			 </div>
			<div class="block_message_avalon">
			<div id="companions">
					<div class="loader mt-4"></div>
				</div>
              
			<div id="messages_sound_player"></div>
			<div class="block_mes_avalon">
		
				<div id="place_for_messages">
					<div class="loader mt-4"></div>
				</div>
			</div>
              
         </div>     
		</div>

		<script>
			var pm_interval;
			var check_mess;
			{load_dialogs}
			load_companions();
		</script>