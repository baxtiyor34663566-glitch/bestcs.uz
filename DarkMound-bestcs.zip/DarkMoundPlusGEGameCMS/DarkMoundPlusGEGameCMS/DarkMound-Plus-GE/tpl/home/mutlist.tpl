{if(is_worthy_specifically("s", {server}) && '{empty}' != '1')}
	<script src="{site_host}templates/admin/js/timepicker/timepicker.js"></script>
	<script src="{site_host}templates/admin/js/timepicker/jquery-ui-timepicker-addon.js"></script>
	<script src="{site_host}templates/admin/js/timepicker/jquery-ui-timepicker-addon-i18n.min.js"></script>
	<script src="{site_host}templates/admin/js/timepicker/jquery-ui-sliderAccess.js"></script>
{/if}
<div class="container" style="padding-right: 0px;padding-left: 0px;">
<div class="banlist">

<div class="col-lg-9 order-is-first">
<!-- Заголовок -->
        <div class="top_info" style="margin-bottom: -30px;">
          <i class='bx bx-volume-mute' ></i>
          <b class="pretext">Список мутов</b>
        </div>

	<div class="block" style="background: #fff0;">
		{if('{error}' == '')}

		<div class="table-adaptive table-fused mt-4" id="muts">
			{func GetData:mutlist("{start}","{server}","{limit}")}
		</div>
		{else}
		<div class="empty-element">
			{error}
		</div>
		{/if}
	</div>

	<div id="pagination2">{pagination}</div>
	
</div>

<div class="col-lg-3 order-is-last">
  
<div class="block_search">
			<div class="input-search mt mb">
               <i class="bx bx-search-alt" onclick="search_mute({server})" style="z-index: 1000;position: absolute;left: 1px;top: 28px;width: 40px;display: flex;height: 40px;color: #60608a;border-radius: 10px;background: #323249;font-size: 18px;cursor: pointer;justify-content: center;align-items: center;"></i>
			<label for="search_mute" class="custom-input with-title">
				<input id="search_mute" autocomplete="off" type="text" placeholder=" " style="background: #1a1a26;">
				<span>Введите никнейм / SteamID</span>
			</label>
			<script> set_enter('#search_mute', 'search_mute({server})'); </script>
		</div>
        	</div>
  
<div class="block_select_servers">
      <div class="head_new">
		<i class='bx bx-dice-3' ></i> Выберите сервер
      </div>
		<ul class="vertical-navigation">
			{servers}
		</ul>
	</div>

	{include file="/parts/sidebar.tpl"}
</div>
  </div>
   </div>