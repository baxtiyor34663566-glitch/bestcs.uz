<script>
	$(".monitoring").remove();
	$("#hidden-menu").addClass("with-border");
</script>
</div>
</div>

<div class="container">
	<div class="row mt-5">
		<div class="col-lg-3">
			{include file="/parts/sidebar.tpl"}
		</div>

		<div class="col-lg-9 profile-settings">
          
          
           <ul class="nav navigation-setting with-icons" style="background-image: url(../templates/DarkMound-Plus/img/setting.jpg);background-size: 920px;">
				<li>
					<a data-toggle="tab" href="#account">
                      <i class='bx bx-fullscreen'></i>
						Основные   
                      <span class="active-setting">ACTIVE</span>
					</a>
				</li>
				<li>
					<a data-toggle="tab" href="#contacts">
                      <i class='bx bx-book-content' ></i>
						Контакты
                      <span class="active-setting">ACTIVE</span>
					</a>
				</li>
				
				{if('{referral_program}' == '1')}
				<li>
					<a data-toggle="tab" href="#referral_program">
                      <i class='bx bx-dollar-circle' ></i>
						Реферал
                      <span class="active-setting">ACTIVE</span>
					</a>
				</li>
				{/if}
			</ul>
          
          
          
			<div class="tab-content">
				<div class="tab-pane fade" id="account">   
                <div class="block" style="padding: 20px 20px;padding-bottom: 0px;">  
                <div class="black_list">
                  <div class="black_list_left">
                   <i class='bx bx-error-alt' ></i>
                    <div class="black_list_text">
                      <span class="black_list_h1">Черный список</span>
                      <span class="black_list_h2">Здесь находится список пользователей, которых<br> вы заблокировали</span>
                    </div>
                     </div>
                  <button class="black_list_button"
                                data-target="#black-list"
                                data-toggle="modal"
                                onclick="getBlackList();">Открыть список</button>
                  </div>
                 <div class="block_setting_top">                 
                   <div class="block_setting_left">
                     <!-- Заголовок -->
                  <div class="top_info_index" style="margin-bottom: -5px;gap: 8px;display: flex;flex-direction: column;align-items: flex-start;">
                    <b class="pretext_index" style="font-size: 13px;    margin-bottom: -8px;">Общая информация</b>
                    <span class="line_purse"></span>
                  </div>
                   <div class="block" style="padding: 0px;">
								<label for="user_login" class="custom-input with-title with-button">
									<button onclick="edit_user_login();">
                                      <b>Сохранить</b>
									</button>
									<input id="user_login" maxlength="15" autocomplete="off" value="{login}" type="text" placeholder=" ">
									<span>Логин</span>
									<small id="edit_user_login_result"></small>
								</label>

								<label for="user_name" class="custom-input with-title with-button">
									<button type="button" onclick="edit_user_name();">
										<b>Сохранить</b>
									</button>
									<input id="user_name" maxlength="30" autocomplete="off" value="{name}" type="text" placeholder=" ">
									<span>Ваше имя</span>
									<small id="edit_user_name_result"></small>
								</label>	
                              <label for="user_nick" class="custom-input with-title with-button">
									<button type="button" onclick="edit_user_nick();">
										<b>Сохранить</b>
									</button>
									<input id="user_nick" maxlength="30" autocomplete="off" value="{nick}" type="text" placeholder=" ">
									<span>Ник на сервере</span>
									<small id="edit_user_nick_result"></small>
								</label>

								<label for="user_steam_id" class="custom-input with-title with-button mb-0">
									<button type="button" onclick="edit_user_steam_id();">
										<b>Сохранить</b>
									</button>
									<input id="user_steam_id" maxlength="32" autocomplete="off" value="{steam_id}" type="text" placeholder=" ">
									<span>Steam ID</span>
									<small id="edit_user_steam_id_result"></small>
								</label>
							</div>
                     
                       <!-- Заголовок -->
                  <div class="top_info_index" style="margin-bottom: -5px;gap: 8px;display: flex;flex-direction: column;align-items: flex-start;">
                    <b class="pretext_index" style="font-size: 13px;    margin-bottom: -8px;">Дата рождения</b>
                    <span class="line_purse"></span>
                  </div>
                     <div class="block" style="background: #20202f;margin-bottom: 10px;margin-top: 20px;padding: 0px 15px;">
                     <div class="row edit-date">
									<div class="col-3">
										<label for="birth_day" class="custom-select with-title">
											<select style="background:#36364e;" id="birth_day">{birth_day}</select>
											<span>День</span>
										</label>
									</div>
									<div class="col-3">
										<label for="birth_month" class="custom-select with-title">
											<select style="background: #36364e;" id="birth_month">{birth_month}</select>
											<span>Месяц</span>
										</label>
									</div>
									<div class="col-3">
										<label for="birth_year" class="custom-select with-title">
											<select style="background: #36364e;" id="birth_year">{birth_year}</select>
											<span>Год</span>
										</label>
									</div>
									<div class="col-3">
										<button type="button" class="btn btn-sm" onclick="edit_user_birth();" style="position: relative;top: 14px;height: 45px;width: 45px;margin-bottom: 16px;color: #777b88;display: flex;margin-left: 15px;align-items: center;justify-content: center;">
											<i class="far fa-pencil"></i>
										</button>
									</div>
									<div class="col-12">
										<small id="edit_user_birth_result" class="input-title"></small>
									</div>
								</div>
                       </div>
                     
                       <!-- Заголовок -->
                  <div class="top_info_index" style="margin-bottom: -5px;gap: 8px;display: flex;flex-direction: column;align-items: flex-start;">
                    <b class="pretext_index" style="font-size: 13px;    margin-bottom: -8px;">Безопасность</b>
                    <span class="line_purse"></span>
                  </div>
                    <div class="block" style="padding: 0px;    margin-bottom: 0px;">
								{if($user->password == 'none')}
								<label for="first_user_password" class="custom-input with-title">
									<input id="first_user_password" maxlength="15" autocomplete="off" type="password" placeholder=" ">
									<span>Новый пароль</span>
								</label>

								<label for="first_user_password2" class="custom-input with-title">
									<input id="first_user_password2" maxlength="15" autocomplete="off" type="password" placeholder=" ">
									<span>Повторите новый пароль</span>
								</label>

								<small class="input-title mt-1" id="edit_first_user_password_result"></small>
								<button class="btn btn-sm mt-2 mb-0" type="button" onclick="edit_first_user_password();">Сохранить изменения</button>
								{else}

								<label for="user_old_password" class="custom-input with-title">
									<input id="user_old_password" maxlength="15" autocomplete="off" type="password" placeholder=" ">
									<span>Текущий пароль</span>
								</label>

								<label for="user_password" class="custom-input with-title">
									<input id="user_password" maxlength="15" autocomplete="off" type="password" placeholder=" ">
									<span>Новый пароль</span>
								</label>

								<label for="user_password2" class="custom-input with-title mb-0">
									<input id="user_password2" maxlength="15" autocomplete="off" type="password" placeholder=" ">
									<span>Повторите новый пароль</span>
								</label>

								<small class="input-title mt-1" id="edit_user_password_result"></small>
								<button class="password_setting" type="button" onclick="edit_user_password();">Изменить пароль</button>
								{/if}
							</div>
                  </div>
                   
                   <div class="block_setting_right">
                      <!-- Заголовок -->
                  <div class="top_info_index" style="gap: 8px;display: flex;flex-direction: column;align-items: flex-start;">
                    <b class="pretext_index" style="font-size: 13px;    margin-bottom: -8px;">Аватар</b>
                    <span class="line_purse"></span>
                  </div>
                   <div class="block" style="background: #262639;padding: 16px;padding-bottom: 7px;">
								<div class="row edit-avatar">
									<div class="col-4">
										<img id="avatar" src="{avatar}" alt="Ваш аватар">
									</div>
									<div class="col-8" style="max-width: 100%;margin-left: -30px;">
										<form enctype="multipart/form-data" id="edit_user_avatar_form">
											<input type="hidden" id="token" name="token" value="{token}">
											<input type="hidden" id="edit_user_avatar" name="edit_user_avatar" value="1">
											<input type="hidden" id="phpaction" name="phpaction" value="1">

											<div class="custom-file mb-0">
												<input type="file" class="custom-file-input" id="user_avatar" accept="image/*" name="user_avatar">
												<label class="custom-file-label" for="user_avatar">Выбрать...</label>
											</div>

											
											<input class="btn btn-sm mt-2 mb-0" type="submit" value="Загрузить изображение" style="margin-top: 10px;">
											<div id="edit_user_avatar_result"></div>
										</form>
                                      
                                     
                                      
									</div>
								</div>
							</div>
                     
                     
                      <!-- Заголовок -->
                 <div class="top_info_index" style="gap: 8px;display: flex;flex-direction: column;align-items: flex-start;">
                    <b class="pretext_index" style="font-size: 13px;    margin-bottom: -8px;">Приватность</b>
                    <span class="line_purse"></span>
                  </div>
                     <div class="block edit-privacy" style="padding: 0px;margin-bottom: 0px;">
                      <div style="background: #262639;    padding: 16px 20px 32px 20px;border-radius: 13px;margin-bottom: 7px;">
						<p>Кто может писать мне личные сообщения?</p>
						<div class="custom-control custom-radio custom-control-inline" onclick="on_im(1);">
							<input type="radio" class="custom-control-input" id="im_radio_1" name="im_radio" {if('{im_radio_1}' == 'active')} checked {/if}>
							<label class="custom-control-label" for="im_radio_1">Все пользователи</label>
						</div>
						<div class="custom-control custom-radio custom-control-inline" onclick="on_im(2);">
							<input type="radio" class="custom-control-input" id="im_radio_2" name="im_radio" {if('{im_radio_2}' == 'active')} checked {/if}>
							<label class="custom-control-label" for="im_radio_2">Только друзья</label>
						</div>
                        </div>

                      <div style="background: #262639;    padding: 1px 20px 32px 20px;border-radius: 13px;margin-bottom: 7px;">
						<p class="mt-3">Дублировать ли уведомления на почту?</p>
						<div class="custom-control custom-radio custom-control-inline" onclick="on_email_notice(1);">
							<input type="radio" class="custom-control-input" id="notice_radio_1" name="notice_radio" {if('{notice_radio_1}' == 'active')} checked {/if}>
							<label class="custom-control-label" for="notice_radio_1">Дублировать</label>
						</div>
						<div class="custom-control custom-radio custom-control-inline" onclick="on_email_notice(2);">
							<input type="radio" class="custom-control-input" id="notice_radio_2" name="notice_radio" {if('{notice_radio_2}' == 'active')} checked {/if}>
							<label class="custom-control-label" for="notice_radio_2">Уведомлять только на сайте</label>
						</div>
					</div>
                      
                      <div style="background:#262639;    padding: 1px 20px 32px 20px;border-radius: 13px;margin-bottom: 7px;">
						<p class="mt-3">Привязать cookies к IP адресу?</p>
						<div class="custom-control custom-radio custom-control-inline" onclick="on_ip_protect(1);">
							<input type="radio" class="custom-control-input" id="protect_radio_1" name="protect_radio" {if('{protect_radio_1}' == 'active')} checked {/if}>
							<label class="custom-control-label" for="protect_radio_1">Включено</label>
						</div>
						<div class="custom-control custom-radio custom-control-inline mb-0" onclick="on_ip_protect(2);">
							<input type="radio" class="custom-control-input" id="protect_radio_2" name="protect_radio" {if('{protect_radio_2}' == 'active')} checked {/if}>
							<label class="custom-control-label" for="protect_radio_2">Выключено</label>
						</div>
                        </div>
					</div>
                  </div>
                   </div>
                   
                  </div>
              
						<script>$('#black-list').modal('hide');</script>
                            
						<div id="black-list" class="modal fade">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								 <!-- Заголовок -->
                <div class="top_info" style="margin-bottom: 5px;">
                  <i class='bx bx-block' ></i>
                  <b class="pretext">Черный список</b>
                </div>
							</div>
							<div class="modal-body">
								<div class="table-responsive mb-0">
									<table class="table table-bordered">
										<thead>
										<tr>
											<td>#</td>
											<td>Профиль</td>
											<td>Действие</td>
										</tr>
										</thead>
										<tbody id="black-list-content">
										<tr>
											<td colspan="10">
												<div class="loader"></div>
											</td>
										</tr>
										</tbody>
									</table>
								</div>
							</div>
                      </div>
                      </div>

                            
						
					</div>
				</div>
				<div class="tab-pane fade" id="contacts">
                  <div class="block" style="padding: 20px;padding-bottom: 10px;">
                    <div class="referal_block" style="background: #fff0;border: solid 1px #2b2b40;">
                  <div class="black_list_left">
                   <i class='bx bx-book-content' ></i>
                    <div class="black_list_text">
                      <span class="black_list_h1">Привяжите контакты</span>
                      <span class="black_list_h2">Для удобной связи - добавьте к профилю<br> свои контакты</span>
                    </div>
                     </div>
                  </div>
                    
                     <div class="block_setting_top" style="padding-bottom: 0px;">                 
                   <div class="block_setting_left1">
                     <!-- Заголовок -->
                                  <div class="top_info_index" style="    margin-bottom: -5px;gap: 8px;display: flex;flex-direction: column;align-items: flex-start;">
                    <b class="pretext_index" style="font-size: 13px;    margin-bottom: -8px;">Контакты</b>
                    <span class="line_purse"></span>
                  </div>
                     <label for="user_telegram" class="custom-input with-title with-button mb-0">
									<button type="button" onclick="edit_user_telegram();">
										Сохранить
									</button>
									<input id="user_telegram" maxlength="32" autocomplete="off" value="{telegram}" type="text" placeholder=" ">
									<span>Telegram</span>
									<div id="edit_user_telegram_result"></div>
								</label>
                              
                              	<label for="user_discord" class="custom-input with-title with-button mb-0" style="margin-top: 8px;">
									<button type="button" onclick="edit_user_discord();">
										Сохранить
									</button>
									<input id="user_discord" maxlength="32" autocomplete="off" value="{discord}" type="text" placeholder=" ">
									<span>Discord</span>
									<small id="edit_user_discord_result"></small>
								</label>
                     
                     </div>
                       
                        <div class="block_setting_right1">
                      <!-- Заголовок -->
                                  <div class="top_info_index" style="gap: 8px;display: flex;flex-direction: column;align-items: flex-start;">
                    <b class="pretext_index" style="font-size: 13px;    margin-bottom: -8px;">Социальные сети</b>
                    <span class="line_purse"></span>
                  </div>
                      {if($auth_api->vk_api == '2')}
					<div class="input-group">
						<div class="input-group-prepend">
							<button class="btn btn-outline-primary" type="button" onclick="edit_user_vk();">Изменить</button>
						</div>
						<input type="text" class="form-control" id="user_vk" maxlength="30" autocomplete="off" value="{vk}" placeholder="Введите свой ID в Вконтакте">
					</div>
					<div id="edit_user_vk_result"></div>
				{else}
					{if($user->vk_api == '0')}
						<div class="vk_block_setting" style="height: 47px;margin-bottom: 15px;">
                          <div style="display: flex;align-items: center;">
							<i class='bx bxl-vk'></i> 
                          	<span>Вконтакте</span>
                            </div>
                          <a class="button_vk_login" id="vk_attach_link" href="#">Прикрепить</a>
						</div>
					{else}
						<div class="vk_block_setting" style="margin-bottom: 13px;">
							<a style="display: flex;align-items: center;color: #fff;" target="_blank" href="https://vk.com/{vk}" id="vk_user">
								<i class='bx bxl-vk' ></i>
								<span>Загрузка...</span>
							</a>
                          <button class="button_contact_osn" type="button" onclick="unset_vk();"><i class='bx bx-x' style="font-size: 14px;margin-right: -10px;"></i></button>
							<script>get_vk_profile_info('{vk_api}', '#vk_user img', '#vk_user span', '{vk}');</script>
						</div>	
						<div id="unset_vk_result"></div>
					{/if}

					{conf_mess}
				{/if}
                    
                    
                    {if($auth_api->steam_api != '2')}
				{if('{steam_api}' == '0')}
                <div class="steam_block_setting" style="height: 47px;margin-top: -6px;margin-bottom: 13px;">
                          <div style="display: flex;align-items: center;">
							<i class='bx bxl-steam' ></i>
                          	<span>Steam</span>
                            </div>
                          <a class="button_steam_login" id="steam_attach_link" href="#">Прикрепить</a>
						</div>
				{else}
				<div class="steam_block_setting" style="margin-top: -6px;margin-bottom: 13px;">
					<a style="display: flex;align-items: center;" target="_blank" href="https://steamcommunity.com/profiles/{steam_api}/" id="steam_user">
						<i class='bx bxl-steam' ></i>
						<span>Загрузка...</span>
					</a>
                  <button class="button_contact_osn" onclick="unset_steam();" style="margin-bottom: -5px;"><i class='bx bx-x' style="font-size: 14px;margin-right: -10px;"></i></button>
					<script>get_user_steam_info('{steam_api}');</script>
				</div>
				<div id="unset_steam_result"></div>
				{/if}

				{conf_mess2}
			{/if}
                          
                     </div>     
                    </div>
    
                  </div>
                  
					
				</div>
				
				<div class="tab-pane fade" id="referral_program">

					{if('{referral_program}' == '1')}
                 <div class="block" style="padding: 20px;">
                   <div class="referal_block">
                  <div class="black_list_left">
                   <i class='bx bx-group' ></i>
                    <div class="black_list_text">
                      <span class="black_list_h1">Приведи друга - получи деньги</span>
                      <span class="black_list_h2">За каждого приведенного пользователя</span>
                    </div>
                     </div>
                  <div class="referal_procent">{referral_percent}% от пополнений</div>
                  </div>
                   
					<div class="info-referal">
                      <div class="referal_text">
                        <span class="referal_h1">Реферальная система</span>
						<span class="referal_h2">Реферальная система - это способ заработка, путем привлечения новых пользователей на сайт. <br>Мы выплачиваем <b>{referral_percent}%</b> от суммы пополнения ваших рефералов</span>
                      </div>
                      <div class="block-ref-link">
                        <div class="copy_link">
                          <span>{referral_link}</span> <button class="copyref" onclick="Copy('toCopy')" title="Скопировать ссылку"><i class='bx bx-copy-alt'></i></button>
                          </div>

                                  <div id="toCopy">{referral_link}</div>	
                        
                         <script type="text/javascript" >
                          function Copy(containerid) {
                                let textarea = document.createElement('textarea');
                                textarea.id = 'temp';
                                textarea.style.height = 0;
                                document.body.appendChild(textarea);
                                textarea.value = document.getElementById(containerid).innerText;
                                let selector = document.querySelector('#temp');
                                selector.select();
                                document.execCommand('copy');
                                document.body.removeChild(textarea);
                          }
                          </script>
                        
                       
							</div>
                  </div>
                  </div>

					<script>$('#referrals').modal('hide');</script>
					<div id="referrals" class="modal fade">
						<div class="modal-dialog modal-lg">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										<span aria-hidden="true">×</span>
									</button>
									<h4 class="modal-title">Список приглашенных друзей</h4>
								</div>
								<div class="modal-body">
									<div class="table-responsive mb-0">
										<table class="table table-bordered">
											<thead>
											<tr>
												<td>#</td>
												<td>Приглашенный друг</td>
												<td>Дата регистрации</td>
												<td>Прибыль</td>
											</tr>
											</thead>
											<tbody id="referrals_body">
											<tr>
												<td colspan="10">
													<div class="loader"></div>
												</td>
											</tr>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<script>$('#profit').modal('hide');</script>
					<div id="profit" class="modal fade">
						<div class="modal-dialog modal-lg">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										<span aria-hidden="true">×</span>
									</button>
									<h4 class="modal-title">Моя прибыль</h4>
								</div>
								<div class="modal-body">
									<div class="table-responsive mb-0">
										<table class="table table-bordered">
											<thead>
											<tr>
												<td>#</td>
												<td>Приглашенный друг</td>
												<td>Полученная сумма</td>
												<td>Дата зачисления</td>
											</tr>
											</thead>
											<tbody id="profit_body">
											<tr>
												<td colspan="10">
													<div class="loader"></div>
												</td>
											</tr>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					{/if}
				</div>
			</div>
		</div>

		<script>
			$(document).ready(function () {
				init_tinymce("signature", "lite", "{file_manager_theme}", "", "");
			});
			$("#edit_user_avatar_form").submit(function (event) {
				NProgress.start();
				event.preventDefault();
				var data = new FormData($('#edit_user_avatar_form')[0]);
				$.ajax({
					type: "POST",
					url: "ajax/actions_a.php",
					data: data,
					contentType: false,
					processData: false,
				}).done(function (html) {
					$("#edit_user_avatar_result").empty();
					$("#edit_user_avatar_result").append(html);
					$('#edit_user_avatar_form')[0].reset();
				});
				NProgress.done();
			});
		</script>

		<script>
			var anchor = window.location.hash.substr(1);

			if(anchor != "account" && anchor != "contacts" && anchor != "privacy" && anchor != "referral_program") {
				anchor = "account";
			}

			$("a[href='#"+anchor+"']").addClass("active");
			$("#"+anchor).addClass("active");
			$("#"+anchor).addClass("show");
		</script>