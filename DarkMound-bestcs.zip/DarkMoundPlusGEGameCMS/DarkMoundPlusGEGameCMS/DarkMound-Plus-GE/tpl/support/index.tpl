<div class="container">
<div class="two_top_menu">
        <div class="menu_top_left">
          
          <a href="../">
          <div class="menu_top_push">
            <i class='bx bx-home-alt-2' ></i> Главная
          </div>
          </a>
          
          <div class="menu_top_left">
            <a href="../news">
          <div class="menu_top_push">
            <i class='bx bx-globe' ></i> Новости
          </div>
           </a>
         </div> 
          
        <div class="menu_top_left">
          <a href="../forum">
          <div class="menu_top_push">
            <i class='bx bx-chat' ></i> Форум
          </div>
          </a>
         </div> 
          
          <div class="menu_top_left">
            <a href="../support">
          <div class="menu_top_push_active">
            <i class='bx bx-support' ></i> Поддержка
          </div>
           </a>
         </div> 
          </div>
        
         <div class="menu_top_rigth">
           
                     <a href="../users">
           <div class="search_user">
           <i class='bx bx-search'></i>
             <span>Foydalanuvchini qidirish</span>
           </div> 
           </a>
             
            <div class="qr_code_top" data-target="#promocode" data-toggle="modal">
             <i class='bx bx-scan' ></i> Promokod
           </div>
           
         </div> 
        </div> 
</div> 
<style>
  .two_menu_2 {
    display: none;
  }
  

</style>

<div class="container">
<div class="row_menu">

<div class="col-lg-9 order-is-first">

  <div class="block" style="padding: 20px;margin-bottom: 40px;">
     <div class="referal_block" style="background: #fff0;border: solid 1px #2c2c42;">
                  <div class="black_list_left">
                   <i class='bx bx-info-circle' ></i>
                    <div class="black_list_text">
                      <span class="black_list_h1">Появился вопрос</span>
                      <span class="black_list_h2">Задайте свой вопрос удобным для Вас способом<br>Мы с радостью ответим Вам в кротчайшие сроки</span>
                    </div>
                     </div>
       </div> 
       
       <div class="three_support">
         <div class="vk_support">
            <div style="display: flex;gap: 10px;align-items: center;">
           <div class="icon_support">
             <i class='bx bxl-vk' ></i>
           </div>
           <div style="display: flex;flex-direction: column;line-height: 16px;">
           <span style="font-weight: 600;">ВКонтакте</span>
           <span style="font-weight: 500;font-size: 10.5px;color: #ffffff8f;">Официальное сообщество</span>
           </div> 
               </div>
          
           <a href="https://vk.com/">
           <div class="send_support">
            <i class='bx bxs-send' ></i> Написать 
           </div> 
            </a>
           </div> 
         
         
          <div class="ticket_support">
             <div style="display: flex;gap: 10px;align-items: center;">
           <div class="icon_support">
            <i class='bx bx-support' ></i>
           </div>
           <div style="display: flex;flex-direction: column;line-height: 16px;">
           <span style="font-weight: 600;">Тикет</span>
           <span style="font-weight: 500;font-size: 10.5px;color: #ffffffa8;">Написать в поддержку</span>
           </div> 
               </div>
          
           <a href="../support/add_ticket">
           <div class="send_support">
            <i class='bx bxs-send' ></i> Написать 
           </div> 
            </a> 
            </div>
         </div>         
         
    
  </div>

 

  <div class="clearfix"></div>

 
    <div class="table-adaptive table-fused mt" id="tickets">
      <div class="loader"></div>
      <script>
        load_tickets('{id}');
      </script>
    </div>
  </div>



<div class="col-lg-3 order-is-last">
   {if(is_worthy("p"))}
  <div class="block" style="padding: 0px;background: #fff;margin-bottom: 50px;">
<a class="btn btn-outline-primary btn-xl" href="../support/all_tickets">
		Список обращений
	</a>
    </div>
  {/if}
  {include file="/parts/sidebar.tpl"}
</div>
  </div>
  </div>