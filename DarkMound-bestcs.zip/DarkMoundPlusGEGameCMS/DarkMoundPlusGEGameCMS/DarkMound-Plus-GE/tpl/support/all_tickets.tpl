<div class="container" style="padding-right: 0px;padding-left: 0px;">
<div class="banlist">

<div class="col-lg-9 order-is-first">
  <!-- Заголовок -->
        <div class="top_info">
          <i class='bx bx-sticker' ></i>
          <b class="pretext">Актуальные обращения</b>
        </div>

	<div class="block block-table" style="
    padding: 20px;
">
	
		<div class="tab-content">
			<div class="tab-pane fade show active" id="open-tickets-tab" role="tabpanel" aria-labelledby="open_tickets-tab">
				<div class="table-responsive mb-0">
					<table class="table table-bordered">
						<thead>
							<tr style="background: #2e2e42;height: 50px;">
								<td style="position: relative;line-height: 50px;">Тема</td>
								<td style="position: relative;line-height: 50px;">Закрыл</td>
								<td style="position: relative;line-height: 50px;">Последний ответ</td>
								<td style="position: relative;line-height: 50px;">Дата создания</td>
							</tr>
						</thead>
						<tbody id="open_tickets">
							<tr>
								<td colspan="10">
									<div class="loader"></div>
									<script>load_open_tickets();</script>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<div class="tab-pane fade" id="close-tickets-tab" role="tabpanel" aria-labelledby="close_tickets-tab">
				<div class="table-responsive mb-0">
					<table class="table table-bordered">
						<thead>
							<tr style="background: #2e2e42;height: 50px;">
								<td style="position: relative;line-height: 50px;">Тема</td>
								<td style="position: relative;line-height: 50px;">Закрыл</td>
								<td style="position: relative;line-height: 50px;">Последний ответ</td>
								<td style="position: relative;line-height: 50px;">Дата создания</td>
							</tr>
						</thead>
						<tbody id="close_tickets">
							<tr>
								<td colspan="10">
									<div class="loader"></div>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="col-lg-3 order-is-last">
  <div class="block_select_servers">
      <div class="head_new">
		<i class='bx bx-category' ></i> Выберите категорию
      </div>
	<ul class="nav vertical-navigation">
		<li>
			<a class="active" id="open-tickets-tab" data-toggle="tab" href="#open-tickets-tab">Открытые тикеты <span class="support_razdel">{count1}</span></a>
		</li>
		<li>
			<a id="open-tickets-tab" data-toggle="tab" href="#close-tickets-tab" onclick="load_close_tickets('first')">Закрытые тикеты <span class="support_razdel">{count2}</span></a>
		</li>
	</ul>
    </div>
</div>

    </div>
</div>