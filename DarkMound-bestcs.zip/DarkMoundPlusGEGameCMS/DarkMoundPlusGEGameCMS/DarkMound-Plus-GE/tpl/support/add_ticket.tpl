<div class="container">
<div class="two_top_menu">
        <div class="menu_top_left">
          
          <a href="../">
          <div class="menu_top_push">
            <i class='bx bx-home-alt-2' ></i> Главная
          </div>
          </a>
          
          <div class="menu_top_left">
            <a href="../news">
          <div class="menu_top_push">
            <i class='bx bx-globe' ></i> Новости
          </div>
           </a>
         </div> 
          
        <div class="menu_top_left">
          <a href="../forum">
          <div class="menu_top_push">
            <i class='bx bx-chat' ></i> Форум
          </div>
          </a>
         </div> 
          
          <div class="menu_top_left">
            <a href="../support">
          <div class="menu_top_push_active">
            <i class='bx bx-support' ></i> Поддержка
          </div>
           </a>
         </div> 
          </div>
        
         <div class="menu_top_rigth">
           
           <a href="../users">
           <div class="search_user">
           <i class='bx bx-search'></i>
             <span>Foydalanuvchini qidirish</span>
           </div> 
           </a>
           
            <div class="qr_code_top" data-target="#promocode" data-toggle="modal">
             <i class='bx bx-scan' ></i> Promokod
           </div>
           
         </div> 
        </div> 
</div> 
<style>
  .two_menu_2 {
    display: none;
  }
  

</style>

<div class="container">
<div class="row_menu">

<div class="col-lg-9 order-is-first">
   <!-- Заголовок -->
        <div class="top_info">
          <i class='bx bx-sticker' ></i>
          <b class="pretext">Создать обращение</b>
        </div>
  <div class="block">
    <div class="referal_block" style="margin-top: -9px;margin-bottom: 20px;">
                  <div class="black_list_left">
                 <i class='bx bx-info-circle' style="top: 0px;    background: linear-gradient(227deg, #40b481 0%, #258a5e 55%);font-size: 18px;"></i>
                    <div class="black_list_text">
                      <span class="black_list_h1">Опишите ситуацию</span>
                      <span class="black_list_h2">Раскройте суть ситуации со всеми<br> подробностями</span>
                    </div>
                     </div>
                  </div>
    
    <div class="form-group" style="margin-top: -27px;">      
    <label for="name" style="margin-bottom: 13px;" class="custom-input with-title">
      <input  id="name" autocomplete="off" type="text" placeholder=" ">
      <span>Тема обращения</span>
	</label>
    </div>

    <div class="form-group">
      <textarea id="text" rows="10" maxlength="2000"></textarea>
    </div>

    <div id="ticket_result"></div>

    <button onclick="add_ticket();" type="button" class="button-m" style="margin-top: 5px;">Создать обращение</button>
  </div>
</div>

<script>
  $(document).ready(function() {
    init_tinymce("text", "lite", "{file_manager_theme}", "{file_manager}", "{{md5($conf->code)}}");
  });
  $("#load_file_form").submit(function(event) {
    NProgress.start();
    event.preventDefault();
    var data = new FormData($('#load_file_form')[0]);
    $.ajax({
      type: "POST",
      url: "../ajax/actions_a.php",
      data: data,
      contentType: false,
      processData: false,
    }).done(function(html) {
      NProgress.done();
      $("#load_file_result").html(html);
      $('#load_file_form')[0].reset();
    });
  });
</script>

<div class="col-lg-3 order-is-last">
  {include file="/parts/mini-profile.tpl"} {include file="/parts/sidebar.tpl"}
</div>
  </div>
  </div>