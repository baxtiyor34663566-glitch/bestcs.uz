<div class="col-lg-6">
  <!-- Заголовок -->
        <div class="top_info">
          <i class='bx bx-info-circle' ></i>
          <b class="pretext">Информация</b>
        </div>
	<div class="div_edit_user">
      <div class="flip-tr">
          <span class="h1-tr">Тема обращения</span>
          <span class="h2-tr">{name}</span>
      	</div>
      <div class="flip-tr">
          <span class="h1-tr">Автор</span>
          <span class="h2-tr"><a target="_blank" href="../profile?id={author_id}">{author_login}</a></span>
      	</div>
      <div class="flip-tr">
          <span class="h1-tr">Статус</span>
          <span id="status" class="label label-{color}" style="font-weight: 600;">
        {if('{status}' == '1')}
				<span id="status" class="label label-info">Открыт</span>
			{else}
				<span id="status" class="label label-success">Закрыт</span>
			{/if}
        </span>
      	</div>
       <div class="flip-tr">
          <span class="h1-tr">Дата создания</span>
          <span class="h2-tr">{date}</span>
      	</div>

	</div>
	
</div>

<div class="col-lg-6">
  <!-- Заголовок -->
        <div class="top_info">
          <i class='bx bx-message-square-detail' ></i>
          <b class="pretext">Сообщение</b>
        </div>
	<div class="block ban-application ban-information" style="padding: 15px;">	 
		<div class="with_code" style="background: #1f1f2e;padding: 15px;border-radius: 10px;">
			{text}
		</div>
	</div>
  
	{if(('{status}' == '1') or (is_worthy("l")))}
           <!-- Заголовок -->
        <div class="top_info">
          <i class="bx bx-exit-fullscreen" style="background: linear-gradient(43deg, #b24141 0%, rgb(236 85 85) 55%);"></i>
          <b class="pretext">Действия</b>
        </div>
	<div class="block" style="padding: 10px;gap: 6px;border-radius: 11px;display: flex;">
		{if('{status}' == '1')}
			<button class="razban2" onclick="close_ticket('{id}')">Закрыть тикет</button>
		{/if}
		{if(is_worthy("l"))}
			<button class="razban3" onclick="dell_ticket('{id}')">Удалить тикет</button>
		{/if}
	</div>
	{/if}

           
</div>


<div class="col-lg-12">
	<div class="block">
      		<div class="block_head">
			<i class="bx bx-message-square-detail" style="width: 33px;background: #404059;display: flex;font-size: 14px;border-radius: 8px;color: #8484b6;margin-right: 11px;margin-left: -9px;height: 33px;align-items: center;justify-content: center;"></i> Комментарии / Обсуждение
		</div>
		<div id="add_ticket_answer">
			{if('{status}' == '1')}
				<textarea id="text"></textarea>
				<div class="smile_input_forum mt-3">
					<button id="send_btn" class="btn btn-primary" type="button" onclick="send_ticket_answer({id});">Отправить</button>
					<div id="smile_btn" class="smile_btn" data-container="body" data-toggle="popover" data-placement="top" data-content="empty"></div>
				</div>
			{/if}
		</div>
		<div id="answers" class="mt-3">
			<div class="loader"></div>
			<script>load_ticket_answers("{id}");</script>
		</div>
	</div>
</div>
<script>
	$(document).ready(function() {
		init_tinymce("text", "lite", "{file_manager_theme}", "{file_manager}", "{{md5($conf->code)}}");
		get_smiles('#smile_btn', 1);
	});

	$('#smile_btn').popover({ html: true, animation: true, trigger: "click" });
	$('#smile_btn').on('show.bs.popover', function () {
		$(document).mouseup(function (e) {
			var container = $(".popover-body");
			if (container.has(e.target).length === 0){
				$('#smile_btn').popover('hide');
				selected = 'gcms_smiles';
			}
		});
	});

	function set_smile(elem){
		var smile =  "<img src=\""+$(elem).attr("src")+"\" class=\"g_smile\" height=\"20px\" width=\"20px\">";
		tinymce.activeEditor.insertContent(smile);
		$('#smile_btn').popover('hide'); 
		selected = 'gcms_smiles';
	}
</script>