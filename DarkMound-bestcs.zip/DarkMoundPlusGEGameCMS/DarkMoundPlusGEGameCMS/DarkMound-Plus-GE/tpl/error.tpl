<div class="col-lg-12 order-is-first">
	<div class="noty-block error">
		<span style="font-size: 21px;color: #ff6161;margin-bottom: 10px;">Что-то пошло не так...</span>
		<span>{message}</span>
	</div>
</div>
