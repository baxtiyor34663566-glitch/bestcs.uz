<div class="col-lg-9 order-is-first">
   <div class="referal_block" style="background: #fff0;border: solid 1px #262639;">
                  <div class="black_list_left">
                  <i class='bx bx-lock-open-alt' style="top: 0px;font-size: 18px;"></i>
                    <div class="black_list_text">
                      <span class="black_list_h1">Заявки на разбан</span>
                      <span class="black_list_h2">Здесь Вы сможете обжаловать свою<br> блокировку</span>
                    </div>
                     </div>
                  </div>
  
  <div class="flex-double">   
    <a href="../bans/add_ban" class="add-click">
  	 <div style="display: flex;flex-direction: column;">
      <span class="h1-list">Добавить заявку</span>
      <span class="h2-list">Усомнились в своем бане? Создайте тикет на аппеляцию прямо сейчас <i class='bx bx-lock-open-alt' ></i></span>
    </div>
    </a>
    
   <a href="../complaints" class="return-click">
     <div style="display: flex;flex-direction: column;">
      <span class="h1-list">Подать жалобу</span>
      <span class="h2-list">Есть сведения о нарушении правил? Давайте разберем ситуацию <i class="bx bx-error-alt"></i></span>
    </div>
      </a>
  </div>


  <div class="clearfix"></div>

  <div class="block" style="background: #fff0;">
    <div class="table-adaptive table-fused mt" id="bans">
      {func GetData:bans_applications("{start}","{server}","{limit}")}
    </div>
  </div>

  <div id="pagination2">{pagination}</div>
</div>

<div class="col-lg-3 order-is-last">

  {include file="/parts/sidebar.tpl"}
</div>