<div class="col-lg-6">
  <!-- Заголовок -->
        <div class="top_info">
          <i class='bx bx-info-circle' ></i>
          <b class="pretext">Информация</b>
        </div>
	<div class="div_edit_user">
      <div class="flip-tr">
          <span class="h1-tr">Ник игрока</span>
          <span class="h2-tr">{nick}</span>
      	</div>
      <div class="flip-tr">
          <span class="h1-tr">Причина</span>
          <span class="h2-tr">{reason}</span>
      	</div>
      <div class="flip-tr">
          <span class="h1-tr">Статус блокировки</span>
          <span id="status" class="label label-{color}" style="font-weight: 600;">{status}</span>
      	</div>
         <div class="flip-tr">
          <span class="h1-tr">Пользователь</span>
          <span class="h2-tr" href="../profile?id={author_id}">{author_login}</span>
      	</div>
       <div class="flip-tr">
          <span class="h1-tr">Дата создания</span>
          <span class="h2-tr">{date}</span>
      	</div>
            <div class="flip-tr">
          <span class="h1-tr">Рассмотрел</span>
          {if('{closed}' != '0')}
          <span class="h2-tr" href="../profile?id={closed}">{closed_a}</span>
          {else}
          <span id="closed"></span>
		{/if}
      	</div>
		
	</div>
	
</div>
<div class="col-lg-6">
   <!-- Заголовок -->
        <div class="top_info">
          <i class='bx bx-info-circle' ></i>
          <b class="pretext">Материалы дела</b>
        </div>
	<div class="div_edit_user" style="padding: 20px;">
		<p class="mb-0"><b style="color: #777b88;">Комментарий игрока</b></p>
      <div class="noty-block info with_code mt-2" style="background-color: #353842;border-radius: 11px;font-size: 11px !important;margin-top: 7px;padding: 15px;padding-bottom: 0px;margin-bottom: 10px;padding-right: 0px;border: solid 1px #fff0;font-weight: 600;height: 100%;">
        <span>{text}</span></div>

		
		<p class="mb-0 mt-3"><b style="color: #777b88;">Демо</b></p>
		{if('{demo}' == '0')}
			<small style="color: #ffff;">Пользователь не указал ссылку на демо</small>
		{else}
			<a class="btn btn-outline-primary" href="{demo}" target="_blank">
				Скачать
			</a>
		{/if}
	</div>
  
  {if(('{bid}' != '0') || is_worthy_specifically("o", {server_id}) || is_worthy_specifically("i", {server_id}))}
   <!-- Заголовок -->
        <div class="top_info">
          <i class="bx bx-exit-fullscreen" style="background: linear-gradient(43deg, #b24141 0%, rgb(236 85 85) 55%);"></i>
          <b class="pretext">Действия</b>
        </div>
	<div class="block ban-application ban-information" style="padding: 10px;gap: 6px;border-radius: 11px;display: flex;">
		{if('{bid}' != '0')}
		<input type="hidden" class="form-control" id="search_ban" value="{bid}">
		<button onclick="search_ban_application({server_id})" type="button" class="razban1">Подробнее</button>

		<div id="ban" class="modal fade">
			<div class="modal-dialog modal-lg">
				<div class="modal-content" style="height: 670px;">
					<div class="modal-header">
					  <!-- Заголовок -->
                <div class="top_info" style="margin-bottom: -10px;">
                  <i class='bx bx-error-alt' ></i>
                  <b class="pretext">Подробная информация</b>
                </div>
				</div>
					<div class="modal-body" id="baninfo">
					</div>
				</div>
			</div>
		</div>
		{/if}
		{if(is_worthy_specifically("i", {server_id}))}
		<button onclick="close_ban({id},'1','{bid}');" type="button" class="razban2">Разбанить</button>
		<button onclick="close_ban({id},'2','{bid}');" type="button" class="razban3">Отказать</button>
		{/if}
		{if(is_worthy_specifically("o", {server_id}))}
		<button onclick="dell_ban({id});" type="button" class="razban4">Удалить</button>
		{/if}
	</div>
	{/if}
</div>

<div class="col-lg-12">
	<div class="block">
		<div class="block_head">
			<i class="bx bx-message-square-detail" style="width: 33px;background: #494c56;display: flex;font-size: 14px;border-radius: 8px;color: #777b88;margin-right: 11px;height: 33px;align-items: center;justify-content: center;"></i> Комментарии / Обсуждение
		</div>
		{if(is_auth())}
			<div id="add_new_comments">
				<textarea id="text" maxlength="500"></textarea>

				<div class="smile_input_forum mt-3">
					<input id="send_btn" class="btn btn-primary" type="button" onclick="send_ban_comment({id});" value="Отправить">
					<div id="smile_btn" class="smile_btn" data-container="body" data-toggle="popover" data-placement="top" data-content="empty"></div>
				</div>
			</div>
			<script>
				$(document).ready(function() {
					init_tinymce("text", "lite", "{file_manager_theme}", "{file_manager}", "{{md5($conf->code)}}");
					get_smiles('#smile_btn', 1);
				});

				$('#smile_btn').popover({ html: true, animation: true, trigger: "click" });
				$('#smile_btn').on('show.bs.popover', function () {
					$(document).mouseup(function (e) {
						var container = $(".popover-body");
						if (container.has(e.target).length === 0){
							$('#smile_btn').popover('hide');
							selected = 'gcms_smiles';
						}
					});
				});

				function set_smile(elem){
					var smile =  "<img src=\""+$(elem).attr("src")+"\" class=\"g_smile\" height=\"20px\" width=\"20px\">";
					tinymce.activeEditor.insertContent(smile);
					$('#smile_btn').popover('hide');
					selected = 'gcms_smiles';
				}
			</script>
		{/if}
		<div id="comments" class="mt-3">
			<div class="loader"></div>
			<script>load_ban_comments("{id}");</script>
		</div>
	</div>