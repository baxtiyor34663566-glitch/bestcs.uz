<div class="col-lg-9 order-is-first">
  <!-- Заголовок -->
        <div class="top_info">
          <i class='bx bx-lock-open-alt' ></i>
          <b class="pretext">Добавить заявку</b>
        </div>
	<div class="block">

		<div class="form-group">
			<label for="birth_day" class="custom-select with-title" style="margin-top: -25px;margin-bottom: 20px;">
			<select id="server" onchange="local_change_server();">{servers}</select>
				<span>Выберите сервер</span>
		</label>
		</div>
          <div class="form-group" style="margin-top: -27px;">      
    <label for="nick" style="margin-bottom: 20px;" class="custom-input with-title">
      <input  id="nick" autocomplete="off" type="text" placeholder=" ">
      <span>Ваш никнейм</span>
	</label>
    </div>
      
    <div class="form-group" style="margin-top: -27px;">      
    <label for="reason" style="margin-bottom: 20px;" class="custom-input with-title">
      <input  id="reason" autocomplete="off" type="text" placeholder=" ">
      <span>Причина бана</span>
	</label>
    </div>
 

		<div id="db" class="disp-n">
			<div class="form-group">
				          <div class="form-group" style="margin-top: -27px;">      
    <label for="nick_db" style="margin-bottom: 20px;" class="custom-input with-title">
      <input  id="nick_db" autocomplete="off" type="text" placeholder=" ">
      <span>Ваш SteamID или никнейм</span>
	</label>
    </div>
				<button class="btn btn-outline-primary mt-3" onclick="find_bans();">Найти</button>
				<div id="bans_table" class="table-responsive mb-0 mt-3 disp-n">
					<table class="table table-bordered">
						<thead>
							<tr>
								<td>Действие</td>
								<td>Ник</td>
								<td>Причина</td>
								<td>Дата окончания</td>
							</tr>
						</thead>
						<tbody id="search_ban_res_min">
							<tr>
								<td colspan="10">
									<div class="loader"></div>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				<div id="search_ban_res_full" class="mt-3"></div>
			</div>
		</div>

		<div id="dop" class="disp-n">
			<div class="form-group">
				<b style="color: #6e6e88;position: relative;top: -5px;">Подробное пояснение</b><br>
				<textarea id="text" rows="3" maxlength="2000"></textarea>
			</div>
			
          
           <div class="form-group" style="margin-top: -20px;">      
    <label for="demo" style="margin-bottom: 20px;" class="custom-input with-title">
      <input  id="demo" autocomplete="off" type="text" placeholder=" ">
      <span>Ссылка на демо (Необязательно)</span>
	</label>
    </div> 
		

			<div id="new_result" class="mt-10"></div>
			<button id="create_btn" onclick="add_ban();" type="button" class="button-m">Создать заявку</button>
		</div>
	</div>
</div>

<script>
	$(document).ready(function() {
		init_tinymce("text", "lite", "{file_manager_theme}", "{file_manager}", "{{md5($conf->code)}}");
	});
	$("#add_img_form").submit(function (event){
		NProgress.start();
		event.preventDefault();
		var data = new FormData($('#add_img_form')[0]);
		$.ajax({
			type: "POST",
			url: "../ajax/actions_a.php",
			data: data,
			contentType: false,
			processData: false,
		}).done(function (html) {
			NProgress.done();
			$("#img_result").empty();
			$("#img_result").append(html);
			$('#add_img_form')[0].reset();
		});
	});
	
	function local_change_server() {
		var server_type = $('#server option:selected').attr('data-server-type');
		select_ban_type(server_type);
	}
	local_change_server();
</script>

<div class="col-lg-3 order-is-last">
	{include file="/parts/sidebar.tpl"}
</div>