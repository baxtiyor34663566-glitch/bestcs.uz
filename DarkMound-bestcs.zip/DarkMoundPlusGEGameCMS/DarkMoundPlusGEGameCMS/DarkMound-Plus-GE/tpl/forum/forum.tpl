<script>
    $(".monitoring").remove();
</script>
</div>
</div>

<style>
  .two_menu_2 {
    display: none;
  }
</style>

<div class="container">
  {if(is_auth())}
  <div class="two_top_menu">
        <div class="menu_top_left">
          
          <a href="../">
          <div class="menu_top_push">
            <i class='bx bx-home-alt-2' ></i> Главная
          </div>
          </a>
          
          <div class="menu_top_left">
            <a href="../news">
          <div class="menu_top_push">
            <i class='bx bx-globe' ></i> Новости
          </div>
           </a>
         </div> 
          
        <div class="menu_top_left">
          <a href="../forum">
          <div class="menu_top_push_active">
            <i class='bx bx-chat' ></i> Форум
          </div>
          </a>
         </div> 
          
          <div class="menu_top_left">
            <a href="../support">
          <div class="menu_top_push">
            <i class='bx bx-support' ></i> Поддержка
          </div>
           </a>
         </div> 
          </div>
        
         <div class="menu_top_rigth">
           
           <a href="../users">
           <div class="search_user">
           <i class='bx bx-search'></i>
             <span>Foydalanuvchini qidirish</span>
           </div> 
           </a>
           
            <div class="qr_code_top" data-target="#promocode" data-toggle="modal">
             <i class='bx bx-scan' ></i> Promokod
           </div>
           
         </div> 
        </div> 
  {/if}
   <div class="block" style="padding: 10px;margin-top: -10px;">
    <div class="block_back">
  <ul class="forum_next">
		{{$nav}} 
		</ul>
    <a href="../forum/" class="back_forum">Вернуться</a>
    </div>
        </div> 
  <div class="row">
<div class="col-lg-9 order-is-first">
  <!-- Заголовок -->
      <div class="top_info">
        {if(is_worthy("b"))}
	<a href="../forum/add_topic?id={id}">
        <button class="add_forum">+</button>
        </a>
        {/if}
	 	<i class='bx bx-customize'></i>
          <b class="pretext">{name}</b>
      </div>
  

  <div class="block" id="forum_topics">
		<div class="row" style="background: #20202f;margin: 0px;border-radius: 12px;">
			{func Forum:get_forum("{id}","{start}","{limit}")}
		</div>
      </div>
    </div>
    <div class="col-lg-3 order-is-last">

  {include file="/parts/sidebar.tpl"}
</div>
   

  