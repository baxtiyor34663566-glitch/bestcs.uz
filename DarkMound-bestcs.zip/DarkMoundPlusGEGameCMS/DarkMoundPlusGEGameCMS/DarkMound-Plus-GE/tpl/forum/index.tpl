{if(is_auth())}
<div class="container">
<div class="two_top_menu">
        <div class="menu_top_left">
          
          <a href="../">
          <div class="menu_top_push">
            <i class='bx bx-home-alt-2' ></i> Главная
          </div>
          </a>
          
          <div class="menu_top_left">
            <a href="../news">
          <div class="menu_top_push">
            <i class='bx bx-globe' ></i> Новости
          </div>
           </a>
         </div> 
          
        <div class="menu_top_left">
          <a href="../forum">
          <div class="menu_top_push_active">
            <i class='bx bx-chat' ></i> Форум
          </div>
          </a>
         </div> 
          
          <div class="menu_top_left">
            <a href="../support">
          <div class="menu_top_push">
            <i class='bx bx-support' ></i> Поддержка
          </div>
           </a>
         </div> 
          </div>
        
         <div class="menu_top_rigth">
           
           <a href="../users">
           <div class="search_user">
           <i class='bx bx-search'></i>
             <span>Foydalanuvchini qidirish</span>
           </div> 
           </a>
            
             <div class="qr_code_top" data-target="#promocode" data-toggle="modal">
             <i class='bx bx-scan' ></i> Promokod
           </div>
           
         </div> 
        </div> 
</div> 
{/if}
<style>
  .two_menu_2 {
    display: none;
  }
  

</style>

<div class="container">
<div class="row_menu">
<div class="col-lg-9 order-is-first">

  <div class="button-plateji">
   <!-- Заголовок -->
      <div class="top_info">
        {if(is_worthy("b"))}
		<a href="../forum/edit_forum">
        <button class="add_news">Настройки</button>
        </a>
        {/if}
	 	<i class='bx bx-customize'></i>
          <b class="pretext">Форум проекта</b>
      </div>
 
  </div>

  <div class="clearfix"></div>
  <div id="forum">
    {func Forum:get_forums()}
  </div>

</div>
<div class="col-lg-3 order-is-last">

  {include file="/parts/sidebar.tpl"}
</div>
</div>
  </div>