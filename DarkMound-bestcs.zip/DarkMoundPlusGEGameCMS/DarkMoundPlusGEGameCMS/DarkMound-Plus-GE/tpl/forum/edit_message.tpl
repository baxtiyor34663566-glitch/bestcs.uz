<script>
    $(".monitoring").remove();
</script>
</div>
</div>


	<div class="container">
  <div class="block" style="padding: 15px 15px 0px 15px;margin-top: -40px;">
    <div class="block_back">
  <ul class="forum_next">
		{{$nav}} 
		</ul>
    <a href="../forum/forum?id={id2}" class="back_forum">Вернуться</a>
    </div>

  <div class="block" style="display: flex;    padding: 20px 0px; justify-content: space-between;" >
		<div style="display: flex;align-items: center;">
		<span style="font-size: 16px;font-weight: 600;">
			{if('{status}' == '3' || '{status}' == '4')}
			<i class="far fa-paperclip" tooltip="yes" title="Тема закреплена" style="background: #313544;padding: 11px;font-size: 12px;color: #757985;width: 33px;height: 33px;border-radius: 9px;"></i>
			{/if}
			{if('{status}' == '2' || '{status}' == '4')}
			<i class="far fa-lock" tooltip="yes" title="Тема закрыта" style="background: #313544;padding: 11px;font-size: 12px;color: #757985;width: 33px;height: 33px;border-radius: 9px;"></i>
			{/if}

          <span style="margin-left: 15px;">{name}</span>
		</span>
    </div>
    
    <div style="display: flex;">
      
		<p class="forum_deatails" style="position: relative;top: -2px;">
          <span tooltip="yes" title="Просмотров">Просмотров: <b style="color: #ffff;margin-left: 2px;">{{$topic->views}}</b></span>
			<span tooltip="yes" title="Ответов" style="border-left: solid 1px #404454;padding-left: 10px;margin-left: 10px;">Ответов: <b style="color: #ffff;margin-left: 2px;">{{$topic->answers}}</b></span>
		</p>


			
       </div>
  </div>
    </div>
	</div>



<div class="container">
	<div class="block mt-5" style="margin-top: 30px;">
		<textarea id="text" rows="10">{text}</textarea>

		<div class="smile_input_forum mt-3">
			<button id="create_btn" onclick="edit_message('{id}');" type="button" class="btn btn-primary">Изменить</button>
			<div id="smile_btn" class="smile_btn" data-container="body" data-toggle="popover" data-placement="top" data-content="empty"></div>
		</div>
		<div id="topic_result"></div>

		<script>
            $(document).ready(function () {
                init_tinymce("text", "forum", "{file_manager_theme}", "{file_manager}", "{{md5($conf->code)}}");
                get_smiles('#smile_btn', 1);
            });

            $('#smile_btn').popover({html: true, animation: true, trigger: "click"});
            $('#smile_btn').on('show.bs.popover', function () {
                $(document).mouseup(function (e) {
                    var container = $(".popover-body");
                    if (container.has(e.target).length === 0) {
                        $('#smile_btn').popover('hide');
                        selected = 'gcms_smiles';
                    }
                });
            });

            function set_smile(elem) {
                var smile = "<img src=\"" + $(elem).attr("src") + "\" class=\"g_smile\" height=\"20px\" width=\"20px\">";
                tinymce.activeEditor.insertContent(smile);
                $('#smile_btn').popover('hide');
                selected = 'gcms_smiles';
            }
		</script>
