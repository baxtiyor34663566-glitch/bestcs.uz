{if(is_worthy("t"))}
<div class="col-lg-12">
	<div class="block" style="padding: 15px;padding-bottom: 5px;"> 
		<div class="row">
			<div class="col-lg-6">
				<a data-target="#add_section" data-toggle="modal" class="forum_setting_button">Добавить раздел</a>
			</div>
			<div class="col-lg-6">
				<a data-target="#add_forum" onclick="load_sections_list();" data-toggle="modal" class="forum_setting_button">Добавить форум</a>
			</div>
		</div>
	</div>
</div>
{/if}

<div class="col-lg-12">
	<div id="sections">
		<div class="loader"></div>
		<script>load_sections();</script>
	</div>
</div>

<div id="add_section" class="modal fade">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				 <!-- Заголовок -->
                <div class="top_info">
                  <i class='bx bx-folder'></i>
                  <b class="pretext">Добавить раздел</b>
                </div>
			</div>
			<div class="modal-body">
				<form id="section_settings">
					<div class="form-group">
						<b>Название</b>
						<input type="text" class="form-control" name="section_name" id="section_name" maxlength="255" autocomplete="off">
					</div>
					<div class="form-group">
						
						<div class="btn-group-toggle" data-toggle="buttons" id="access">
							{groups}
						</div>
					</div>

					<button onclick="add_section();" type="button" class="btn btn-primary mt-3">Создать</button>
				</form>
			</div>
		</div>
	</div>
</div>

<div id="add_forum" class="modal fade">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				 <!-- Заголовок -->
                <div class="top_info">
                  <i class='bx bx-objects-horizontal-left'></i>
                  <b class="pretext">Добавить форум</b>
                </div>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<span for="section_name">
						<b>Изображение</b>
					</span>
					<div class="row">
						<div class="col-lg-2">
							<img id="image" src="../files/forums_imgs/none.jpg" class="w-100" alt="Изображение форума">
						</div>
						<div class="col-lg-10">
							<div class="input-group" >
								<form enctype="multipart/form-data" action="ajax/actions_c.php" method="POST" id="img_form">
									<input type="hidden" id="token" name="token" value="{token}">
									<input type="hidden" id="id" name="id" value="">
									<input type="hidden" id="load_forum_img" name="load_forum_img" value="1">
									<input type="hidden" id="phpaction" name="phpaction" value="1">

									<div class="custom-file">
										<input type="file" class="custom-file-input" id="img" accept="image/*" name="img">
										<label class="custom-file-label" for="img">Выбрать...</label>
									</div>

									<div id="img_result" class="mt-1"></div>
									<button class="btn btn-primary btn-sm mt-2" type="submit">Загрузить</button>
								</form>
								<script>
                                    $("#img_form").submit(function (event) {
                                        NProgress.start();
                                        event.preventDefault();
                                        var data = new FormData($('#img_form')[0]);
                                        $.ajax({
                                            type: "POST",
                                            url: "../ajax/actions_c.php",
                                            data: data,
                                            contentType: false,
                                            processData: false,
                                            beforeSend: function () {
                                                $('#img_loader').show();
                                            }
                                        }).done(function (html) {
                                            $("#img_result").empty();
                                            $("#img_result").append(html);
                                            $('#img_form')[0].reset();
                                            NProgress.done();
                                        });
                                    });
								</script>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<b>Название</b>
					<input type="text" class="form-control" id="forum_name" maxlength="255" autocomplete="off">
				</div>
				<div class="form-group">
					<b>Описание</b>
					<input type="text" class="form-control" id="forum_description" maxlength="255" autocomplete="off">
				</div>
				<div class="form-group">
					<b>Раздел</b>
					<div id="sections_list"></div>
				</div>
				<div id="add_forum_result"></div>
				<button onclick="add_forum();" type="button" class="btn btn-primary mt-3">Создать</button>
			</div>
		</div>
	</div>
</div>