<script>
    $(".monitoring").remove();
</script>
</div>
</div>

<style>
  .two_menu_2 {
    display: none;
  }
</style>

<div class="container">
  {if(is_auth())}
   <div class="two_top_menu">
        <div class="menu_top_left">
          
          <a href="../">
          <div class="menu_top_push">
            <i class='bx bx-home-alt-2' ></i> Главная
          </div>
          </a>
          
          <div class="menu_top_left">
            <a href="../news">
          <div class="menu_top_push">
            <i class='bx bx-globe' ></i> Новости
          </div>
           </a>
         </div> 
          
        <div class="menu_top_left">
          <a href="../forum">
          <div class="menu_top_push_active">
            <i class='bx bx-chat' ></i> Форум
          </div>
          </a>
         </div> 
          
          <div class="menu_top_left">
            <a href="../support">
          <div class="menu_top_push">
            <i class='bx bx-support' ></i> Поддержка
          </div>
           </a>
         </div> 
          </div>
        
         <div class="menu_top_rigth">
           
           <a href="../users">
           <div class="search_user">
           <i class='bx bx-search'></i>
             <span>Foydalanuvchini qidirish</span>
           </div> 
           </a>
            
            <div class="qr_code_top" data-target="#promocode" data-toggle="modal">
             <i class='bx bx-scan' ></i> Promokod
           </div>
           
         </div> 
     </div> 
{/if}
  <div class="block" style="padding: 10px;margin-top: -10px;">
    <div class="block_back">
  <ul class="forum_next">
		{{$nav}} 
		</ul>
    <a href="../forum" class="back_forum">Вернуться</a>
    </div>
        </div> 
  <!-- Заголовок -->
      <div class="top_info_forum">
        {if(is_worthy("e"))}
		<a href="#" onclick="dell_topic('{id}' , '{id2}');" class="add_forum1">
			<i class="far fa-trash"></i>
		</a>
		{/if}
		{if((is_worthy("e")) || (is_auth() && '{author_id}' == '{my_id}'))}
		<a href="../forum/edit_topic?id={id}" class="add_forum1">
			<i class="far fa-pencil"></i>
		</a>
		{/if}

	 	<i class='bx bx-customize'></i>
          <b class="pretext">{name}</b>
      </div>
  
  
	<div id="answers" class="topic-answers">
		{if('{page}' == '1')}
		<div id="answer_0" class="forum_eb">
			<div class="left-side">
              
               <div class="block_fbrs_forum" style="background-image: url(../templates/DarkMound-Plus-GE/img/profile_back.png);background-size: cover;">
          <div style="display: flex;align-items: center;">
         <a href="../profile?id={author_id}">
		<img src="../{author_avatar}" alt="{login}" class="avatarprofile">
            </a>
          <div class="text_forum">
            <p class="username">{author_login}</p>
            <span class="lastname">{group_name}</span>
          </div>
                 </div>
                 <button class="answer_forum" onclick="answer(0, '{author_login}', '{link}');">
						<i class='bx bx-share'></i>
					</button>
                 </div>
              
				<div style="display: flex;flex-direction: column;">
				<span class="forum_profile_reaction">
                  <i class='bx bx-heart' ></i> 
                  <div class="reaction_block">
                  Реакций 
                  <b style="color: #ffff;">{thanks}</b>
                  </div>
				</span>
                  
				<span class="forum_profile_reaction">
                  <i class='bx bx-message-square-detail' ></i>
                  <div class="reaction_block">
                  Ответов 
                  <b style="color: #ffff;">{answers}</b>
                  </div>
				</span>
                  
				<span class="forum_profile_reaction">
                  <i class='bx bx-star' ></i> 
                  <div class="reaction_block">
                  Рейтинг 
                  <b style="color: #ffff;">{reit}</b>
                  </div>
				</span>
                  </div>
              
              <div style="display: flex;margin-top: 7px;justify-content: space-between;">
              {if('{author_id}' != '{my_id}')}
					<button class="like_forum" onclick="thank({id}, 1);">
						Поблагодарить
					</button>
					{/if}
			</div>
              
			</div>

			<div class="right-side">
				 <span class="date_forum">{date}</span>
				<div id="text_0" class="with_code">
					{text}
				</div>
				{if('{signature}' != '')}
				<div class="with_code signature">
					{signature}
				</div>
				{/if}

				<div class="clearfix"></div>
{if('{edited_by_id}' != '')}<span class="editeds" style="color: #576178;font-weight: 600;margin-bottom: 20px;">Отредактировал: <a href="../profile?id={edited_by_id}" title="{edited_by_login}">{edited_by_login}</a>, {edited_time}</span>{/if}
				{thanks_str}

			</div>
		</div>
		{/if}

		{func Forum:get_answers("{id}", "{start}", "{limit}", "{script}", "{link}")}
	</div>

	<div id="pagination2" class="mt-4">{pagination}</div>

	{if(is_auth())}
   <!-- Заголовок -->
      <div class="top_info">
	 	<i class='bx bx-message-square-detail' ></i>
          <b class="pretext">Оставить ответ</b>
      </div>
	<div class="block mt-4">
		{if('{status}' == '1' or '{status}' == '3')}
		<div id="send_answer">
			<textarea id="text"></textarea>
			<div class="smile_input_forum mt-3">
				<button id="send_btn" class="btn btn-primary" type="button" onclick="send_answer('{id}');">Отправить</button>
				<div id="smile_btn" class="smile_btn visible-lg-inline-block" data-container="body" data-toggle="popover" data-placement="top" data-content="empty"></div>
			</div>
		</div>
		{else}
		<div class="empty-element"><i class="bx bx-lock-alt" style="font-size: 19px;margin-right: 10px;position: relative;top: 3px;color: #5086ff;"></i> В этой теме нельзя размещать новые ответы<span class="glyphicon glyphicon-ban-circle"></span></div>
		{/if}
	</div>
	{/if}

	<script>
        $(document).ready(function () {
            init_tinymce("text", "forum", "{file_manager_theme}", "{file_manager}", "{{md5($conf->code)}}");
            get_smiles('#smile_btn', 1);
        });

        $('#smile_btn').popover({html: true, animation: true, trigger: "click"});
        $('#smile_btn').on('show.bs.popover', function () {
            $(document).mouseup(function (e) {
                var container = $(".popover-body");
                if (container.has(e.target).length === 0) {
                    $('#smile_btn').popover('hide');
                    selected = 'gcms_smiles';
                }
            });
        });

        function set_smile(elem) {
            var smile = "<img src=\"" + $(elem).attr("src") + "\" class=\"g_smile\" height=\"20px\" width=\"20px\">";
            tinymce.activeEditor.insertContent(smile);
            $('#smile_btn').popover('hide');
            selected = 'gcms_smiles';
        }
	</script>
	<div>