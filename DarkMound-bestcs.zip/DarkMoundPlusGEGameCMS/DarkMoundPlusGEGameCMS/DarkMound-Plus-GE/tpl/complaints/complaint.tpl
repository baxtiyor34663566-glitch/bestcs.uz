<div class="col-lg-6">
  <!-- Заголовок -->
        <div class="top_info">
          <i class='bx bx-info-circle' ></i>
          <b class="pretext">Информация</b>
        </div>
    <div class="div_edit_user">
      
       <div class="flip-tr">
          <span class="h1-tr">Сервер</span>
          <span class="h2-tr">{server_name}</span>
      	</div>
      <div class="flip-tr">
          <span class="h1-tr">Нарушитель</span>
        	{if('{accused_id}' == '0')}Не зарегистрирован{else}
          <span class="h2-tr">{accused_login}</span>
        	{/if}
      	</div>
      <div class="flip-tr">
          <span class="h1-tr">Статус блокировки</span>
          <span id="status" class="text-warning">{status}</span>
      	</div>
         <div class="flip-tr">
          <span class="h1-tr">Идентификатор нарушителя</span>
          <span class="h2-tr" data-target="#services" data-toggle="modal" title="Подробнее" onclick="get_admin_info2({accused_admin_id})">{accused_admin_nick}</span>
      	</div>
       <div class="flip-tr">
          <span class="h1-tr">Автор </span>
          <span class="h2-tr" href="../profile?id={author_id}">{author_login}</span>
      	</div>
       <div class="flip-tr">
          <span class="h1-tr">Дата создания</span>
          <span class="h2-tr">{date}</span>
      	</div>
            <div class="flip-tr">
          <span class="h1-tr">Рассмотрел</span>
          {if('{judge_id}' != '')}
          <span class="h2-tr" href="../profile?id={judge_id}">{judge_login}</span>
          {else}
          <span id="closed"></span>
		{/if}
      	</div>

        <div id="services" class="modal fade">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                        <h4 class="modal-title">Услуги</h4>
                    </div>
                    <div class="modal-body">
                        <div class="table-responsive mb-0">
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <td>#</td>
                                    <td>Услуга</td>
                                    <td>Дата покупки</td>
                                    <td>Дата окончания</td>
                                    <td>Осталось</td>
                                </tr>
                                </thead>
                                <tbody id="admin_info{accused_admin_id}">
                                <tr>
                                    <td colspan="10">
                                        <div class="loader"></div>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

       
    </div>

   
</div>

<div class="col-lg-6">
  <!-- Заголовок -->
        <div class="top_info">
          <i class='bx bx-info-circle' ></i>
          <b class="pretext">Материалы дела</b>
        </div>
    <div class="block">
        <p class="mb-0"><b style="color:#777b88;">Комментарий автора</b></p>
        <div class="noty-block with_code mt-2" style="background-color: #353842;border-radius: 11px;font-size: 11px !important;margin-top: 7px;padding: 15px;padding-bottom: 0px;margin-bottom: 10px;padding-right: 0px;border: solid 1px #fff0;font-weight: 600;height: 100%;">{description}</div>

        <p class="mb-0"><b>Скриншоты</b></p>
        {if('{screens}' == '')}
            <small>Пользователь не прикрепил скриншотов</small>
        {else}
            {screens}
        {/if}

        <p class="mb-0 mt-2"><b>Демо</b></p>
        {if('{demo}' == '')}
            <small>Пользователь не указал ссылку на демо</small>
        {else}
            <a class="btn btn-outline-primary" href="{demo}" target="_blank">
                Скачать
            </a>
        {/if}
    </div>
   {if((is_worthy_specifically("k", {server_id}) || is_worthy_specifically("u", {server_id}) && '{sentence}' == '0') || ('{sentence}' != '0' && is_worthy_specifically("u", {server_id})))}
       <!-- Заголовок -->
        <div class="top_info">
          <i class="bx bx-exit-fullscreen" style="background: linear-gradient(43deg, #b24141 0%, rgb(236 85 85) 55%);"></i>
          <b class="pretext">Действия</b>
        </div>
  
  <div class="block ban-application" id="complaintCloseBlock" style="padding: 0px 20px;">
            <div class="form-group mb-0">
                <div class="input-group">
                   <label for="birth_day" class="custom-select with-title">
                    <select id="sentence">
                        {if('{sentence}' == '0')}
                            {if(is_worthy_specifically("k", {server_id}))}
                                <option value="1">Оправдать</option>
                                <option value="2">Выдать предупреждение</option>
                            {/if}
                            {if(is_worthy_specifically("j", {server_id}))}
                                <option value="3">Удалить услуги</option>
                                <option value="4">Заблокировать услуги</option>
                            {/if}
                        {/if}
                        {if(is_worthy_specifically("u", {server_id}))}
                            <option value="5">Удалить жалобу</option>
                        {/if}
                    </select>
                     <span>Выберите действие</span>
                     </label>
                </div>
                 <button class="tune_complain" type="button" onclick="closeComplaint({id}, {accused_admin_id});">Выполнить</button>
            </div>
        </div>
        <script>
            if($('#sentence').find('option').length === 0) {
            	$('#complaintCloseBlock').remove();
            }
        </script>
    {/if}
</div>

<div class="col-lg-12">
    <div class="block">
       <div class="block_head">
			<i class="bx bx-message-square-detail" style="width: 33px;background: #494c56;display: flex;font-size: 14px;border-radius: 8px;color: #777b88;margin-right: 11px;height: 33px;align-items: center;justify-content: center;"></i> Комментарии / Обсуждение
		</div>

        {if(is_auth() && '{sentence}' == '0')}
			<textarea id="text" maxlength="500"></textarea>

			<div class="smile_input_forum mt-3">
				<input id="send_btn" class="btn btn-primary" type="button" onclick="sendComplaintComment({id});" value="Отправить">
				<div id="smile_btn" class="smile_btn" data-container="body" data-toggle="popover" data-placement="top" data-content="empty"></div>
			</div>

            <script>
				$(document).ready(function () {
					init_tinymce(
						'text',
						'lite',
						"{file_manager_theme}",
						"{file_manager}",
						"{{md5($conf->code)}}"
					);
					get_smiles('#smile_btn', 1);
				});

				$('#smile_btn').popover({html: true, animation: true, trigger: "click"});
				$('#smile_btn').on('show.bs.popover', function () {
					$(document).mouseup(function (e) {
						var container = $('.popover-body');
						if (container.has(e.target).length === 0) {
							$('#smile_btn').popover('hide');
							selected = 'gcms_smiles';
						}
					});
				});

				function set_smile(elem) {
					var smile = '<img src="' + $(elem).attr('src') + '" class="g_smile" height="20px" width="20px">';
					tinymce.activeEditor.insertContent(smile);
					$('#smile_btn').popover('hide');
					selected = 'gcms_smiles';
				}
            </script>
        {/if}

        <div id="comments" class="mt-3">
            <div class="loader"></div>
            <script>loadComplaintComments({id});</script>
        </div>
    </div>
</div>