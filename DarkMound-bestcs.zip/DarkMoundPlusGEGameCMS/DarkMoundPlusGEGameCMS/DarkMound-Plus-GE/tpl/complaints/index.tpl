<div class="col-lg-9 order-is-first">
   <div class="referal_block" style="background: #fff0;border: solid 1px #262639;">
                  <div class="black_list_left">
                  <i class='bx bx-detail' style="top: 0px;font-size: 18px;"></i>
                    <div class="black_list_text">
                      <span class="black_list_h1">Жалобы</span>
                      <span class="black_list_h2">Стали свидетелем нарушения? Оставьте<br> жалобу</span>
                    </div>
                     </div>
                  </div>
  
  <div class="flex-double">
    <a href="../complaints/add" class="add-click">
  	<div style="display: flex;flex-direction: column;">
      <span class="h1-list">Подать жалобу</span>
      <span class="h2-list">Есть сведения о нарушении правил? Давайте разберем ситуацию <i class="bx bx-error-alt"></i></span>
    </div>
    </a>
    
    <a href="../bans" class="return-click">
    	<div style="display: flex;flex-direction: column;">
      <span class="h1-list">Заявка на разбан</span>
      <span class="h2-list">Усомнились в своем бане? Создайте тикет на аппеляцию прямо сейчас <i class='bx bx-lock-open-alt' ></i></span>
    </div>
      </a>
  </div>

	<div class="block" style="padding: 10px 18px;">
		<div class="table-responsive mb-0">
			<table class="table table-bordered">
				<thead>
					<tr>
						<td style="padding-top: 15px;">Действие</td>
						<td style="padding-top: 15px;">Нарушитель</td>
						<td style="padding-top: 15px;">Статус</td>
						<td style="padding-top: 15px;">Дата создания</td>
					</tr>
				</thead>
				<tbody id="bans">
					{func Complaints:getList("{accusedProfileId}","{server}","{start}","{limit}")}
				</tbody>
			</table>
		</div>
	</div>

	<div id="pagination2">{pagination}</div>
</div>

<div class="col-lg-3 order-is-last">

	
{include file="/parts/sidebar.tpl"}
</div>