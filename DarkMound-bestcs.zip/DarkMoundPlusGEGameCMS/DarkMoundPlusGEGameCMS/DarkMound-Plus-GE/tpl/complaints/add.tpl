<div class="col-lg-9 order-is-first">

  <!-- Заголовок -->
        <div class="top_info">
          <i class='bx bx-detail' ></i>
          <b class="pretext">Подать жалобу</b>
        </div>
	<div class="block">	
      		<div class="form-group">
			<label for="birth_day" class="custom-select with-title" style="margin-top: -25px;margin-bottom: 20px;">
			<select id="server_id">{servers}</select>
				<span>Выберите сервер</span>
		</label>
		</div>
          <div class="form-group" style="margin-top: -27px;">      
    <label for="accused" style="margin-bottom: 20px;" class="custom-input with-title">
      <input  id="accused" autocomplete="off" type="text" placeholder=" ">
      <span>Введите ник нарушителя / steam_id / логин на сайте</span>
	</label>
    </div>

		<div class="form-group">
			<label for="accused">
			
			</label>
			<button class="button-m" onclick="findTheAccused()">Найти нарушителя</button>

			<div id="find-result-table" class="table-responsive mb-0 mt-3" style="display: none">
				<table class="table table-bordered">
					<thead>
						<tr style="background: #2c3956;">
							<td style="padding-top: 15px;">Действие</td>
							<td style="padding-top: 15px;">Профиль</td>
							<td style="padding-top: 15px;">Индентификатор</td>
							<td style="padding-top: 15px;">Услуги</td>
						</tr>
					</thead>
					<tbody id="find-result">
						<tr>
							<td colspan="10">
								<div class="loader"></div>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>

		<div id="accused-info" style="display: none;"></div>

		<div id="additional-info" style="display: none">
			<div class="form-group mt-3">
				<span for="description">
					<h4>Пояснения</h4>
				</span>
				<br>

				<textarea id="description" rows="3" maxlength="2000"></textarea>
			</div>

			<div class="form-group">
				<span>
					<h4>Скриншоты <small>(максимальное количество: 5)</small></h4>
				</span>
				<br>

				<div id="imgs"></div>

				<div class="input-group mt-3" style="display: flex;flex-direction: column;align-items: flex-start;">
					<input type="file" id="image" accept="image/*" style="margin-left: 0px;">
					<button class="btn btn-outline-primary" type="button" onclick="loadImages('complaints');">Загрузить</button>
				</div>
				<div id="load-image-result"></div>

				<input type="hidden" id="counter" value="0">
				<input type="hidden" id="images-load-result-value" value="" autocomplete="off">
			</div>

			<div class="form-group">
				<span for="demo">
					<h4>Ссылка на демо <small>(Необязательно)</small></h4>
				</span>
				<input type="text" class="form-control" id="demo" maxlength="250" autocomplete="off">
			</div>

			<div id="result" class="mt-10"></div>
			<button onclick="addComplaint(this);" type="button" class="btn btn-primary mt-3">Создать</button>
		</div>
	</div>
</div>
<script>
  $(document).ready(function () {
    init_tinymce('description', 'lite', "{file_manager_theme}", "{file_manager}", "{{md5($conf->code)}}");
  });
</script>

<div class="col-lg-3 order-is-last">
	{include file="/parts/mini-profile.tpl"}
	{include file="/parts/sidebar.tpl"}
</div>