{configuration}

// Описание проекта в футере
// -------------------------
{var:footer_description}
bestcs.uz - Counter-Strike 1.6 serveri. VIP imkoniyatlar, maxsus skin va modellar, Telegram orqali qulay xarid. Bizga qo'shiling va o'ynang!

{/var}

// Баннеры в футере (88x31)
// ------------------------
//banner 1
{var:footer_banners[0]['link']} https://t.me/bestcsuz {/var}
{var:footer_banners[0]['img']} https://via.placeholder.com/88x31.jpg?v={cache} {/var}
//banner 2
{var:footer_banners[1]['link']} https://t.me/bestcsuz {/var}
{var:footer_banners[1]['img']} https://via.placeholder.com/88x31.jpg?v={cache} {/var}
//banner 3
{var:footer_banners[2]['link']} https://t.me/bestcsuz {/var}
{var:footer_banners[2]['img']} https://via.placeholder.com/88x31.jpg?v={cache} {/var}

{/configuration}