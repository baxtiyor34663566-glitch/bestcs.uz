{if(is_auth())}
<div class="container">
<div class="two_top_menu">
        <div class="menu_top_left">
          
          <a href="../">
          <div class="menu_top_push">
            <i class='bx bx-home-alt-2' ></i> Главная
          </div>
          </a>
          
          <div class="menu_top_left">
            <a href="../news">
          <div class="menu_top_push_active">
            <i class='bx bx-globe' ></i> Новости
          </div>
           </a>
         </div> 
          
        <div class="menu_top_left">
          <a href="../forum">
          <div class="menu_top_push">
            <i class='bx bx-chat' ></i> Форум
          </div>
          </a>
         </div> 
          
          <div class="menu_top_left">
            <a href="../support">
          <div class="menu_top_push">
            <i class='bx bx-support' ></i> Поддержка
          </div>
           </a>
         </div> 
          </div>
        
         <div class="menu_top_rigth">
           
           <a href="../users">
           <div class="search_user">
           <i class='bx bx-search'></i>
             <span>Foydalanuvchini qidirish</span>
           </div> 
           </a>
                    
            <div class="qr_code_top" data-target="#promocode" data-toggle="modal">
             <i class='bx bx-scan' ></i> Promokod
           </div>
           
         </div> 
        </div> 
</div> 
{/if}
<style>
  .two_menu_2 {
    display: none;
  }
  

</style>

<div class="container">
<div class="row_menu">

<div class="col-lg-9 order-is-first">
	      <!-- Заголовок -->
      <div class="top_info">
	 	<i class='bx bx-map-alt' ></i>
          <b class="pretext">Новости проекта</b>
      </div>

	<div class="clearfix"></div>

	<div id="new_news" class="row" style="
    display: flex;
    flex-wrap: wrap;
">
		{func GetData:news("{start}","{class}","{limit}")}
	</div>
	
	<div id="pagination2">{pagination}</div>
</div>

<div class="col-lg-3 order-is-last">
  {if(is_worthy("b"))}
  	<div class="block" style="padding: 0px;background: #fff;margin-bottom: 50px;">
	<a class="btn btn-outline-primary btn-xl" href="../news/add_new">
		Добавить новость
	</a>
    </div>
	{/if}
   
	{include file="/parts/sidebar.tpl"}
</div>
</div>
</div>