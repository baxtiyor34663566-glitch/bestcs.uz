 {if(is_auth())}
 <div class="container">
     <div class="two_top_menu">
         <div class="menu_top_left">

             <a href="../">
                 <div class="menu_top_push">
                     <i class='bx bx-home-alt-2'></i> Главная
                 </div>
             </a>

             <div class="menu_top_left">
                 <a href="../news">
                     <div class="menu_top_push_active">
                         <i class='bx bx-globe'></i> Новости
                     </div>
                 </a>
             </div>

             <div class="menu_top_left">
                 <a href="../forum">
                     <div class="menu_top_push">
                         <i class='bx bx-chat'></i> Форум
                     </div>
                 </a>
             </div>

             <div class="menu_top_left">
                 <a href="../support">
                     <div class="menu_top_push">
                         <i class='bx bx-support'></i> Поддержка
                     </div>
                 </a>
             </div>
         </div>

         <div class="menu_top_rigth">

             <a href="../users">
                 <div class="search_user">
                     <i class='bx bx-search'></i>
                     <span>Foydalanuvchini qidirish</span>
                 </div>
             </a>

             <div class="qr_code_top" data-target="#promocode" data-toggle="modal">
                 <i class='bx bx-scan'></i> Promokod
             </div>

         </div>
     </div>
 </div>
 {/if}
 <style>
     .two_menu_2 {
         display: none;
     }
 </style>

 <div class="container">
     <div class="row_menu">

         <div class="col-lg-9 order-is-first">
             <!-- Заголовок -->
             <div class="top_info_forum">
                 {if(is_worthy("q"))}
                 <a href="../news/change_new?id={id}" class="add_forum1">
                     <i class="far fa-pencil"></i>
                 </a>
                 <a href="#" onclick="dell_new('{id}','2');" class="add_forum1">
                     <i class="far fa-trash"></i>
                 </a>
                 {/if}

                 <i class='bx bx-map-alt' style="        background: linear-gradient(33deg, #835ed9 0%, #7539ff 85%);width: 40px;height: 40px;border-radius: 10px;display: flex;color: #fff;top: 0px;margin-right: 10px;font-size: 17px;align-items: center;justify-content: center;"></i>
                 <b class="pretext">{name}</b>
             </div>
             <div class="news_flex">
                 <div class="news-block-imgg" style="background-image: url(../{img});background-size: cover;">
                     <span>{date}</span>
                 </div>
             </div>

             <div class="clearfix"></div>
             <!-- Заголовок -->
             <div class="top_info">
                 <i class='bx bx-box'></i>
                 <b class="pretext">Содержание</b>
             </div>
             <div class="block new">
                 <div class="with_code" style="margin: 10px;">
                     {text}
                 </div>
             </div>

             <!-- Заголовок -->
             <div class="top_info">
                 <i class='bx bx-chat'></i>
                 <b class="pretext">Комментарии</b>
             </div>
             {if(is_auth())}
             <div class="block" style="padding: 15px;padding-bottom: 40px; margin-bottom: 50px;">
                 <textarea id="text"></textarea>
                 <div class="smile_input_forum mt-3">

                     <button id="send_btn" class="btn btn-primary" type="button" onclick="send_new_comment({id});" style="float: right;position: relative;margin-right: 1px;padding: 17px;width: 10px;top: -20px;display: flex;font-size: 14px;align-items: center;justify-content: center;"><i class='bx bxs-send'></i></button>
                     <div id="smile_btn" class="smile_btn" data-container="body" data-toggle="popover" data-placement="top" data-content="empty" style="top: 6px;"></div>
                 </div>
             </div>
             {/if}


             <div class="block" style="padding: 0px;background: #fff0; display: flex;
    flex-direction: column-reverse;">
                 <div id="comments" class="mt-3">
                     <div class="loader"></div>
                     <script>
                         load_new_comments("{id}");
                     </script>
                 </div>
                 {if(is_auth())}
                 <br>

                 <p style="font-weight: 600;color: #545866;margin-bottom: -70px;font-size: 12px;"></p>
                 <script>
                     $(document).ready(function() {
                         init_tinymce("text", "lite", "{file_manager_theme}", "{file_manager}", "{{md5($conf->code)}}");
                         get_smiles('#smile_btn');
                     });
                     $('#smile_btn').popover({
                         html: true,
                         animation: true,
                         trigger: "click"
                     });
                     $('#smile_btn').on('show.bs.popover', function() {
                         $(document).mouseup(function(e) {
                             var container = $(".popover-body");
                             if (container.has(e.target).length === 0) {
                                 $('#smile_btn').popover('hide');
                                 selected = 'gcms_smiles';
                             }
                         });
                     });

                     function set_sticker(elem) {
                         var text = "sticker" + $(elem).attr("src");
                         text = encodeURIComponent(text);
                         send_new_comment({
                             id
                         }, text);
                         $('#smile_btn').popover('hide');
                         selected = 'gcms_smiles';
                     }

                     function set_smile(elem) {
                         var smile = "<img src=\"" + $(elem).attr("src") + "\" class=\"g_smile\" height=\"20px\" width=\"20px\">";
                         tinymce.activeEditor.insertContent(smile);
                         $('#smile_btn').popover('hide');
                         selected = 'gcms_smiles';
                     }
                 </script>
                 {/if}

             </div>
         </div>

         <div class="col-lg-3 order-is-last">


             {include file="/parts/sidebar.tpl"}
         </div>
     </div>
 </div>