</div>
</div>
</div>

<div class="container">
  <div class="bottom_stats">
	 <div id="site_stats">
        <script>
          get_site_stats(1);
        </script>
      </div>
   </div>
  <div class="bottom_new" style="background-image: url(../templates/DarkMound-Plus-GE/img/bottom.png);background-size: cover;">
  <div class="bottom_info">  
   <div class="left_bottom_logo">
     <span class="logol">
		<a href="../">
           <img class="logo_button" src="../templates/DarkMound-Plus-GE/img/logo.png">
        </a>
     </span>
      <div class="bottom_info_left">
        <span>{site_name} <b class="shield_bottom">© Barcha huquqlar himoyalangan</b>{gamecms_copyright}</span>
        <span><b class="shield_bottom">O'yin loyihasi:</b> Counter-Strike 1.6</span>
      </div>
    </div>
    
    <div class="bottom_info_right">
     <div class="nav_bottom_soc">
        <a href="https://t.me/bestcschat" target="_blank" rel="noopener" title="Telegram chat" class="icon-ds">
          <i class="bx bx-chat"></i>
        </a>

         <a href="https://t.me/bestcsuz" target="_blank" rel="noopener" title="Telegram kanal" class="icon-tg">
          <i class="bx bxl-telegram"></i>
        </a>
      </div>
    </div>
  </div>
   
    <div class="full_menu_bottom">
    <div class="menu_bottom_left">
      {{$footer_description}}
    </div>
    <div class="menu_bottom_right">
    <div class="menu_link">
	<div class="block_head_purse">
		Navigatsiya
        <span class="line_purse"></span>
		</div>
		<div class="vertical_menu_link">
           <a href="../"><span class="dote_link">Bosh sahifa</span> </a>
           <a href="../news"><span class="dote_link">Loyiha yangiliklari</span> </a>
           <a href="../store"><span class="dote_link">Privilegiyalar do'koni</span> </a>
           <a href="../forum"><span class="dote_link">Forum</span> </a>
        </div>
    </div>
    
    <div class="menu_link">
	<div class="block_head_purse">
		Loyiha
        <span class="line_purse"></span>
		</div>
		<div class="vertical_menu_link">
           <a href="../users"><span class="dote_link">Foydalanuvchilar</span> </a>
           <a href="../admins"><span class="dote_link">Administratorlar</span> </a>
           <a href="../banlist"><span class="dote_link">Banlar ro'yxati</span> </a>
           <a href="../bans"><span class="dote_link">Unban arizalari</span> </a>
        </div>
    </div>
    
        <div class="menu_link">
	<div class="block_head_purse">
		Ma'lumot
        <span class="line_purse"></span>
		</div>
		<div class="vertical_menu_link">
           <a href="https://t.me/bestcsuz" target="_blank" rel="noopener"><span class="dote_link">Telegram kanal</span> </a>
           <a href="https://t.me/bestcschat" target="_blank" rel="noopener"><span class="dote_link">Telegram chat</span> </a>
           <a href="steam://connect/195.158.4.108:27111"><span class="dote_link">Server: 195.158.4.108:27111</span> </a>
        </div>
    </div>
    </div>
      </div>
    
   <div class="bottom_water_info">
     <div class="bottom_water_info_left">
      	<a href="../privacy-policy">
            <button class="button_bottom_left">Maxfiylik siyosati</button>
        </a>
       
        <a href="../rules">
            <button class="button_bottom_left">Loyiha qoidalari</button>
        </a>
   	 </div>
     
     <div class="banners_bottom">
    	
       
         <div id='hidden_modals'></div>
   	 </div>  
   </div>
 </div>
    
    <script src="{site_host}templates/{template}/js/lightbox.js"></script>
    <script>
      window.onload = function() {
        $('[tooltip="yes"]').tooltip();
        $('[data-toggle="dropdown"]').dropdown();
      };
    </script>
 